<?php

session_start();

require_once "connection.php";


$error_message = "";


if ($_SERVER["REQUEST_METHOD"] == "POST") {


    $username = trim($_POST["username"]);

    $password = $_POST["password"];



    $sql = "SELECT 
            ID,
            firstname,
            middlename,
            surname,
            username,
            password,
            email,
            usertype

            FROM logintbl

            WHERE username = ?";



    $stmt = mysqli_prepare($conn, $sql);



    if ($stmt) {



        mysqli_stmt_bind_param(
            $stmt,
            "s",
            $username
        );



        mysqli_stmt_execute($stmt);



        $result = mysqli_stmt_get_result($stmt);



        if ($result && mysqli_num_rows($result) == 1) {



            $row = mysqli_fetch_assoc($result);



            if (password_verify($password, $row["password"])) {



                session_regenerate_id(true);



                $_SESSION["ID"] = $row["ID"];

                $_SESSION["firstname"] = $row["firstname"];

                $_SESSION["middlename"] = $row["middlename"];

                $_SESSION["surname"] = $row["surname"];

                $_SESSION["username"] = $row["username"];

                $_SESSION["email"] = $row["email"];

                $_SESSION["usertype"] = $row["usertype"];





                // ADMIN LOGIN

                if ($row["usertype"] == "admin") {



                    $_SESSION["admin_id"] = $row["ID"];

                    $_SESSION["admin_name"] = $row["username"];



                    header(
                        "Location: /CAPSTONE/admin/admin_dashboard.php"
                    );


                    exit();



                }



                // USER LOGIN

                else {



                    $_SESSION["user_id"] = $row["ID"];



                    header(
                        "Location: /CAPSTONE/user/user_dashboard.php"
                    );


                    exit();



                }



            }


            else {


                $error_message =
                "Invalid Username or Password.";


            }



        }


        else {


            $error_message =
            "Invalid Username or Password.";


        }



        mysqli_stmt_close($stmt);



    }


    else {


        $error_message =
        "Database Error.";


    }



}


mysqli_close($conn);


?>

<!DOCTYPE html>

<html lang="en">


<head>


<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">


<title>e-Nurse Login</title>



<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">



<style>


*{

    margin:0;

    padding:0;

    box-sizing:border-box;

    font-family:'Poppins',sans-serif;

}



body{


    min-height:100vh;


    display:flex;


    justify-content:center;


    align-items:center;


    background:linear-gradient(
        135deg,
        #eff6ff,
        #dbeafe
    );


    padding:20px;


}




/* LOGIN CONTAINER */


.login-box{


    width:420px;


    background:white;


    padding:45px 40px;


    border-radius:25px;


    box-shadow:
    0 20px 50px rgba(0,0,0,0.12);



}



/* LOGO */


.logo{


    text-align:center;


    font-size:42px;


    font-weight:700;


    color:#2563eb;


    margin-bottom:10px;



}



.logo span{


    color:#0ea5e9;


}



/* DESCRIPTION */


.subtitle{


    text-align:center;


    color:#64748b;


    font-size:14px;


    line-height:1.6;


    margin-bottom:35px;



}



/* INPUT AREA */


.input-group{


    margin-bottom:20px;



}



.input-group input{


    width:100%;


    padding:15px 18px;


    border:1px solid #cbd5e1;


    border-radius:12px;


    font-size:15px;


    outline:none;


    transition:.3s;



}



.input-group input:focus{


    border-color:#2563eb;


    box-shadow:
    0 0 0 4px rgba(37,99,235,.15);



}



/* SHOW PASSWORD */


.show{


    font-size:14px;


    color:#64748b;


    margin-bottom:25px;



}



.show input{


    margin-right:6px;


}



/* BUTTON */


button{


    width:100%;


    padding:15px;


    border:none;


    border-radius:12px;


    background:#2563eb;


    color:white;


    font-size:16px;


    font-weight:600;


    cursor:pointer;


    transition:.3s;



}



button:hover{


    background:#1d4ed8;


    transform:translateY(-2px);



}




/* ERROR MESSAGE */


.error{


    background:#fee2e2;


    color:#b91c1c;


    padding:12px;


    border-radius:10px;


    font-size:14px;


    text-align:center;


    margin-bottom:20px;



}



/* MOBILE RESPONSIVE */


@media(max-width:480px){



    .login-box{


        width:100%;


        padding:35px 25px;


        border-radius:20px;



    }




    .logo{


        font-size:36px;



    }



    .subtitle{


        font-size:13px;



    }



}


</style>


</head>
    
    <body>


<div class="login-box">



    <div class="logo">

        e-<span>Nurse</span>

    </div>




    <p class="subtitle">

        Online Review and Mock Licensure Examination System
        for Nursing Students.

    </p>





    <form method="POST">





        <?php

        if (!empty($error_message)) {


            echo "

            <div class='error'>

            $error_message

            </div>

            ";

        }

        ?>






        <div class="input-group">


            <input

            type="text"

            name="username"

            placeholder="Username"

            required>


        </div>







        <div class="input-group">


            <input

            type="password"

            id="password"

            name="password"

            placeholder="Password"

            required>


        </div>







        <div class="show">


            <label>


                <input

                type="checkbox"

                id="showPassword">


                Show Password


            </label>


        </div>







        <button type="submit">


            Login


        </button>






    </form>




</div>









<script>


const password = document.getElementById("password");


const showPassword = document.getElementById("showPassword");



showPassword.addEventListener("change", function(){



    if(this.checked){


        password.type = "text";


    }

    else{


        password.type = "password";


    }



});



</script>





</body>


</html>