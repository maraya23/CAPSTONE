<?php
session_start();

require_once "connection.php";

/* Log logout activity */
if (isset($_SESSION['user_id'])) {

    $user_id = $_SESSION['user_id'];
    $activity = "Logged out";

    $stmt = $conn->prepare("INSERT INTO user_activity (user_id, activity) VALUES (?, ?)");
    $stmt->bind_param("is", $user_id, $activity);
    $stmt->execute();
    $stmt->close();
}

/* Clear all session variables */
$_SESSION = [];

/* Destroy session */
session_destroy();

header("Location: login.php");
exit();
?>