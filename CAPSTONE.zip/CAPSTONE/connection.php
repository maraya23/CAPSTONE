<?php

$host = "sql104.infinityfree.com";
$user = "if0_42371645";
$pass = "d3b5iCBMhnkPq7j";
$db   = "if0_42371645_capstonedb";

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
    die("Database Connection Failed: " . mysqli_connect_error());
}

/* Set UTF-8 character encoding */
mysqli_set_charset($conn, "utf8mb4");

/* Set the correct timezone */
date_default_timezone_set('Asia/Manila');

?>