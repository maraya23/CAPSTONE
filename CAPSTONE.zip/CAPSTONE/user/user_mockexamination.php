<?php

error_reporting(E_ALL);
ini_set('display_errors',1);

session_start();

require_once "../connection.php";

/* ==========================================
   CHECK LOGIN
========================================== */

if(!isset($_SESSION["user_id"])){

    header("Location: ../login.php");
    exit();

}

$user_id = $_SESSION["user_id"];

/* ==========================================
   USER INFORMATION
========================================== */

$fullname = "Student";

$sql = "

SELECT

firstname,
surname

FROM logintbl

WHERE id=?

LIMIT 1

";

$stmt = mysqli_prepare($conn,$sql);

mysqli_stmt_bind_param($stmt,"i",$user_id);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

if($row=mysqli_fetch_assoc($result)){

    $fullname =
    $row["firstname"] . " " .
    $row["surname"];

}

/* ==========================================
   VERIFY E-PERMIT
========================================== */

$error = "";

if(isset($_POST["verify"])){

    $exam_id = (int)$_POST["exam_id"];

    $permit_number = trim($_POST["permit_number"]);

    $sql = "

    SELECT

        permit_id,
        exam_id,
        permit_number

    FROM e_permits

   WHERE permit_number=?
AND user_id=?
AND exam_id=?
AND permit_status='Unused'

    LIMIT 1

    ";

    $stmt = mysqli_prepare($conn,$sql);

    mysqli_stmt_bind_param(

        $stmt,
        "sii",
        $permit_number,
        $exam_id,
        $user_id

    );

    mysqli_stmt_execute($stmt);

    $permitResult = mysqli_stmt_get_result($stmt);

    if(mysqli_num_rows($permitResult)==1){

        $permit = mysqli_fetch_assoc($permitResult);

        $_SESSION["permit_id"]     = $permit["permit_id"];
        $_SESSION["permit_number"] = $permit["permit_number"];
        $_SESSION["exam_id"]        = $permit["exam_id"];

        header("Location: take_mockexam.php");
        exit();

    }else{

        $error = "Invalid E-Permit Number for this examination.";

    }

}

/* ==========================================
   LOAD PUBLISHED MOCK EXAMS
========================================== */

$sql = "

SELECT

    e.exam_id,
    e.title,
    e.description,
    e.duration,
    e.total_questions,
    e.passing_score,
    e.exam_type,
    c.category_name

FROM exams e

LEFT JOIN categories c

ON e.category_id=c.category_id

WHERE

    e.status='Published'

AND

    e.exam_type='Mock Exam'

ORDER BY e.created_at DESC

";

$exams = mysqli_query($conn,$sql);

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Mock Examination</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css">

<?php include "user_sidebar.php"; ?>

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    background:#f3f6fb;
}

/* ==========================
   MAIN CONTENT
========================== */

.main-content{
    margin-left:230px;
    padding:30px;
    min-height:100vh;
}

/* ==========================
   PAGE HEADER
========================== */

.page-header{
    margin-bottom:35px;
}

.page-header h1{
    color:#0A2F73;
    font-size:34px;
    font-weight:700;
    margin-bottom:8px;
}

.page-header p{
    color:#64748b;
    font-size:15px;
    line-height:1.7;
}

/* ==========================
   EXAM GRID
========================== */

.exam-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(340px,1fr));
    gap:25px;
}

/* ==========================
   EXAM CARD
========================== */

.exam-card{
    background:#fff;
    border-radius:20px;
    padding:28px;
    box-shadow:0 8px 22px rgba(0,0,0,.08);
    border:1px solid #edf2f7;
    transition:.25s;
}

.exam-card:hover{
    transform:translateY(-5px);
    box-shadow:0 15px 28px rgba(37,99,235,.15);
}

.exam-icon{
    width:70px;
    height:70px;
    border-radius:18px;
    background:#e8f1ff;
    color:#2563eb;
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:30px;
    margin-bottom:20px;
}

.exam-card h2{
    color:#0A2F73;
    font-size:24px;
    margin-bottom:12px;
}

.exam-description{
    color:#64748b;
    font-size:15px;
    line-height:1.7;
    margin-bottom:18px;
    min-height:70px;
}

/* ==========================
   CATEGORY
========================== */

.category{
    display:inline-block;
    background:#eef4ff;
    color:#2563eb;
    padding:8px 16px;
    border-radius:25px;
    font-size:13px;
    font-weight:600;
    margin-bottom:20px;
}

/* ==========================
   DETAILS
========================== */

.exam-details{
    margin-bottom:25px;
}

.exam-details p{
    margin-bottom:12px;
    color:#475569;
    font-size:15px;
}

.exam-details i{
    width:22px;
    color:#2563eb;
}

/* ==========================
   BUTTON
========================== */

.take-btn{
    width:100%;
    border:none;
    border-radius:14px;
    background:#2563eb;
    color:#fff;
    padding:15px;
    cursor:pointer;
    font-size:15px;
    font-weight:600;
    transition:.25s;
}

.take-btn:hover{
    background:#1d4ed8;
}

.take-btn i{
    margin-right:8px;
}

/* ==========================
   EMPTY STATE
========================== */

.empty-card{
    grid-column:1/-1;
    background:#fff;
    border-radius:20px;
    padding:60px 30px;
    text-align:center;
    box-shadow:0 8px 22px rgba(0,0,0,.08);
}

.empty-card i{
    font-size:70px;
    color:#94a3b8;
    margin-bottom:20px;
}

.empty-card h2{
    color:#0A2F73;
    margin-bottom:10px;
}

.empty-card p{
    color:#64748b;
}

/* ==========================
   REMINDER
========================== */

.reminder-card{
    margin-top:35px;
    background:#fff8e6;
    border-left:6px solid #f59e0b;
    border-radius:18px;
    padding:25px;
}

.reminder-title{
    color:#b45309;
    font-size:20px;
    font-weight:700;
    margin-bottom:15px;
}

.reminder-title i{
    margin-right:10px;
}

.reminder-card ul{
    padding-left:22px;
}

.reminder-card li{
    color:#6b4f00;
    margin-bottom:12px;
    line-height:1.7;
}

/* ==========================
   MODAL
========================== */

.modal{
    display:none;
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.45);
    justify-content:center;
    align-items:center;
    z-index:9999;
}

.modal-content{
    background:#fff;
    width:90%;
    max-width:500px;
    border-radius:20px;
    padding:35px;
    position:relative;
    animation:popup .25s ease;
}

@keyframes popup{

from{

transform:scale(.9);
opacity:0;

}

to{

transform:scale(1);
opacity:1;

}

}

.close{
    position:absolute;
    right:20px;
    top:18px;
    font-size:30px;
    cursor:pointer;
    color:#64748b;
}

.close:hover{
    color:#ef4444;
}

.modal-content h2{
    color:#0A2F73;
    margin-bottom:10px;
}

.modal-content p{
    color:#64748b;
    margin-bottom:20px;
}

.modal-content input{
    width:100%;
    padding:14px;
    border:1px solid #d1d5db;
    border-radius:12px;
    margin-bottom:18px;
    font-size:15px;
}

.modal-content input:focus{
    outline:none;
    border-color:#2563eb;
}

.verify-btn{
    width:100%;
    border:none;
    background:#2563eb;
    color:#fff;
    padding:15px;
    border-radius:12px;
    cursor:pointer;
    font-size:15px;
    font-weight:600;
}

.verify-btn:hover{
    background:#1d4ed8;
}

/* ==========================
   ERROR
========================== */

.error-box{
    margin-top:18px;
    padding:14px;
    background:#fee2e2;
    color:#b91c1c;
    border-radius:12px;
    font-size:14px;
}

/* ==========================
   MOBILE
========================== */

@media(max-width:768px){

.main-content{
    margin-left:0;
    padding:85px 15px 20px;
}

.page-header h1{
    font-size:28px;
}

.exam-grid{
    grid-template-columns:1fr;
}

.exam-card{
    padding:22px;
}

.modal-content{
    padding:25px;
}

}

</style>

</head>
    
    <body>

<div class="main-content">

    <!-- =====================================
         PAGE HEADER
    ====================================== -->

    <div class="page-header">

        <h1>
            <i class="fa-solid fa-clipboard-list"></i>
            Mock Examination
        </h1>

        <p>

            Welcome,

            <strong><?= htmlspecialchars($fullname); ?></strong>

            <br><br>

            Select a published mock examination below.

            The examination timer will only begin after your
            <strong>E-Permit</strong> has been successfully verified.

        </p>

    </div>


    <!-- =====================================
         AVAILABLE EXAMINATIONS
    ====================================== -->

    <div class="exam-grid">

    <?php

    if(mysqli_num_rows($exams) > 0){

        while($exam = mysqli_fetch_assoc($exams)){

    ?>

        <div class="exam-card">

            <div class="exam-icon">

                <i class="fa-solid fa-file-circle-check"></i>

            </div>

            <h2>

                <?= htmlspecialchars($exam["title"]); ?>

            </h2>

            <div class="exam-description">

                <?php

                if(!empty($exam["description"])){

                    echo nl2br(htmlspecialchars($exam["description"]));

                }else{

                    echo "No examination description available.";

                }

                ?>

            </div>

            <?php if(!empty($exam["category_name"])){ ?>

                <span class="category">

                    <?= htmlspecialchars($exam["category_name"]); ?>

                </span>

            <?php } ?>

            <div class="exam-details">

                <p>

                    <i class="fa-solid fa-layer-group"></i>

                    <strong>Type:</strong>

                    <?= htmlspecialchars($exam["exam_type"]); ?>

                </p>

                <p>

                    <i class="fa-solid fa-clock"></i>

                    <strong>Duration:</strong>

                    <?= (int)$exam["duration"]; ?>

                    Minutes

                </p>

                <p>

                    <i class="fa-solid fa-list-check"></i>

                    <strong>Total Questions:</strong>

                    <?= (int)$exam["total_questions"]; ?>

                </p>

                <p>

                    <i class="fa-solid fa-award"></i>

                    <strong>Passing Score:</strong>

                    <?= (int)$exam["passing_score"]; ?>%

                </p>

            </div>

            <button

                type="button"

                class="take-btn"

                onclick="openModal(<?= $exam['exam_id']; ?>)">

                <i class="fa-solid fa-play"></i>

                Take Mock Examination

            </button>

        </div>

    <?php

        }

    }else{

    ?>

        <div class="empty-card">

            <i class="fa-solid fa-folder-open"></i>

            <h2>

                No Published Mock Examination

            </h2>

            <p>

                There are currently no published mock examinations available.

                Please check again later.

            </p>

        </div>

    <?php

    }

    ?>

    </div>
    
        <!-- =====================================
         EXAMINATION REMINDER
    ====================================== -->

    <div class="reminder-card">

        <div class="reminder-title">

            <i class="fa-solid fa-triangle-exclamation"></i>

            Examination Reminder

        </div>

        <ul>

            <li>
                Prepare your assigned <strong>E-Permit Number</strong> before starting the examination.
            </li>

            <li>
                The examination timer starts immediately after your E-Permit has been verified.
            </li>

            <li>
                Each examinee receives a randomized order of questions.
            </li>

            <li>
                Do not refresh, close, or leave your browser while taking the examination.
            </li>

            <li>
                Your answers are final once the examination has been submitted.
            </li>

        </ul>

    </div>

</div>


<!-- =====================================
     E-PERMIT VERIFICATION MODAL
===================================== -->

<div class="modal" id="permitModal">

    <div class="modal-content">

        <span class="close" onclick="closeModal()">

            &times;

        </span>

        <h2>

            <i class="fa-solid fa-id-card"></i>

            Verify E-Permit

        </h2>

        <p>

            Enter the E-Permit Number issued by the administrator to begin this examination.

        </p>

        <form
            action="verify_permit.php"
            method="POST">

            <input
                type="hidden"
                name="exam_id"
                id="exam_id">

            <input
                type="text"
                name="permit_number"
                placeholder="ENURSE-20260722-1234"
                autocomplete="off"
                required>

            <button
                type="submit"
                name="verify">

                <i class="fa-solid fa-circle-check"></i>

                Verify & Start Examination

            </button>

        </form>

    </div>

</div>
        
        <script>

/* =====================================
   E-PERMIT MODAL
===================================== */

const permitModal = document.getElementById("permitModal");

function openModal(examId){

    document.getElementById("exam_id").value = examId;

    permitModal.style.display = "flex";

}

function closeModal(){

    permitModal.style.display = "none";

}


/* =====================================
   CLOSE MODAL WHEN CLICKING OUTSIDE
===================================== */

window.onclick = function(e){

    if(e.target === permitModal){

        closeModal();

    }

};


/* =====================================
   ESC KEY CLOSE
===================================== */

document.addEventListener("keydown",function(e){

    if(e.key === "Escape"){

        closeModal();

    }

});

</script>

</body>
</html>