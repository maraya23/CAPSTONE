<?php

session_start();
require_once "../connection.php";

// Check login
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION["user_id"];

// Load 100 random questions
$sql = "SELECT * FROM questions ORDER BY RAND() LIMIT 100";
$result = mysqli_query($conn, $sql);

$questions = [];

while ($row = mysqli_fetch_assoc($result)) {
    $questions[] = $row;
}

$totalQuestions = count($questions);

// Store questions in session
if (!isset($_SESSION["mock_exam"])) {
    $_SESSION["mock_exam"] = $questions;
}

$questions = $_SESSION["mock_exam"];

// Store answers
if (!isset($_SESSION["answers"])) {
    $_SESSION["answers"] = [];
}

// Current Question
$current = isset($_GET['q']) ? intval($_GET['q']) : 1;

if ($current < 1) {
    $current = 1;
}

if ($current > count($questions)) {
    $current = count($questions);
}

// Save answer
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["answer"])) {

    $_SESSION["answers"][$current] = $_POST["answer"];

    if (isset($_POST["next"])) {

        header("Location:user_mockexamination.php?q=" . ($current + 1));
        exit();

    }

    if (isset($_POST["previous"])) {

        header("Location:user_mockexamination.php?q=" . ($current - 1));
        exit();

    }

}

$question = $questions[$current - 1];

?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Mock Examination</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css">

<?php include 'user_sidebar.php'; ?>

    <style>
        
        *{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    background:#f3f6fb;
}

/* ==========================
    MAIN CONTENT
========================== */

.main-content{
    margin-left:230px;
    padding:30px;
    min-height:100vh;
}

/* ==========================
    TOP BAR
========================== */

.top-bar{

    display:flex;

    justify-content:space-between;

    align-items:center;

    background:#fff;

    padding:18px 25px;

    border-radius:14px;

    box-shadow:0 5px 18px rgba(0,0,0,.08);

    margin-bottom:25px;

}

.timer-box{

    background:#eaf2ff;

    color:#1d4ed8;

    padding:10px 18px;

    border-radius:10px;

    font-weight:600;

    font-size:15px;

}

.timer-box i{

    margin-right:8px;

}

.question-count{

    font-size:18px;

    font-weight:600;

    color:#333;

}

.submit-btn{

    background:#22c55e;

    color:white;

    border:none;

    padding:12px 22px;

    border-radius:10px;

    cursor:pointer;

    font-size:15px;

    font-weight:600;

    transition:.3s;

}

.submit-btn:hover{

    background:#16a34a;

}

/* ==========================
    CONTENT
========================== */

.exam-container{

    display:grid;

    grid-template-columns:280px 1fr;

    gap:25px;

}

/* ==========================
    NAVIGATOR
========================== */

.navigator{

    background:#fff;

    border-radius:14px;

    padding:20px;

    box-shadow:0 5px 18px rgba(0,0,0,.08);

}

.navigator h3{

    margin-bottom:20px;

    color:#0A2F73;

    font-size:18px;

}

.number-grid{

    display:grid;

    grid-template-columns:repeat(5,1fr);

    gap:10px;

}

.number-grid a{

    text-decoration:none;

    width:42px;

    height:42px;

    display:flex;

    justify-content:center;

    align-items:center;

    border-radius:10px;

    background:#eef2f7;

    color:#555;

    font-weight:600;

    transition:.25s;

}

.number-grid a:hover{

    background:#dbeafe;

}

.number-grid a.current{

    background:#2563eb;

    color:white;

}

.number-grid a.answered{

    background:#16a34a;

    color:white;

}

/* ==========================
    QUESTION CARD
========================== */

.question-card{

    background:white;

    border-radius:14px;

    padding:30px;

    box-shadow:0 5px 18px rgba(0,0,0,.08);

}

.category{

    color:#2563eb;

    font-weight:600;

    margin-bottom:18px;

}

.question-card h2{

    font-size:22px;

    margin-bottom:25px;

    color:#222;

    line-height:1.5;

}

/* ==========================
    CHOICES
========================== */

.choice{

    display:flex;

    align-items:flex-start;

    gap:12px;

    background:#f8fafc;

    padding:16px;

    border-radius:10px;

    margin-bottom:15px;

    cursor:pointer;

    transition:.25s;

    border:2px solid transparent;

}

.choice:hover{

    border-color:#2563eb;

    background:#eef4ff;

}

.choice input{

    margin-top:4px;

    transform:scale(1.2);

}

/* ==========================
    BUTTONS
========================== */

.button-group{

    display:flex;

    justify-content:space-between;

    margin-top:35px;

}

.prev-btn{

    background:#64748b;

    color:white;

    border:none;

    padding:12px 24px;

    border-radius:10px;

    cursor:pointer;

    font-size:15px;

    transition:.3s;

}

.prev-btn:hover{

    background:#475569;

}

.next-btn{

    background:#2563eb;

    color:white;

    border:none;

    padding:12px 24px;

    border-radius:10px;

    cursor:pointer;

    font-size:15px;

    transition:.3s;

}

.next-btn:hover{

    background:#1d4ed8;

}

/* ==========================
    MOBILE
========================== */

@media(max-width:768px){

.main-content{

    margin-left:0;

    padding:80px 15px 20px;

}

.top-bar{

    flex-direction:column;

    gap:15px;

}

.exam-container{

    grid-template-columns:1fr;

}

.navigator{

    order:2;

}

.question-card{

    order:1;

}

.number-grid{

    grid-template-columns:repeat(5,1fr);

}

}
        
    </style>
    
</head>

<body>

<div class="main-content">

    <!-- =========================
            TOP BAR
    ========================== -->

    <div class="top-bar">

        <div class="timer-box">

            <i class="fa-solid fa-clock"></i>

            <span id="timer">02:30:00</span>

        </div>

        <div class="question-count">

            Question

            <strong><?= $current ?></strong>

            of

            <strong><?= count($questions) ?></strong>

        </div>

        <form method="POST" id="submitExamForm">

            <button
                type="submit"
                name="submit_exam"
                class="submit-btn">

                <i class="fa-solid fa-paper-plane"></i>

                Submit Exam

            </button>

        </form>

    </div>



    <div class="exam-container">

        <!-- =====================
            QUESTION NAVIGATOR
        ====================== -->

        <div class="navigator">

            <h3>

                Question Navigator

            </h3>

            <div class="number-grid">

                <?php

                for($i=1;$i<=count($questions);$i++):

                    $class="";

                    if($i==$current){

                        $class="current";

                    }

                    elseif(isset($_SESSION["answers"][$i])){

                        $class="answered";

                    }

                ?>

                <a

                    href="?q=<?= $i; ?>"

                    class="<?= $class; ?>">

                    <?= $i; ?>

                </a>

                <?php endfor; ?>

            </div>

        </div>



        <!-- =====================
              QUESTION AREA
        ====================== -->

        <div class="question-card">

            <div class="category">

                Category :

                <strong>

                    <?= htmlspecialchars($question["category"]); ?>

                </strong>

            </div>

            <h2>

                <?= htmlspecialchars($question["question"]); ?>

            </h2>

            <form method="POST">

                <label class="choice">

                    <input

                        type="radio"

                        name="answer"

                        value="A"

                        <?= (($_SESSION["answers"][$current] ?? "")=="A") ? "checked" : ""; ?>>

                    A. <?= htmlspecialchars($question["choice_a"]); ?>

                </label>

                <label class="choice">

                    <input

                        type="radio"

                        name="answer"

                        value="B"

                        <?= (($_SESSION["answers"][$current] ?? "")=="B") ? "checked" : ""; ?>>

                    B. <?= htmlspecialchars($question["choice_b"]); ?>

                </label>

                <label class="choice">

                    <input

                        type="radio"

                        name="answer"

                        value="C"

                        <?= (($_SESSION["answers"][$current] ?? "")=="C") ? "checked" : ""; ?>>

                    C. <?= htmlspecialchars($question["choice_c"]); ?>

                </label>

                <label class="choice">

                    <input

                        type="radio"

                        name="answer"

                        value="D"

                        <?= (($_SESSION["answers"][$current] ?? "")=="D") ? "checked" : ""; ?>>

                    D. <?= htmlspecialchars($question["choice_d"]); ?>

                </label>

                <div class="button-group">

                    <?php if($current>1): ?>

                    <button

                        class="prev-btn"

                        type="submit"

                        name="previous">

                        <i class="fa-solid fa-arrow-left"></i>

                        Previous

                    </button>

                    <?php endif; ?>

                    <?php if($current<count($questions)): ?>

                    <button

                        class="next-btn"

                        type="submit"

                        name="next">

                        Next

                        <i class="fa-solid fa-arrow-right"></i>

                    </button>

                    <?php endif; ?>

                </div>

            </form>

        </div>

    </div>

</div>

    <script>

// ===============================
// EXAM TIMER (2 HOURS 30 MINUTES)
// ===============================

let totalSeconds = 2 * 60 * 60 + 30 * 60; // 2:30:00

const timer = document.getElementById("timer");

function updateTimer(){

    let hours = Math.floor(totalSeconds / 3600);

    let minutes = Math.floor((totalSeconds % 3600) / 60);

    let seconds = totalSeconds % 60;

    hours = String(hours).padStart(2,'0');
    minutes = String(minutes).padStart(2,'0');
    seconds = String(seconds).padStart(2,'0');

    timer.innerHTML = hours + ":" + minutes + ":" + seconds;

    if(totalSeconds <= 0){

        clearInterval(countdown);

        alert("Time is up! Your exam will now be submitted.");

        document.getElementById("submitExamForm").submit();

    }

    totalSeconds--;

}

updateTimer();

const countdown = setInterval(updateTimer,1000);

// ===============================
// SUBMIT CONFIRMATION
// ===============================

document.getElementById("submitExamForm").addEventListener("submit",function(e){

    if(!confirm("Are you sure you want to submit your exam? You cannot change your answers afterwards.")){

        e.preventDefault();

    }

});

// ===============================
// HIGHLIGHT SELECTED CHOICE
// ===============================

const radios = document.querySelectorAll("input[type=radio]");

radios.forEach(function(radio){

    radio.addEventListener("change",function(){

        document.querySelectorAll(".choice").forEach(function(choice){

            choice.style.borderColor="transparent";

            choice.style.background="#f8fafc";

        });

        this.parentElement.style.borderColor="#2563eb";

        this.parentElement.style.background="#eaf2ff";

    });

});

// Restore selected answer styling
window.onload = function(){

    const checked = document.querySelector("input[type=radio]:checked");

    if(checked){

        checked.parentElement.style.borderColor="#2563eb";

        checked.parentElement.style.background="#eaf2ff";

    }

}

</script>
    
</body>
</html>