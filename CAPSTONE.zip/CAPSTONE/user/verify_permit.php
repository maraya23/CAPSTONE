<?php

error_reporting(E_ALL);
ini_set('display_errors',1);

session_start();

require_once "../connection.php";

/* ==========================================
   CHECK LOGIN
========================================== */

if(!isset($_SESSION["user_id"])){

    header("Location: ../login.php");
    exit();

}

$user_id = $_SESSION["user_id"];

/* ==========================================
   ACCEPT POST ONLY
========================================== */

if($_SERVER["REQUEST_METHOD"]!="POST"){

    header("Location:user_mockexamination.php");
    exit();

}

/* ==========================================
   GET FORM VALUES
========================================== */

$exam_id = isset($_POST["exam_id"])
    ? (int)$_POST["exam_id"]
    : 0;

$permit_number = trim($_POST["permit_number"]);

/* ==========================================
   VALIDATE INPUT
========================================== */

if($exam_id<=0 || $permit_number==""){

    $_SESSION["permit_error"] =
    "Please enter your E-Permit Number.";

    header("Location:user_mockexamination.php");
    exit();

}

/* ==========================================
   VERIFY E-PERMIT
========================================== */

$sql = "

SELECT

    permit_id,
    permit_number,
    exam_id,
    user_id

FROM e_permits

WHERE

    permit_number=?

AND

    exam_id=?

AND

    user_id=?

LIMIT 1

";

$stmt = mysqli_prepare($conn,$sql);

mysqli_stmt_bind_param(

    $stmt,

    "sii",

    $permit_number,

    $exam_id,

    $user_id

);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

/* ==========================================
   PERMIT FOUND
========================================== */

if(mysqli_num_rows($result)==1){

    $permit = mysqli_fetch_assoc($result);

    // Save permit information
    $_SESSION["permit_id"] = $permit["permit_id"];
    $_SESSION["permit_number"] = $permit["permit_number"];
    $_SESSION["exam_id"] = $permit["exam_id"];

    // Clear any previous exam session
    unset($_SESSION["mock_exam"]);
    unset($_SESSION["answers"]);
    unset($_SESSION["attempt_id"]);

    // Proceed to the examination
    header("Location: take_mockexam.php");
    exit();

}

/* ==========================================
   INVALID PERMIT
========================================== */

$_SESSION["permit_error"] =
"Invalid E-Permit Number or this permit is not assigned to the selected examination.";

header("Location:user_mockexamination.php");
exit();

?>