<?php

error_reporting(E_ALL);
ini_set('display_errors',1);

session_start();

require_once "../connection.php";



/* ==========================================
   CHECK LOGIN
========================================== */

if(!isset($_SESSION["user_id"])){

    header("Location: ../login.php");
    exit();

}


$user_id = $_SESSION["user_id"];




/* ==========================================
   CHECK ACTIVE ATTEMPT
========================================== */


if(!isset($_SESSION["attempt_id"])){

    die("No active examination.");

}


$attempt_id = $_SESSION["attempt_id"];





/* ==========================================
   CHECK EXAM SESSION DATA
========================================== */


if(

    !isset($_SESSION["mock_exam"]) ||

    !isset($_SESSION["answers"])

){

    die("Exam data missing.");

}





$questions = $_SESSION["mock_exam"];

$answers = $_SESSION["answers"];


$totalQuestions = count($questions);




/* ==========================================
   CHECK IF ALREADY SUBMITTED
========================================== */


$sql="

SELECT end_time

FROM exam_attempts

WHERE attempt_id=?

LIMIT 1

";



$stmt=mysqli_prepare($conn,$sql);


mysqli_stmt_bind_param(

    $stmt,

    "i",

    $attempt_id

);



mysqli_stmt_execute($stmt);



$result=mysqli_stmt_get_result($stmt);



$attempt=mysqli_fetch_assoc($result);





if(!empty($attempt["end_time"])){

    die("Examination already submitted.");

}







/* ==========================================
   COMPUTE SCORE
========================================== */


$score=0;



foreach($questions as $index=>$question){



    $number=$index+1;



    $studentAnswer="";



    if(isset($answers[$number])){


        $studentAnswer=$answers[$number];


    }



    if(

        $studentAnswer ==

        $question["correct_answer"]

    ){


        $score++;


    }


}








/* ==========================================
   CALCULATE PERCENTAGE
========================================== */


$percentage=0;



if($totalQuestions>0){


    $percentage=round(

        ($score/$totalQuestions)*100

    );


}







/* ==========================================
   GET EXAM PASSING SCORE
========================================== */


$exam_id=$_SESSION["exam_id"];



$sql="

SELECT

title,

passing_score

FROM exams

WHERE exam_id=?

LIMIT 1

";



$stmt=mysqli_prepare($conn,$sql);



mysqli_stmt_bind_param(

    $stmt,

    "i",

    $exam_id

);



mysqli_stmt_execute($stmt);



$result=mysqli_stmt_get_result($stmt);



$exam=mysqli_fetch_assoc($result);





$title=$exam["title"];

$passingScore=$exam["passing_score"];







/* ==========================================
   RESULT STATUS
========================================== */


if($percentage >= $passingScore){


    $status="Passed";


}else{


    $status="Failed";


}







/* ==========================================
   UPDATE ATTEMPT RESULT
========================================== */


$end_time=date(
    "Y-m-d H:i:s"
);



$sql="

UPDATE exam_attempts

SET

end_time=?,

score=?,

total_questions=?,

percentage=?,

remarks=?

WHERE attempt_id=?

";



$stmt=mysqli_prepare($conn,$sql);



mysqli_stmt_bind_param(

    $stmt,

    "siiisi",

    $end_time,

    $score,

    $totalQuestions,

    $percentage,

    $status,

    $attempt_id

);



mysqli_stmt_execute($stmt);








/* ==========================================
   SAVE STUDENT ANSWERS
========================================== */



foreach($questions as $index=>$question){



    $question_id=$question["question_id"];


    $number=$index+1;



    $studentAnswer="";



    if(isset($answers[$number])){


        $studentAnswer=$answers[$number];


    }



    $correctAnswer=
    $question["correct_answer"];




    $isCorrect=0;



    if($studentAnswer==$correctAnswer){


        $isCorrect=1;


    }





    $sql="

    INSERT INTO exam_answers

    (

        attempt_id,

        question_id,

        selected_answer,

        correct_answer,

        is_correct

    )

    VALUES

    (?,?,?,?,?)

    ";



    $stmt=mysqli_prepare($conn,$sql);



    mysqli_stmt_bind_param(

        $stmt,

        "iissi",

        $attempt_id,

        $question_id,

        $studentAnswer,

        $correctAnswer,

        $isCorrect

    );



    mysqli_stmt_execute($stmt);



}







/* ==========================================
   CONSUME E-PERMIT
   ONE TIME USE ONLY
========================================== */


unset($_SESSION["permit_id"]);

unset($_SESSION["permit_number"]);

unset($_SESSION["exam_id"]);

unset($_SESSION["mock_exam"]);

unset($_SESSION["answers"]);

unset($_SESSION["attempt_id"]);



?>



<!DOCTYPE html>

<html lang="en">

<head>


<meta charset="UTF-8">


<meta name="viewport" content="width=device-width,initial-scale=1.0">



<title>Exam Result</title>


<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">



<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css">



<style>


*{

margin:0;
padding:0;
box-sizing:border-box;
font-family:'Poppins',sans-serif;

}


body{

background:#f3f6fb;

}


.result-container{

min-height:100vh;

display:flex;

justify-content:center;

align-items:center;

padding:30px;

}



.result-card{

background:white;

max-width:550px;

width:100%;

padding:40px;

border-radius:25px;

text-align:center;

box-shadow:0 10px 30px rgba(0,0,0,.08);

}



.icon{

width:90px;

height:90px;

border-radius:50%;

display:flex;

justify-content:center;

align-items:center;

font-size:40px;

margin:auto auto 20px;

}



.pass{

background:#dcfce7;

color:#16a34a;

}



.fail{

background:#fee2e2;

color:#dc2626;

}



h1{

color:#0A2F73;

margin-bottom:10px;

}



.title{

color:#64748b;

margin-bottom:25px;

}



.score{

font-size:45px;

font-weight:700;

color:#2563eb;

}



.info{

margin-top:25px;

text-align:left;

}



.info p{

padding:12px 0;

border-bottom:1px solid #e5e7eb;

}



.btn{

display:block;

margin-top:25px;

background:#2563eb;

color:white;

text-decoration:none;

padding:15px;

border-radius:12px;

font-weight:600;

}



</style>


</head>



<body>



<div class="result-container">


<div class="result-card">



<?php if($status=="Passed"){ ?>


<div class="icon pass">

<i class="fa-solid fa-check"></i>

</div>


<h1>

Congratulations!

</h1>


<?php }else{ ?>


<div class="icon fail">

<i class="fa-solid fa-xmark"></i>

</div>


<h1>

Exam Completed

</h1>


<?php } ?>





<div class="title">

<?=htmlspecialchars($title);?>

</div>





<div class="score">

<?=$percentage;?>%

</div>





<div class="info">


<p>

<strong>Score:</strong>

<?=$score;?> / <?=$totalQuestions;?>

</p>


<p>

<strong>Status:</strong>

<?=$status;?>

</p>



<p>

<strong>Submitted:</strong>

<?=date("M d, Y h:i A");?>

</p>


</div>






<a href="user_dashboard.php" class="btn">

<i class="fa-solid fa-house"></i>

Return Dashboard

</a>



</div>


</div>



</body>

</html>