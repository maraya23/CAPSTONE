<?php

session_start();

require_once "../connection.php";

// ===============================
// CHECK LOGIN
// ===============================

if (!isset($_SESSION["user_id"])) {

    header("Location: ../login.php");

    exit();

}

$user_id = $_SESSION["user_id"];

// ===============================
// GET STUDENT INFORMATION
// ===============================

$sql = "SELECT
            firstname,
            middlename,
            surname
        FROM logintbl
        WHERE ID = ?";

$stmt = mysqli_prepare($conn, $sql);

mysqli_stmt_bind_param($stmt, "i", $user_id);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

$user = mysqli_fetch_assoc($result);

// ===============================
// FULL NAME
// ===============================

$fullname = trim(

    $user['firstname']." ".

    $user['middlename']." ".

    $user['surname']

);

// ===============================
// PERMIT INFORMATION
// ===============================

$permitNumber = "EPN-".date("Y")."-".str_pad($user_id,5,"0",STR_PAD_LEFT);

$dateIssued = date("F d, Y");

$validFor = "Mock Examination";

$status = "Approved";

// ===============================
// QR CODE
// ===============================

// Uses Google Chart API

$qrText = $permitNumber." | ".$fullname;

$qrCode = "https://chart.googleapis.com/chart?chs=250x250&cht=qr&chl="

            . urlencode($qrText);

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>E-Permit</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap"
rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css">

<?php include "user_sidebar.php"; ?>

<style>

/*=====================================
    GENERAL
======================================*/

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    background:#f4f7fc;
}

/*=====================================
    MAIN CONTENT
======================================*/

.main-content{

    margin-left:230px;

    padding:30px;

    min-height:100vh;

}

/*=====================================
    PAGE HEADER
======================================*/

.page-header{

    margin-bottom:25px;

}

.page-header h1{

    font-size:32px;

    color:#0A2F73;

    margin-bottom:6px;

}

.page-header p{

    color:#6b7280;

    font-size:15px;

}

/*=====================================
    PERMIT CARD
======================================*/

.permit-card{

    background:#fff;

    border-radius:18px;

    padding:30px;

    box-shadow:0 10px 30px rgba(0,0,0,.08);

}

/*=====================================
    HEADER
======================================*/

.permit-header{

    display:flex;

    justify-content:space-between;

    align-items:center;

    margin-bottom:25px;

}

.permit-header h2{

    font-size:24px;

    color:#0A2F73;

}

.permit-header h2 i{

    color:#2563eb;

    margin-right:10px;

}

/*=====================================
    STATUS
======================================*/

.status{

    padding:10px 18px;

    border-radius:30px;

    font-size:14px;

    font-weight:600;

}

.status.approved{

    background:#dcfce7;

    color:#15803d;

}

.status i{

    margin-right:6px;

}

/*=====================================
    APPROVAL BOX
======================================*/

.approval-box{

    display:flex;

    align-items:flex-start;

    gap:15px;

    background:#f0fdf4;

    border:1px solid #bbf7d0;

    border-radius:12px;

    padding:18px;

    margin-bottom:30px;

}

.approval-box i{

    font-size:28px;

    color:#16a34a;

}

.approval-box h3{

    color:#15803d;

    margin-bottom:5px;

}

.approval-box p{

    color:#4b5563;

    font-size:14px;

}

/*=====================================
    BODY
======================================*/

.permit-body{

    display:grid;

    grid-template-columns:2fr 1fr;

    gap:30px;

    align-items:center;

}

/*=====================================
    DETAILS
======================================*/

.permit-details table{

    width:100%;

    border-collapse:collapse;

}

.permit-details td{

    padding:14px 0;

    border-bottom:1px solid #edf2f7;

    font-size:15px;

}

.permit-details td:first-child{

    width:180px;

    color:#6b7280;

    font-weight:600;

}

.permit-details td:last-child{

    color:#111827;

    font-weight:500;

}

/*=====================================
    QR
======================================*/

.qr-section{

    text-align:center;

}

.qr-section img{

    width:180px;

    height:180px;

    border:8px solid #f8fafc;

    border-radius:12px;

    box-shadow:0 6px 18px rgba(0,0,0,.08);

}

.qr-section p{

    margin-top:12px;

    color:#6b7280;

    font-size:14px;

}

/*=====================================
    NOTICE
======================================*/

.notice-box{

    margin-top:30px;

    background:#fffbeb;

    border:1px solid #fde68a;

    color:#92400e;

    border-radius:12px;

    padding:15px 18px;

    display:flex;

    align-items:center;

    gap:10px;

}

.notice-box i{

    color:#d97706;

}

/*=====================================
    BUTTONS
======================================*/

.permit-actions{

    margin-top:30px;

    display:flex;

    justify-content:flex-end;

}

.permit-actions button{

    background:#2563eb;

    color:#fff;

    border:none;

    padding:14px 24px;

    border-radius:10px;

    cursor:pointer;

    font-size:15px;

    font-weight:600;

    transition:.3s;

}

.permit-actions button:hover{

    background:#1d4ed8;

    transform:translateY(-2px);

}

.permit-actions i{

    margin-right:8px;

}

/*=====================================
    TABLET
======================================*/

@media(max-width:992px){

.main-content{

    padding:20px;

}

.permit-body{

    grid-template-columns:1fr;

}

.qr-section{

    margin-top:20px;

}

}

/*=====================================
    MOBILE
======================================*/

@media(max-width:768px){

.main-content{

    margin-left:0;

    padding:80px 15px 20px;

}

.page-header h1{

    font-size:28px;

}

.permit-card{

    padding:20px;

}

.permit-header{

    flex-direction:column;

    align-items:flex-start;

    gap:15px;

}

.status{

    align-self:flex-start;

}

.permit-body{

    grid-template-columns:1fr;

}

.permit-details td{

    display:block;

    width:100%;

    border:none;

    padding:5px 0;

}

.permit-details tr{

    display:block;

    margin-bottom:18px;

    border-bottom:1px solid #e5e7eb;

    padding-bottom:10px;

}

.permit-details td:first-child{

    font-size:13px;

    color:#6b7280;

    margin-bottom:3px;

}

.permit-details td:last-child{

    font-size:15px;

}

.qr-section img{

    width:170px;

    height:170px;

}

.notice-box{

    font-size:14px;

    align-items:flex-start;

}

.permit-actions{

    justify-content:center;

}

.permit-actions button{

    width:100%;

}

}

/*=====================================
    PRINT
======================================*/

@media print{

.sidebar,
.menu-toggle,
.overlay,
.page-header,
.permit-actions{

    display:none !important;

}

.main-content{

    margin:0;

    padding:0;

}

.permit-card{

    box-shadow:none;

    border:1px solid #ccc;

}

}
    
    

</style>

</head>

<body>

<div class="main-content">

    <!-- ==========================
            PAGE HEADER
    =========================== -->

    <div class="page-header">

        <h1>E-Permit</h1>

        <p>
            Present this electronic permit before taking the mock examination.
        </p>

    </div>



    <!-- ==========================
            PERMIT CARD
    =========================== -->

    <div class="permit-card">

        <!-- HEADER -->

        <div class="permit-header">

            <div>

                <h2>

                    <i class="fa-solid fa-id-card"></i>

                    Electronic Permit

                </h2>

            </div>

            <span class="status approved">

                <i class="fa-solid fa-circle-check"></i>

                <?= $status ?>

            </span>

        </div>



        <!-- SUCCESS MESSAGE -->

        <div class="approval-box">

            <i class="fa-solid fa-circle-check"></i>

            <div>

                <h3>Your e-Permit is Approved!</h3>

                <p>

                    You may now take the Mock Examination.

                </p>

            </div>

        </div>



        <!-- BODY -->

        <div class="permit-body">

            <!-- LEFT -->

            <div class="permit-details">

                <table>

                    <tr>

                        <td>Permit No.</td>

                        <td><?= $permitNumber ?></td>

                    </tr>

                    <tr>

                        <td>Student Name</td>

                        <td><?= htmlspecialchars($fullname) ?></td>

                    </tr>

                    <tr>

                        <td>Date Issued</td>

                        <td><?= $dateIssued ?></td>

                    </tr>

                    <tr>

                        <td>Valid For</td>

                        <td><?= $validFor ?></td>

                    </tr>

                </table>

            </div>



            <!-- RIGHT -->

            <div class="qr-section">

                <img

                src="<?= $qrCode ?>"

                alt="QR Code">

                <p>

                    Scan to verify permit

                </p>

            </div>

        </div>



        <!-- NOTICE -->

        <div class="notice-box">

            <i class="fa-solid fa-triangle-exclamation"></i>

            <span>

                This e-Permit is valid for ONE-TIME USE only.

            </span>

        </div>



        <!-- ACTION BUTTONS -->

        <div class="permit-actions">

            <button onclick="window.print()">

                <i class="fa-solid fa-print"></i>

                Print Permit

            </button>

        </div>

    </div>

</div>

</body>

</html>