<?php

session_start();
require_once "../connection.php";

// ===============================
// USER LOGIN
// ===============================

if(!isset($_SESSION["user_id"])){

    header("Location: ../login.php");
    exit();

}

$user_id = $_SESSION["user_id"];

// ===============================
// LOAD USER
// ===============================

$sql = "

SELECT

l.id,
l.username,
l.email,
l.firstname,
l.middlename,
l.surname,

p.student_number,
p.gender,
p.birthday,
p.contact_number,
p.address,
p.profile_picture

FROM logintbl l

LEFT JOIN user_profile p

ON l.id=p.user_id

WHERE l.id=?

";

$stmt = mysqli_prepare($conn,$sql);

mysqli_stmt_bind_param($stmt,"i",$user_id);

mysqli_stmt_execute($stmt);

$result=mysqli_stmt_get_result($stmt);

$user=mysqli_fetch_assoc($result);

if(!$user){

    die("User not found.");

}

// ===============================
// PROFILE IMAGE
// ===============================

$profile = "/CAPSTONE/uploads/profile/default.png";


if(!empty($user["profile_picture"])){

    $custom = "/CAPSTONE/uploads/profile/".$user["profile_picture"];


    $profile = $custom;

}

?>
<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0">

<title>My Profile</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    
    <style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    background:#eef3fb;
    font-family:'Poppins',sans-serif;
}

/* ===========================
MAIN
=========================== */

.main{

    margin-left:230px;
    width:calc(100% - 230px);
    min-height:100vh;
    padding:30px;

}

/* ===========================
PAGE HEADER
=========================== */

.page-header{

    background:#fff;
    border-radius:18px;
    padding:25px 30px;
    margin-bottom:25px;
    box-shadow:0 5px 15px rgba(0,0,0,.06);

}

.page-header h1{

    font-size:30px;
    color:#111827;

}

.page-header p{

    color:#6b7280;
    margin-top:6px;

}

/* ===========================
CARD
=========================== */

.card{

    background:#fff;
    border-radius:18px;
    box-shadow:0 5px 15px rgba(0,0,0,.06);
    overflow:hidden;

}

.card-header{

    padding:22px 28px;
    border-bottom:1px solid #e5e7eb;

}

.card-header h2{

    font-size:24px;
    color:#111827;

}

/* ===========================
PROFILE LAYOUT
=========================== */

.profile-wrapper{

    display:grid;
    grid-template-columns:300px 1fr;
    gap:35px;
    padding:30px;

}

/* ===========================
LEFT PANEL
=========================== */

.profile-left{

    text-align:center;

}

.profile-image{

    width:200px;
    height:200px;
    margin:auto;
    border-radius:50%;
    overflow:hidden;
    border:8px solid #edf3ff;
    background:#f8fafc;

}

.profile-image img{

    width:100%;
    height:100%;
    object-fit:cover;
    display:block;

}

.upload-area{

    margin-top:25px;

}

.upload-area label{

    display:block;
    font-weight:600;
    margin-bottom:10px;
    color:#111827;

}

.upload-area input{

    width:100%;

}

.upload-note{

    margin-top:10px;
    font-size:13px;
    color:#6b7280;

}

/* ===========================
RIGHT PANEL
=========================== */

.profile-right{

    width:100%;

}

.form-grid{

    display:grid;
    grid-template-columns:repeat(2,1fr);
    gap:22px;

}

.form-group{

    display:flex;
    flex-direction:column;

}

.form-group label{

    margin-bottom:8px;
    font-weight:600;
    color:#374151;

}

.form-group input,
.form-group select,
.form-group textarea{

    width:100%;
    height:48px;
    border:1px solid #d1d5db;
    border-radius:10px;
    padding:0 15px;
    font-size:14px;
    font-family:'Poppins',sans-serif;

}

.form-group textarea{

    height:110px;
    resize:none;
    padding-top:14px;

}

.full{

    grid-column:1 / -1;

}

/* ===========================
BUTTONS
=========================== */

.button-area{

    margin-top:35px;
    display:flex;
    justify-content:flex-end;
    gap:15px;

}

.btn{

    border:none;
    padding:12px 22px;
    border-radius:10px;
    cursor:pointer;
    font-family:'Poppins',sans-serif;
    font-weight:600;
    transition:.25s;

}

.btn:hover{

    transform:translateY(-2px);

}

.btn-primary{

    background:#2563eb;
    color:white;

}

.btn-secondary{

    background:#e5e7eb;
    color:#111827;

}

/* ===========================
RESPONSIVE
=========================== */

@media(max-width:992px){

.main{

    margin-left:0;
    width:100%;
    padding:85px 20px 20px;

}

.profile-wrapper{

    grid-template-columns:1fr;

}

.profile-left{

    margin-bottom:10px;

}

}

@media(max-width:768px){

.form-grid{

    grid-template-columns:1fr;

}

.profile-image{

    width:170px;
    height:170px;

}

.button-area{

    flex-direction:column;

}

.btn{

    width:100%;

}

}

</style>

</head>

<body>

<?php include "user_sidebar.php"; ?>

<div class="main">

<div class="page-header">

<h1>My Profile</h1>

<p>Manage your personal information and account details.</p>

</div>

<form
action="update_profile.php"
method="POST"
enctype="multipart/form-data">

<div class="card">

<div class="card-header">

<h2>User Information</h2>

</div>

<div class="profile-wrapper">
    
    <!-- ===========================
LEFT SIDE
=========================== -->

<div class="profile-left">

    <div class="profile-image">

        <img
        src="<?php echo $profile; ?>"
        alt="Profile Picture">

    </div>

    <div class="upload-area">

        <label>Profile Picture</label>

        <input
        type="file"
        name="profile_picture"
        accept="image/*">

        <div class="upload-note">

            Leave blank if you don't want to change your picture.

        </div>

    </div>

</div>

<!-- ===========================
RIGHT SIDE
=========================== -->

<div class="profile-right">

<div class="form-grid">

<!-- First Name -->

<div class="form-group">

<label>First Name</label>

<input
type="text"
name="firstname"
required
value="<?php echo htmlspecialchars($user['firstname']); ?>">

</div>

<!-- Middle Name -->

<div class="form-group">

<label>Middle Name</label>

<input
type="text"
name="middlename"
value="<?php echo htmlspecialchars($user['middlename']); ?>">

</div>

<!-- Surname -->

<div class="form-group">

<label>Surname</label>

<input
type="text"
name="surname"
required
value="<?php echo htmlspecialchars($user['surname']); ?>">

</div>

<!-- Username -->

<div class="form-group">

<label>Username</label>

<input
type="text"
name="username"
required
value="<?php echo htmlspecialchars($user['username']); ?>">

</div>

<!-- Email -->

<div class="form-group">

<label>Email Address</label>

<input
type="email"
name="email"
required
value="<?php echo htmlspecialchars($user['email']); ?>">

</div>

<!-- Student Number -->

<div class="form-group">

<label>Student Number</label>

<input
type="text"
name="student_number"
value="<?php echo htmlspecialchars($user['student_number']); ?>">

</div>

<!-- Gender -->

<div class="form-group">

<label>Gender</label>

<select name="gender">

<option value="">Select Gender</option>

<option value="Male"
<?php if($user['gender']=="Male") echo "selected"; ?>>
Male
</option>

<option value="Female"
<?php if($user['gender']=="Female") echo "selected"; ?>>
Female
</option>

</select>

</div>

<!-- Birthday -->

<div class="form-group">

<label>Birthday</label>

<input
type="date"
name="birthday"
value="<?php echo $user['birthday']; ?>">

</div>

<!-- Contact -->

<div class="form-group">

<label>Contact Number</label>

<input
type="text"
name="contact_number"
value="<?php echo htmlspecialchars($user['contact_number']); ?>">

</div>

<!-- Address -->

<div class="form-group full">

<label>Address</label>

<textarea
name="address"><?php echo htmlspecialchars($user['address']); ?></textarea>

</div>

</div>
    
    <!-- ===========================
BUTTONS
=========================== -->

<div class="button-area">

    <button
    type="button"
    class="btn btn-secondary"
    onclick="window.location='user_dashboard.php'">

        Cancel

    </button>

    <button
    type="submit"
    class="btn btn-primary">

        <i class="fa-solid fa-floppy-disk"></i>

        Save Changes

    </button>

</div>

</div>

</div>

</form>

</div>

</body>

</html>