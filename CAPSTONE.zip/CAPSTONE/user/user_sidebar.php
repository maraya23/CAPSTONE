<?php
$current = basename($_SERVER['PHP_SELF']);
?>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

/* ===========================
   SIDEBAR
=========================== */

.sidebar{

    position:fixed;
    top:0;
    left:0;

    width:230px;
    height:100vh;

    background:linear-gradient(180deg,#041B3D,#0A2F73);

    color:#fff;

    font-family:'Poppins',sans-serif;

    padding:20px 15px;

    display:flex;
    flex-direction:column;

    transition:.35s ease;

    z-index:1001;

}

.logo{

    text-align:center;

    font-size:26px;

    font-weight:700;

    letter-spacing:.5px;

    margin:15px 0 30px;

}

.menu{

    display:flex;

    flex-direction:column;

    gap:8px;

    flex:1;

}

.menu a{

    display:flex;

    align-items:center;

    gap:14px;

    text-decoration:none;

    color:#fff;

    padding:13px 15px;

    border-radius:12px;

    transition:.25s;

    font-size:14px;

    font-weight:500;

}

.menu a i{

    width:22px;

    text-align:center;

    font-size:17px;

}

.menu a:hover{

    background:#2563eb;

}

.menu a.active{

    background:#3568E8;

}

.logout{

    margin-top:auto;

}

/* ===========================
   MOBILE BUTTON
=========================== */

.menu-toggle{

    display:none;

    position:fixed;

    top:15px;

    left:15px;

    width:48px;

    height:48px;

    border:none;

    border-radius:12px;

    background:#0A2F73;

    color:white;

    font-size:20px;

    cursor:pointer;

    z-index:1100;

    box-shadow:0 6px 18px rgba(0,0,0,.25);

}

/* ===========================
   OVERLAY
=========================== */

.overlay{

    position:fixed;

    inset:0;

    background:rgba(0,0,0,.45);

    opacity:0;

    visibility:hidden;

    transition:.3s;

    z-index:1000;

}

.overlay.show{

    opacity:1;

    visibility:visible;

}

/* ===========================
   MOBILE RESPONSIVE
=========================== */

@media(max-width:768px){

    .sidebar{

        width:min(85vw,280px);

        left:-100%;

        padding:20px 15px;

    }

    .sidebar.show{

        left:0;

    }

    .menu-toggle{

        display:flex;

        align-items:center;

        justify-content:center;

    }

    .logo{

        font-size:24px;

        margin:10px 0 25px;

    }

    .menu a{

        font-size:15px;

        padding:14px 16px;

    }

}

</style>

<button class="menu-toggle" onclick="toggleSidebar()">
    <i class="fa-solid fa-bars"></i>
</button>

<div class="overlay" id="overlay" onclick="closeSidebar()"></div>

<aside class="sidebar" id="sidebar">

    <div class="logo">
        e-Nurse
    </div>

    <nav class="menu">

        <a href="user_dashboard.php"
           class="<?= ($current=='user_dashboard.php') ? 'active' : ''; ?>">
            <i class="fa-solid fa-house"></i>
            Dashboard
        </a>

        <a href="user_reviewmaterials.php"
           class="<?= ($current=='user_reviewmaterials.php') ? 'active' : ''; ?>">
            <i class="fa-solid fa-book-open"></i>
            Review Materials
        </a>

        <a href="user_practicequizzes.php"
           class="<?= ($current=='user_practicequizzes.php') ? 'active' : ''; ?>">
            <i class="fa-solid fa-pen-to-square"></i>
            Practice Quizzes
        </a>

        <a href="user_mockexamination.php"
           class="<?= ($current=='user_mockexamination.php') ? 'active' : ''; ?>">
            <i class="fa-solid fa-clipboard-list"></i>
            Mock Examination
        </a>

        <a href="user_myresults.php"
           class="<?= ($current=='user_myresults.php') ? 'active' : ''; ?>">
            <i class="fa-solid fa-square-poll-vertical"></i>
            My Results
        </a>

        <a href="user_myperformance.php"
           class="<?= ($current=='user_myperformance.php') ? 'active' : ''; ?>">
            <i class="fa-solid fa-chart-line"></i>
            My Performance
        </a>

        <a href="user_epermit.php"
           class="<?= ($current=='user_epermit.php') ? 'active' : ''; ?>">
            <i class="fa-solid fa-id-card"></i>
            E-Permit
        </a>

        <a href="user_profile.php"
           class="<?= ($current=='user_profile.php') ? 'active' : ''; ?>">
            <i class="fa-solid fa-user"></i>
            Profile
        </a>

        <a href="../logout.php"
           class="logout"
           onclick="return confirm('Are you sure you want to logout?');">
            <i class="fa-solid fa-right-from-bracket"></i>
            Logout
        </a>

    </nav>

</aside>

<script>

const sidebar = document.getElementById("sidebar");
const overlay = document.getElementById("overlay");

function toggleSidebar(){

    sidebar.classList.toggle("show");
    overlay.classList.toggle("show");

}

function closeSidebar(){

    sidebar.classList.remove("show");
    overlay.classList.remove("show");

}

window.addEventListener("resize",function(){

    if(window.innerWidth > 768){

        closeSidebar();

    }

});

</script>