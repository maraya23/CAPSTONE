<?php

session_start();

require_once "../connection.php";

// Check user login
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION["user_id"];

/*=====================================
    SEARCH & FILTER
======================================*/

$assessment = "";
$search = "";

$where = "WHERE user_id = ?";

$params = [];
$params[] = $user_id;

$types = "i";

if(isset($_GET['assessment']) && $_GET['assessment'] != ""){

    $assessment = $_GET['assessment'];

    $where .= " AND assessment_type=?";

    $params[] = $assessment;

    $types .= "s";

}

if(isset($_GET['search']) && trim($_GET['search']) != ""){

    $search = trim($_GET['search']);

    $where .= " AND assessment_name LIKE ?";

    $params[] = "%".$search."%";

    $types .= "s";

}

/*=====================================
    TESTS TAKEN
======================================*/

$sql = "SELECT COUNT(*) total
        FROM assessment_results
        WHERE user_id=?";

$stmt = mysqli_prepare($conn,$sql);

mysqli_stmt_bind_param($stmt,"i",$user_id);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

$row = mysqli_fetch_assoc($result);

$totalTests = $row['total'] ?? 0;

/*=====================================
    AVERAGE SCORE
======================================*/

$sql = "SELECT AVG(percentage) averageScore
        FROM assessment_results
        WHERE user_id=?";

$stmt = mysqli_prepare($conn,$sql);

mysqli_stmt_bind_param($stmt,"i",$user_id);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

$row = mysqli_fetch_assoc($result);

$averageScore = $row['averageScore'];

if(!$averageScore){

    $averageScore = 0;

}

$averageScore = round($averageScore,1);

/*=====================================
    HIGHEST SCORE
======================================*/

$sql = "SELECT MAX(percentage) highestScore
        FROM assessment_results
        WHERE user_id=?";

$stmt = mysqli_prepare($conn,$sql);

mysqli_stmt_bind_param($stmt,"i",$user_id);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

$row = mysqli_fetch_assoc($result);

$highestScore = $row['highestScore'];

if(!$highestScore){

    $highestScore = 0;

}

$highestScore = round($highestScore,1);

/*=====================================
    LAST ACTIVITY
======================================*/

$sql = "SELECT date_taken
        FROM assessment_results
        WHERE user_id=?
        ORDER BY date_taken DESC
        LIMIT 1";

$stmt = mysqli_prepare($conn,$sql);

mysqli_stmt_bind_param($stmt,"i",$user_id);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

$row = mysqli_fetch_assoc($result);

if($row){

    $lastActivity = date("M d, Y",strtotime($row['date_taken']));

}else{

    $lastActivity = "No Activity";

}

/*=====================================
    RECENT ACHIEVEMENT
======================================*/

$sql = "SELECT *
        FROM assessment_results
        WHERE user_id=?
        ORDER BY date_taken DESC
        LIMIT 1";

$stmt = mysqli_prepare($conn,$sql);

mysqli_stmt_bind_param($stmt,"i",$user_id);

mysqli_stmt_execute($stmt);

$latestResult = mysqli_stmt_get_result($stmt);

$latest = mysqli_fetch_assoc($latestResult);

/*=====================================
    HISTORY TABLE
======================================*/

$sql = "SELECT *
        FROM assessment_results
        $where
        ORDER BY date_taken DESC";

$stmt = mysqli_prepare($conn,$sql);

mysqli_stmt_bind_param($stmt,$types,...$params);

mysqli_stmt_execute($stmt);

$history = mysqli_stmt_get_result($stmt);

/*=====================================
    PROGRESS CIRCLE
======================================*/

$circleDegrees = ($averageScore / 100) * 360;

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>My Results</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css">

<?php include "user_sidebar.php"; ?>

<style>

/*====================================
    GENERAL
====================================*/

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    background:#f4f7fc;
}

.main-content{
    margin-left:230px;
    padding:30px;
    min-height:100vh;
}

/*====================================
    PAGE HEADER
====================================*/

.page-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:30px;
}

.page-header h1{
    font-size:32px;
    font-weight:700;
    color:#0A2F73;
    margin-bottom:6px;
}

.page-header p{
    color:#6b7280;
    font-size:15px;
}

/*====================================
    SUMMARY GRID
====================================*/

.summary-grid{

    display:grid;

    grid-template-columns:repeat(4,1fr);

    gap:20px;

    margin-bottom:30px;

}

.summary-card{

    background:#fff;

    border-radius:18px;

    padding:22px;

    display:flex;

    align-items:center;

    gap:18px;

    box-shadow:0 8px 25px rgba(0,0,0,.08);

    transition:.3s;

}

.summary-card:hover{

    transform:translateY(-5px);

    box-shadow:0 12px 30px rgba(37,99,235,.15);

}

.summary-card h2{

    font-size:28px;

    color:#111827;

    margin-bottom:5px;

}

.summary-card p{

    color:#6b7280;

    font-size:14px;

}

.summary-icon{

    width:65px;

    height:65px;

    border-radius:16px;

    display:flex;

    justify-content:center;

    align-items:center;

    font-size:28px;

    color:#fff;

}

.blue{

    background:linear-gradient(135deg,#2563eb,#3b82f6);

}

.green{

    background:linear-gradient(135deg,#10b981,#34d399);

}

.orange{

    background:linear-gradient(135deg,#f59e0b,#fbbf24);

}

.purple{

    background:linear-gradient(135deg,#7c3aed,#8b5cf6);

}

/*====================================
    MAIN GRID
====================================*/

.content-grid{

    display:grid;

    grid-template-columns:2fr 1fr;

    gap:25px;

}

/*====================================
    CARD
====================================*/

.card{

    background:#fff;

    border-radius:18px;

    padding:25px;

    box-shadow:0 8px 25px rgba(0,0,0,.08);

}

.card-title{

    display:flex;

    justify-content:space-between;

    align-items:center;

    margin-bottom:25px;

}

.card-title h2{

    color:#0A2F73;

    font-size:22px;

}

.card-title i{

    color:#2563eb;

    margin-right:8px;

}

/*====================================
    FILTER
====================================*/

.filter-box{

    display:flex;

    gap:12px;

    margin-bottom:25px;

    flex-wrap:wrap;

}

.filter-box select{

    width:220px;

    padding:12px;

    border:1px solid #d1d5db;

    border-radius:12px;

    outline:none;

    background:#fff;

}

.filter-box input{

    flex:1;

    min-width:220px;

    padding:12px;

    border:1px solid #d1d5db;

    border-radius:12px;

    outline:none;

}

.filter-box input:focus,
.filter-box select:focus{

    border-color:#2563eb;

}

.filter-box button{

    width:50px;

    border:none;

    border-radius:12px;

    background:#2563eb;

    color:#fff;

    cursor:pointer;

    transition:.3s;

}

.filter-box button:hover{

    background:#1d4ed8;

}
    
    /*====================================
    TABLE
====================================*/

.table-responsive{

    width:100%;

    overflow-x:auto;

}

table{

    width:100%;

    border-collapse:collapse;

    min-width:900px;

}

thead{

    background:#0A2F73;

}

thead th{

    color:#fff;

    padding:16px;

    font-size:14px;

    font-weight:600;

    text-align:left;

}

tbody td{

    padding:16px;

    border-bottom:1px solid #eef2f7;

    color:#374151;

    font-size:14px;

    vertical-align:middle;

}

tbody tr{

    transition:.25s;

}

tbody tr:hover{

    background:#f8fbff;

}

/*====================================
    TABLE ICONS
====================================*/

.icon-blue{

    color:#2563eb;

    margin-right:8px;

}

.icon-green{

    color:#10b981;

    margin-right:8px;

}

/*====================================
    SCORE COLORS
====================================*/

.excellent-score{

    color:#2563eb;

    font-weight:700;

}

.passed-score{

    color:#16a34a;

    font-weight:700;

}

.failed-score{

    color:#dc2626;

    font-weight:700;

}

/*====================================
    STATUS BADGES
====================================*/

.badge{

    display:inline-block;

    padding:6px 14px;

    border-radius:30px;

    font-size:13px;

    font-weight:600;

}

.badge.passed{

    background:#dcfce7;

    color:#15803d;

}

.badge.failed{

    background:#fee2e2;

    color:#dc2626;

}

/*====================================
    VIEW DETAILS BUTTON
====================================*/

.view-btn{

    display:inline-block;

    background:#2563eb;

    color:#fff;

    padding:9px 16px;

    border-radius:10px;

    text-decoration:none;

    font-size:13px;

    font-weight:600;

    transition:.3s;

}

.view-btn:hover{

    background:#1d4ed8;

}

/*====================================
    RIGHT PANEL
====================================*/

.right-section{

    display:flex;

    flex-direction:column;

    gap:22px;

}

/*====================================
    PROGRESS CIRCLE
====================================*/

.progress-circle{

    width:190px;

    height:190px;

    margin:25px auto;

    border-radius:50%;

    display:flex;

    justify-content:center;

    align-items:center;

}

.circle-inner{

    width:145px;

    height:145px;

    border-radius:50%;

    background:#fff;

    display:flex;

    justify-content:center;

    align-items:center;

    font-size:30px;

    font-weight:700;

    color:#0A2F73;

    box-shadow:0 4px 12px rgba(0,0,0,.08);

}

/*====================================
    LEGEND
====================================*/

.legend{

    margin-top:15px;

}

.legend p{

    display:flex;

    align-items:center;

    gap:10px;

    margin-bottom:12px;

    font-size:14px;

    color:#4b5563;

}

.legend span{

    width:15px;

    height:15px;

    border-radius:50%;

    display:inline-block;

}

.legend .excellent{

    background:#2563eb;

}

.legend .passed{

    background:#10b981;

}

.legend .failed{

    background:#f59e0b;

}

/*====================================
    ACHIEVEMENT CARD
====================================*/

.achievement-card{

    text-align:center;

}

.trophy{

    font-size:60px;

    color:#f59e0b;

    margin-bottom:18px;

}

.achievement-card h3{

    color:#0A2F73;

    margin-bottom:12px;

}

.achievement-card h2{

    font-size:40px;

    color:#2563eb;

    margin-bottom:12px;

}

.achievement-card p{

    font-weight:600;

    color:#111827;

    margin-bottom:10px;

}

.achievement-card span{

    color:#6b7280;

    line-height:1.7;

}

/*====================================
    EMPTY STATE
====================================*/

.empty-state{

    padding:50px 20px;

    text-align:center;

}

.empty-state i{

    font-size:60px;

    color:#2563eb;

    margin-bottom:15px;

}

.empty-state h3{

    color:#0A2F73;

    margin-bottom:10px;

}

.empty-state p{

    color:#6b7280;

    line-height:1.6;

}
    
    .left-section{
    width:100%;
    min-width:0;
}

.right-section{
    width:100%;
}
    
  /* ===============================
   TABLET
================================ */

@media (max-width:992px){

    .summary-grid{
        grid-template-columns:repeat(2,1fr);
    }

    .content-grid{
        grid-template-columns:1fr;
    }

    .right-section{
        display:grid;
        grid-template-columns:repeat(2,1fr);
        gap:20px;
    }

}

/* ===============================
   MOBILE
================================ */

@media (max-width:768px){

    .main-content{
        margin-left:0;
        padding:85px 15px 20px;
    }

    .page-header{
        margin-bottom:20px;
    }

    .page-header h1{
        font-size:26px;
    }

    .page-header p{
        font-size:14px;
    }

    .summary-grid{
        grid-template-columns:1fr;
        gap:15px;
    }

    .summary-card{
        width:100%;
        padding:18px;
    }

    .summary-card h2{
        font-size:24px;
    }

    .summary-icon{
        width:55px;
        height:55px;
        font-size:22px;
    }

    .content-grid{
        display:flex;
        flex-direction:column;
        gap:20px;
    }

    .left-section,
    .right-section{
        width:100%;
    }

    .card{
        padding:18px;
        border-radius:16px;
    }

    .filter-box{
        display:flex;
        flex-direction:column;
        gap:12px;
    }

    .filter-box select,
    .filter-box input,
    .filter-box button{
        width:100%;
    }

    .filter-box button{
        height:46px;
    }

    .table-responsive{
        overflow-x:auto;
        -webkit-overflow-scrolling:touch;
    }

   table{
    width:100%;
    min-width:700px;
}

    .progress-circle{
        width:160px;
        height:160px;
    }

    .circle-inner{
        width:120px;
        height:120px;
        font-size:24px;
    }

    .achievement-card{
        text-align:center;
    }

    .achievement-card h2{
        font-size:34px;
    }

}

/* ===============================
   SMALL PHONES
================================ */

@media (max-width:480px){

    .main-content{
        padding:80px 12px 15px;
    }

    .page-header h1{
        font-size:22px;
    }

    .summary-card{
        padding:15px;
    }

    .summary-card h2{
        font-size:21px;
    }

    .summary-card p{
        font-size:13px;
    }

    .card{
        padding:15px;
    }

    .progress-circle{
        width:140px;
        height:140px;
    }

    .circle-inner{
        width:105px;
        height:105px;
        font-size:21px;
    }

}
    /* Smooth animations */

body{

opacity:0;

transition:.35s;

}

body.loaded{

opacity:1;

}

.summary-card{

transition:.3s ease;

}

.card{

transition:.3s ease;

}

.view-btn{

transition:.25s;

}

.filter-box button{

transition:.25s;

}

</style>

</head>

<body>

<div class="main-content">

    <!-- =========================
            PAGE HEADER
    ========================== -->

    <div class="page-header">

        <div>

            <h1>My Results</h1>

            <p>
                View your assessment history and monitor your academic progress.
            </p>

        </div>

    </div>



    <!-- =========================
            SUMMARY CARDS
    ========================== -->

    <div class="summary-grid">

        <div class="summary-card">

            <div class="summary-icon blue">

                <i class="fa-solid fa-file-circle-check"></i>

            </div>

            <div>

                <h2><?= $totalTests ?></h2>

                <p>Tests Taken</p>

            </div>

        </div>



        <div class="summary-card">

            <div class="summary-icon green">

                <i class="fa-solid fa-chart-column"></i>

            </div>

            <div>

                <h2><?= number_format($averageScore,1) ?>%</h2>

                <p>Average Score</p>

            </div>

        </div>



        <div class="summary-card">

            <div class="summary-icon orange">

                <i class="fa-solid fa-trophy"></i>

            </div>

            <div>

                <h2><?= number_format($highestScore,1) ?>%</h2>

                <p>Highest Score</p>

            </div>

        </div>



        <div class="summary-card">

            <div class="summary-icon purple">

                <i class="fa-solid fa-clock"></i>

            </div>

            <div>

                <h2><?= $lastActivity ?></h2>

                <p>Last Activity</p>

            </div>

        </div>

    </div>



    <!-- =========================
            MAIN CONTENT
    ========================== -->

    <div class="content-grid">




        <!-- =========================
            LEFT SIDE
        ========================== -->

        <div class="left-section">

            <div class="card">

                <div class="card-title">

                    <h2>

                        <i class="fa-solid fa-list-check"></i>

                        Results History

                    </h2>

                </div>



                <!-- FILTERS -->

                <form method="GET" class="filter-box">

                    <select name="assessment">

                        <option value="">All Assessments</option>

                        <option value="Practice Quiz"

                        <?= ($assessment=="Practice Quiz") ? "selected" : "" ?>>

                        Practice Quiz

                        </option>

                        <option value="Mock Examination"

                        <?= ($assessment=="Mock Examination") ? "selected" : "" ?>>

                        Mock Examination

                        </option>

                    </select>



                    <input

                    type="text"

                    name="search"

                    placeholder="Search assessment..."

                    value="<?= htmlspecialchars($search) ?>">



                    <button type="submit">

                        <i class="fa-solid fa-search"></i>

                    </button>

                </form>



                <!-- TABLE -->

                <div class="table-responsive">

                <table>

                    <thead>

                    <tr>

                        <th>Date</th>

                        <th>Assessment</th>

                        <th>Name</th>

                        <th>Score</th>

                        <th>%</th>

                        <th>Status</th>

                        <th>Action</th>

                    </tr>

                    </thead>

                    <tbody>

                    <?php

                    if(mysqli_num_rows($history)>0):

                    while($row=mysqli_fetch_assoc($history)):

                    ?>

                    <tr>

                        <td>

                            <?= date("M d, Y",strtotime($row['date_taken'])) ?>

                        </td>

                        <td>

                        <?php

                        if($row['assessment_type']=="Practice Quiz"){

                            echo '<i class="fa-solid fa-pen-to-square icon-blue"></i> Practice Quiz';

                        }else{

                            echo '<i class="fa-solid fa-clipboard-list icon-green"></i> Mock Examination';

                        }

                        ?>

                        </td>

                        <td>

                            <?= htmlspecialchars($row['assessment_name']) ?>

                        </td>

                        <td>

                            <?= $row['score'] ?>/<?= $row['total_items'] ?>

                        </td>

                        <td>

                        <?php

                        if($row['percentage']>=90){

                            $class="excellent-score";

                        }elseif($row['percentage']>=75){

                            $class="passed-score";

                        }else{

                            $class="failed-score";

                        }

                        ?>

                        <span class="<?= $class ?>">

                            <?= number_format($row['percentage'],1) ?>%

                        </span>

                        </td>

                        <td>

                            <span class="badge <?= strtolower($row['remarks']) ?>">

                                <?= $row['remarks'] ?>

                            </span>

                        </td>

                        <td>

                            <a

                            href="user_resultdetails.php?id=<?= $row['id'] ?>"

                            class="view-btn">

                            View Details

                            </a>

                        </td>

                    </tr>

                    <?php

                    endwhile;

                    else:

                    ?>

                    <tr>

                        <td colspan="7">

                            <div class="empty-state">

                                <i class="fa-solid fa-folder-open"></i>

                                <h3>No Results Yet</h3>

                                <p>

                                    Complete a Practice Quiz or Mock Examination to see your assessment history.

                                </p>

                            </div>

                        </td>

                    </tr>

                    <?php endif; ?>

                    </tbody>

                </table>

                </div>

            </div>

        </div>



        <!-- =========================
            RIGHT SIDE
        ========================== -->

        <div class="right-section">

            <div class="card">

                <h3>Average Score</h3>

                <div

                class="progress-circle"

                style="background:
                conic-gradient(
                #2563eb <?= $circleDegrees ?>deg,
                #e5e7eb <?= $circleDegrees ?>deg
                );">

                    <div class="circle-inner">

                        <?= number_format($averageScore,1) ?>%

                    </div>

                </div>

                <div class="legend">

                    <p><span class="excellent"></span> Excellent (90-100%)</p>

                    <p><span class="passed"></span> Passed (75-89%)</p>

                    <p><span class="failed"></span> Needs Improvement</p>

                </div>

            </div>



            <div class="card achievement-card">

                <i class="fa-solid fa-trophy trophy"></i>

                <h3>Recent Achievement</h3>

                <?php if($latest){ ?>

                    <h2><?= number_format($latest['percentage'],1) ?>%</h2>

                    <p>

                        <?= htmlspecialchars($latest['assessment_name']) ?>

                    </p>

                    <span>

                        <?= htmlspecialchars($latest['remarks']) ?>

                    </span>

                <?php }else{ ?>

                    <p>No assessments completed yet.</p>

                <?php } ?>

            </div>

        </div>

    </div>

</div>

    <script>

// =====================================
// PAGE LOADING ANIMATION
// =====================================

window.addEventListener("load",function(){

    document.body.classList.add("loaded");

});

// =====================================
// SUMMARY CARD HOVER EFFECT
// =====================================

const cards=document.querySelectorAll(".summary-card");

cards.forEach(function(card){

    card.addEventListener("mouseenter",function(){

        card.style.transform="translateY(-6px)";

    });

    card.addEventListener("mouseleave",function(){

        card.style.transform="translateY(0px)";

    });

});

// =====================================
// TABLE ROW HOVER
// =====================================

const rows=document.querySelectorAll("tbody tr");

rows.forEach(function(row){

    row.addEventListener("mouseenter",function(){

        row.style.transition=".25s";

    });

});

// =====================================
// SEARCH AUTO SUBMIT
// =====================================

const search=document.querySelector("input[name='search']");

if(search){

search.addEventListener("keypress",function(e){

    if(e.key==="Enter"){

        this.form.submit();

    }

});

}

// =====================================
// FILTER AUTO SUBMIT
// =====================================

const filter=document.querySelector("select[name='assessment']");

if(filter){

filter.addEventListener("change",function(){

    this.form.submit();

});

}

// =====================================
// CONFIRM VIEW DETAILS (Optional)
// =====================================

const buttons=document.querySelectorAll(".view-btn");

buttons.forEach(function(button){

button.addEventListener("click",function(e){

    // Reserved for future enhancements

});

});

</script>
    
</body>

</html>