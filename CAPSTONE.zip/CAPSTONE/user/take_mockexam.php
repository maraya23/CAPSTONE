<?php

error_reporting(E_ALL);
ini_set('display_errors',1);

session_start();

require_once "../connection.php";


/* ==========================================
   CHECK LOGIN
========================================== */

if(!isset($_SESSION["user_id"])){

    header("Location: ../login.php");
    exit();

}


$user_id = $_SESSION["user_id"];



/* ==========================================
   CHECK ACTIVE PERMIT
========================================== */

if(
    !isset($_SESSION["permit_id"]) ||
    !isset($_SESSION["exam_id"])
){

    header("Location: user_mockexamination.php");
    exit();

}


$permit_id = $_SESSION["permit_id"];
$exam_id   = $_SESSION["exam_id"];




/* ==========================================
   VERIFY PERMIT
========================================== */

$sql = "

SELECT

ep.permit_id,
ep.permit_number,
ep.exam_id,
ep.user_id,
e.title

FROM e_permits ep

INNER JOIN exams e

ON ep.exam_id = e.exam_id

WHERE

ep.permit_id = ?

AND ep.user_id = ?

AND ep.exam_id = ?

LIMIT 1

";


$stmt = mysqli_prepare($conn,$sql);


mysqli_stmt_bind_param(
    $stmt,
    "iii",
    $permit_id,
    $user_id,
    $exam_id
);


mysqli_stmt_execute($stmt);


$result = mysqli_stmt_get_result($stmt);



if(mysqli_num_rows($result)==0){


    unset($_SESSION["permit_id"]);
    unset($_SESSION["exam_id"]);


    header("Location:user_mockexamination.php");
    exit();

}


$permitData = mysqli_fetch_assoc($result);





/* ==========================================
   LOAD EXAM DETAILS
========================================== */


$sql = "

SELECT

exam_id,
title,
description,
duration,
total_questions,
passing_score,
category_id

FROM exams

WHERE exam_id=?

LIMIT 1

";


$stmt = mysqli_prepare($conn,$sql);


mysqli_stmt_bind_param(
    $stmt,
    "i",
    $exam_id
);


mysqli_stmt_execute($stmt);


$examResult = mysqli_stmt_get_result($stmt);



if(mysqli_num_rows($examResult)==0){

    die("Examination not found.");

}



$exam = mysqli_fetch_assoc($examResult);





/* ==========================================
   CHECK IF ALREADY SUBMITTED
========================================== */


$sql = "

SELECT remarks

FROM exam_attempts

WHERE user_id=?

AND exam_id=?

AND remarks IN ('Passed','Failed')

ORDER BY attempt_id DESC

LIMIT 1

";


$stmt=mysqli_prepare($conn,$sql);


mysqli_stmt_bind_param(
    $stmt,
    "ii",
    $user_id,
    $exam_id
);


mysqli_stmt_execute($stmt);


$finishedCheck=mysqli_stmt_get_result($stmt);



if(mysqli_num_rows($finishedCheck)>0){

    die("This examination has already been completed.");

}







/* ==========================================
   CHECK EXISTING EXAM ATTEMPT
   PREVENT DUPLICATE ATTEMPT
========================================== */


$sql = "

SELECT

attempt_id,

end_time

FROM exam_attempts

WHERE user_id=?

AND exam_id=?

ORDER BY attempt_id DESC

LIMIT 1

";



$stmt=mysqli_prepare($conn,$sql);



mysqli_stmt_bind_param(

    $stmt,

    "ii",

    $user_id,

    $exam_id

);



mysqli_stmt_execute($stmt);



$attemptCheck=mysqli_stmt_get_result($stmt);





if(mysqli_num_rows($attemptCheck)>0){


    $existingAttempt=mysqli_fetch_assoc($attemptCheck);




    /*
       IF ALREADY SUBMITTED
    */


    if(!empty($existingAttempt["end_time"])){


        unset($_SESSION["permit_id"]);

        unset($_SESSION["exam_id"]);

        unset($_SESSION["attempt_id"]);

        unset($_SESSION["mock_exam"]);

        unset($_SESSION["answers"]);



        header(
            "Location:user_mockexamination.php"
        );

        exit();


    }




    /*
       CONTINUE EXISTING EXAM
    */


    $_SESSION["attempt_id"] =
    $existingAttempt["attempt_id"];



}

else{



    /*
       CREATE NEW ATTEMPT
    */


    $start_time=date("Y-m-d H:i:s");


    $score=0;

    $percentage=0;


    /*
       Use Ongoing temporarily
    */

    $remarks="Ongoing";




    $sql="

    INSERT INTO exam_attempts

    (

        user_id,

        exam_id,

        start_time,

        score,

        total_questions,

        percentage,

        remarks

    )

    VALUES

    (?,?,?,?,?,?,?)

    ";



    $stmt=mysqli_prepare($conn,$sql);



    mysqli_stmt_bind_param(

        $stmt,

        "iisiiis",

        $user_id,

        $exam_id,

        $start_time,

        $score,

        $exam["total_questions"],

        $percentage,

        $remarks

    );



    mysqli_stmt_execute($stmt);



    $_SESSION["attempt_id"] =
    mysqli_insert_id($conn);



}




$attempt_id=$_SESSION["attempt_id"];






/* ==========================================
   GET REAL START TIME
========================================== */


$sql="

SELECT start_time

FROM exam_attempts

WHERE attempt_id=?

LIMIT 1

";


$stmt=mysqli_prepare($conn,$sql);


mysqli_stmt_bind_param(
    $stmt,
    "i",
    $attempt_id
);


mysqli_stmt_execute($stmt);


$timeResult=mysqli_stmt_get_result($stmt);


$attempt=mysqli_fetch_assoc($timeResult);



$startTime=$attempt["start_time"];






/* ==========================================
   LOAD QUESTIONS ONCE
   FROM EXAM ITEMS
========================================== */


if(!isset($_SESSION["mock_exam"])){


    $sql="

    SELECT

    q.question_id,

    q.question,

    q.option_a,

    q.option_b,

    q.option_c,

    q.option_d,

    q.correct_answer

    FROM exam_items ei

    INNER JOIN questions q

    ON ei.question_id=q.question_id

    WHERE ei.exam_id=?

    ORDER BY RAND()

    ";


    $stmt=mysqli_prepare($conn,$sql);


    mysqli_stmt_bind_param(
        $stmt,
        "i",
        $exam_id
    );


    mysqli_stmt_execute($stmt);


    $questionResult=mysqli_stmt_get_result($stmt);



    $questions=[];


    while($row=mysqli_fetch_assoc($questionResult)){


        $questions[]=$row;


    }



    if(count($questions)==0){

        die("No questions assigned to this examination.");

    }



    $limit=(int)$exam["total_questions"];



    if(count($questions)>$limit){


        $questions=array_slice(
            $questions,
            0,
            $limit
        );


    }



    $_SESSION["mock_exam"]=$questions;


}



$questions=$_SESSION["mock_exam"];


$totalQuestions=count($questions);






/* ==========================================
   ANSWERS STORAGE
========================================== */


if(!isset($_SESSION["answers"])){

    $_SESSION["answers"]=[];

}






/* ==========================================
   CURRENT QUESTION
========================================== */


$current = isset($_GET["q"])
? intval($_GET["q"])
: 1;



if($current < 1){

    $current=1;

}


if($current > $totalQuestions){

    $current=$totalQuestions;

}





/* ==========================================
   SAVE ANSWER
========================================== */


if($_SERVER["REQUEST_METHOD"]=="POST"){



    if(isset($_POST["answer"])){

        $_SESSION["answers"][$current]
        =
        $_POST["answer"];

    }




    if(isset($_POST["previous"])){

        header(
            "Location: take_mockexam.php?q=".($current-1)
        );

        exit();

    }





    if(isset($_POST["next"])){

        header(
            "Location: take_mockexam.php?q=".($current+1)
        );

        exit();

    }





    if(isset($_POST["submit_exam"])){

        header(
            "Location: submit_mockexam.php"
        );

        exit();

    }


}





$question=$questions[$current-1];


?>

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">


<title>

<?= htmlspecialchars($exam["title"]); ?>

</title>


<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">


<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css">



<style>


/* ==========================================
   GLOBAL
========================================== */

*{

    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;

}



body{

    background:#f3f6fb;

}





/* ==========================================
   MAIN CONTENT
========================================== */


.main-content{

    margin-left:230px;

    padding:30px;

    min-height:100vh;

}





/* ==========================================
   EXAM HEADER
========================================== */


.top-bar{


    background:white;

    border-radius:18px;

    padding:25px;

    display:flex;

    justify-content:space-between;

    align-items:center;

    gap:20px;

    margin-bottom:25px;

    box-shadow:0 8px 25px rgba(0,0,0,.08);


}



.exam-title{


    color:#0A2F73;

    font-size:24px;

    font-weight:700;


}



.exam-title i{


    color:#2563eb;

    margin-right:10px;


}





.exam-info{


    display:flex;

    gap:12px;

    flex-wrap:wrap;

    margin-top:12px;


}





.info-badge{


    background:#eef4ff;

    color:#2563eb;

    padding:8px 14px;

    border-radius:20px;

    font-size:13px;

    font-weight:600;


}





.timer-box{


    background:#eaf2ff;

    color:#2563eb;

    padding:15px 22px;

    border-radius:14px;

    font-size:18px;

    font-weight:700;


}



.timer-box i{


    margin-right:8px;


}








/* ==========================================
   EXAM LAYOUT
========================================== */


.exam-wrapper{


    display:grid;

    grid-template-columns:280px 1fr;

    gap:25px;


}








/* ==========================================
   QUESTION NAVIGATOR
========================================== */


.navigator{


    background:white;

    padding:25px;

    border-radius:18px;

    box-shadow:0 8px 25px rgba(0,0,0,.08);


}




.navigator h3{


    color:#0A2F73;

    margin-bottom:20px;

    font-size:20px;


}





.number-grid{


    display:grid;

    grid-template-columns:repeat(5,1fr);

    gap:10px;


}




.number-grid a{


    width:42px;

    height:42px;

    display:flex;

    justify-content:center;

    align-items:center;

    text-decoration:none;

    border-radius:10px;

    background:#eef2f7;

    color:#374151;

    font-weight:600;


}





.number-grid a:hover{


    background:#dbeafe;


}





.number-grid a.current{


    background:#2563eb;

    color:white;


}




.number-grid a.answered{


    background:#22c55e;

    color:white;


}







/* ==========================================
   QUESTION CARD
========================================== */


.question-card{


    background:white;

    border-radius:18px;

    padding:35px;

    box-shadow:0 8px 25px rgba(0,0,0,.08);


}







.question-number{


    color:#2563eb;

    font-weight:600;

    margin-bottom:15px;


}





.question-card h2{


    font-size:24px;

    color:#111827;

    line-height:1.6;

    margin-bottom:30px;


}








/* ==========================================
   ANSWER CHOICES
========================================== */


.choice{


    display:flex;

    align-items:flex-start;

    gap:12px;

    padding:18px;

    margin-bottom:15px;

    background:#f8fafc;

    border-radius:12px;

    border:2px solid transparent;

    cursor:pointer;

    transition:.25s;


}




.choice:hover{


    background:#eef4ff;

    border-color:#2563eb;


}





.choice input{


    margin-top:5px;

    transform:scale(1.2);


}








/* ==========================================
   BUTTONS
========================================== */


.button-group{


    display:flex;

    justify-content:space-between;

    align-items:center;

    margin-top:35px;


}





button{


    border:none;

    cursor:pointer;

    padding:14px 25px;

    border-radius:12px;

    font-size:15px;

    font-weight:600;


}





.prev-btn{


    background:#64748b;

    color:white;


}



.prev-btn:hover{


    background:#475569;


}







.next-btn{


    background:#2563eb;

    color:white;


}




.next-btn:hover{


    background:#1d4ed8;


}







.submit-btn{


    background:#16a34a;

    color:white;


}





.submit-btn:hover{


    background:#15803d;


}









/* ==========================================
   MOBILE RESPONSIVE
========================================== */


@media(max-width:768px){



.main-content{


    margin-left:0;

    padding:85px 15px 20px;


}





.top-bar{


    flex-direction:column;

    align-items:flex-start;


}





.exam-wrapper{


    grid-template-columns:1fr;


}





.navigator{


    order:2;


}





.question-card{


    order:1;


}





.question-card h2{


    font-size:20px;


}



}



</style>


</head>

<body>


<?php include "user_sidebar.php"; ?>



<div class="main-content">



<!-- ==========================================
     EXAM HEADER
========================================== -->


<div class="top-bar">



<div>


<div class="exam-title">


<i class="fa-solid fa-file-circle-check"></i>


<?= htmlspecialchars($exam["title"]); ?>


</div>





<div class="exam-info">



<div class="info-badge">

<i class="fa-solid fa-clock"></i>

<?= (int)$exam["duration"]; ?> Minutes

</div>





<div class="info-badge">

<i class="fa-solid fa-list"></i>

<?= $totalQuestions; ?> Questions

</div>





<div class="info-badge">

<i class="fa-solid fa-award"></i>

Passing:

<?= (int)$exam["passing_score"]; ?>%

</div>





<div class="info-badge">

<i class="fa-solid fa-id-card"></i>

<?= htmlspecialchars($permitData["permit_number"]); ?>

</div>




</div>


</div>






<div class="timer-box">


<i class="fa-solid fa-stopwatch"></i>


<span id="timer">

Loading...

</span>



</div>





</div>









<!-- ==========================================
     EXAM CONTENT
========================================== -->


<div class="exam-wrapper">







<!-- ==========================================
     QUESTION NAVIGATOR
========================================== -->


<div class="navigator">



<h3>

<i class="fa-solid fa-list-ol"></i>

Questions

</h3>





<div class="number-grid">



<?php


for($i=1;$i<=$totalQuestions;$i++){


$class="";



if($i==$current){


    $class="current";


}

elseif(isset($_SESSION["answers"][$i])){


    $class="answered";


}


?>



<a

href="take_mockexam.php?q=<?= $i; ?>"

class="<?= $class; ?>"

>


<?= $i; ?>


</a>



<?php

}

?>



</div>




</div>









<!-- ==========================================
     QUESTION CARD
========================================== -->


<div class="question-card">





<div class="question-number">


Question <?= $current; ?>

of <?= $totalQuestions; ?>


</div>







<h2>


<?= htmlspecialchars($question["question"]); ?>


</h2>







<form method="POST">







<!-- OPTION A -->


<label class="choice">



<input

type="radio"

name="answer"

value="A"


<?=

(($_SESSION["answers"][$current] ?? "")=="A")

?

"checked"

:

"";

?>

>


<strong>A.</strong>


<?= htmlspecialchars($question["option_a"]); ?>


</label>










<!-- OPTION B -->


<label class="choice">



<input

type="radio"

name="answer"

value="B"


<?=

(($_SESSION["answers"][$current] ?? "")=="B")

?

"checked"

:

"";

?>

>


<strong>B.</strong>


<?= htmlspecialchars($question["option_b"]); ?>


</label>










<!-- OPTION C -->


<label class="choice">



<input

type="radio"

name="answer"

value="C"


<?=

(($_SESSION["answers"][$current] ?? "")=="C")

?

"checked"

:

"";

?>

>


<strong>C.</strong>


<?= htmlspecialchars($question["option_c"]); ?>


</label>










<!-- OPTION D -->


<label class="choice">



<input

type="radio"

name="answer"

value="D"


<?=

(($_SESSION["answers"][$current] ?? "")=="D")

?

"checked"

:

"";

?>

>


<strong>D.</strong>


<?= htmlspecialchars($question["option_d"]); ?>


</label>









<!-- BUTTON AREA -->


<div class="button-group">





<?php if($current > 1){ ?>


<button

type="submit"

name="previous"

class="prev-btn"

>


<i class="fa-solid fa-arrow-left"></i>


Previous


</button>



<?php }else{ ?>


<div></div>


<?php } ?>









<?php if($current < $totalQuestions){ ?>



<button

type="submit"

name="next"

class="next-btn"

>


Next


<i class="fa-solid fa-arrow-right"></i>


</button>




<?php }else{ ?>



<button

type="submit"

name="submit_exam"

class="submit-btn"

>


<i class="fa-solid fa-paper-plane"></i>


Submit Examination


</button>




<?php } ?>







</div>








</form>







</div>







</div>







</div>
    
    <script>


/* ==========================================
   REAL EXAM TIMER
   DATABASE START TIME BASED
========================================== */


let startTime = new Date(
    "<?= $startTime; ?>"
).getTime();



let duration = 
<?= (int)$exam["duration"]; ?> * 60 * 1000;



let endTime = startTime + duration;



const timer = document.getElementById("timer");



function updateTimer(){


    let now = new Date().getTime();


    let remaining = endTime - now;





    if(remaining <= 0){



        timer.innerHTML="00:00:00";


        clearInterval(countdown);



        alert(
            "Time is up! Your examination will now be submitted."
        );



        let form = document.querySelector(
            ".question-card form"
        );



        let submitInput=document.createElement("input");


        submitInput.type="hidden";

        submitInput.name="submit_exam";

        submitInput.value="1";



        form.appendChild(submitInput);



        form.submit();



        return;


    }







    let hours=Math.floor(
        remaining / (1000 * 60 * 60)
    );



    let minutes=Math.floor(
        (remaining % (1000 * 60 * 60))
        /
        (1000 * 60)
    );



    let seconds=Math.floor(
        (remaining % (1000 * 60))
        /
        1000
    );





    hours=String(hours).padStart(2,"0");

    minutes=String(minutes).padStart(2,"0");

    seconds=String(seconds).padStart(2,"0");





    timer.innerHTML =

        hours + ":" +

        minutes + ":" +

        seconds;



}





updateTimer();



const countdown=setInterval(
    updateTimer,
    1000
);








/* ==========================================
   HIGHLIGHT SELECTED ANSWER
========================================== */



function highlightAnswer(){



    document
    .querySelectorAll(".choice")
    .forEach(function(choice){



        choice.style.background="#f8fafc";

        choice.style.borderColor="transparent";



    });







    let selected=document.querySelector(
        "input[name='answer']:checked"
    );





    if(selected){



        selected.parentElement.style.background="#eef4ff";


        selected.parentElement.style.borderColor="#2563eb";


    }



}








document
.querySelectorAll("input[name='answer']")
.forEach(function(radio){



    radio.addEventListener(
        "change",
        highlightAnswer
    );



});







window.onload=function(){


    highlightAnswer();


};









/* ==========================================
   FINAL SUBMISSION CONFIRMATION
========================================== */



let submitButton=document.querySelector(
    ".submit-btn"
);





if(submitButton){



    submitButton.addEventListener(
        "click",
        function(event){



            let confirmSubmit=confirm(

                "Are you sure you want to submit your examination?\n\nYou cannot change your answers afterwards."

            );





            if(!confirmSubmit){


                event.preventDefault();


            }



        }

    );



}



</script>



</body>

</html>