<?php
// Enable error reporting to catch any hidden issues instead of a 500 Error
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once "../connection.php";

// Check login
if (!isset($_SESSION["user_id"])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION["user_id"];
$fullname = "User";

// 1. Fetch User Details
$sql_user = "SELECT firstname, middlename, surname FROM logintbl WHERE id = ?";
$stmt = mysqli_prepare($conn, $sql_user);
if ($stmt) {
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if ($row = mysqli_fetch_assoc($result)) {
        $fullname = $row["firstname"] . " " . $row["surname"];
    }
    mysqli_stmt_close($stmt);
}

// Initialize default values to prevent crashes
$quizzes_taken = 0;
$mock_exams = 0;
$highest_score = 0;
$avg_score = 0;
$total_percentage = 0;
$total_attempts_count = 0;
$category_progress = [];
$recent_activity = [];

// 2. Fetch Top Card Statistics using your existing exam_attempts table
try {
    $sql_stats = "
        SELECT 
            e.exam_type,
            r.score,
            r.total_questions
        FROM exam_attempts r
        INNER JOIN exams e ON r.exam_id = e.exam_id
        WHERE r.user_id = ?
    ";
    $stmt = mysqli_prepare($conn, $sql_stats);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "i", $user_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        while ($row = mysqli_fetch_assoc($result)) {
            $total_attempts_count++;
            
            // Calculate percentage for this attempt
            $percentage = ($row['total_questions'] > 0) ? ($row['score'] / $row['total_questions']) * 100 : 0;
            
            // Update highest score
            if ($percentage > $highest_score) {
                $highest_score = $percentage;
            }
            
            // Sum for average
            $total_percentage += $percentage;
            
            // Count by type
            if ($row['exam_type'] == 'Practice Quiz') {
                $quizzes_taken++;
            } elseif ($row['exam_type'] == 'Mock Exam') {
                $mock_exams++;
            }
        }
        
        // Calculate final average
        if ($total_attempts_count > 0) {
            $avg_score = $total_percentage / $total_attempts_count;
        }
        mysqli_stmt_close($stmt);
    }

    // 3. Fetch Category Progress
    $sql_progress = "
        SELECT 
            c.category_name, 
            AVG((r.score / r.total_questions) * 100) as avg_percentage
        FROM exam_attempts r
        INNER JOIN exams e ON r.exam_id = e.exam_id
        INNER JOIN categories c ON e.category_id = c.category_id
        WHERE r.user_id = ? AND r.total_questions > 0
        GROUP BY c.category_id
        LIMIT 5
    ";
    $stmt = mysqli_prepare($conn, $sql_progress);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "i", $user_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        while ($row = mysqli_fetch_assoc($result)) {
            $category_progress[] = $row;
        }
        mysqli_stmt_close($stmt);
    }

    // 4. Fetch Recent Activity
    $sql_activity = "
        SELECT 
            e.title,
            e.exam_type,
            r.score,
            r.total_questions,
            r.start_time
        FROM exam_attempts r
        INNER JOIN exams e ON r.exam_id = e.exam_id
        WHERE r.user_id = ?
        ORDER BY r.start_time DESC
        LIMIT 3
    ";
    
    // 5. Latest Announcements

$announcements = [];

$sql_announcements = "
SELECT
title,
content,
created_at
FROM announcements
WHERE status='Visible'
ORDER BY created_at DESC
LIMIT 5
";

$result = mysqli_query($conn, $sql_announcements);

while($row = mysqli_fetch_assoc($result)){
    $announcements[] = $row;
}
    
    $stmt = mysqli_prepare($conn, $sql_activity);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "i", $user_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        while ($row = mysqli_fetch_assoc($result)) {
            $recent_activity[] = $row;
        }
        mysqli_stmt_close($stmt);
    }
} catch (Exception $e) {
    // If there is a database error, it logs here quietly instead of crashing
    $db_error = $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>User Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
<style>
*{ margin:0; padding:0; box-sizing:border-box; font-family:'Poppins',sans-serif; }
body{ background:#eef3fb; }
.main{ margin-left:230px; padding:30px; min-height:100vh; }
.topbar{ display:flex; justify-content:space-between; align-items:center; margin-bottom:30px; }
.user{ display:flex; align-items:center; gap:15px; }
.user img{ width:45px; height:45px; border-radius:50%; background: #ddd; object-fit:cover; }
.user i{ font-size:20px; color:#666; cursor:pointer; }
.welcome{ margin-bottom:25px; }
.welcome h2{ font-size:28px; color:#222; }
.welcome p{ color:#666; margin-top:5px; }
.cards{ display:grid; grid-template-columns:repeat(4,1fr); gap:20px; margin-bottom:25px; }
.card{ background:white; border-radius:16px; padding:20px; display:flex; align-items:center; gap:18px; box-shadow:0 5px 15px rgba(0,0,0,.06); }
.icon{ width:55px; height:55px; border-radius:50%; display:flex; justify-content:center; align-items:center; font-size:22px; }
.green{ background:#e9f9ef; color:#2ecc71; }
.blue{ background:#ebf3ff; color:#2b7cff; }
.purple{ background:#f2edff; color:#845ef7; }
.orange{ background:#fff3e8; color:#ff922b; }
.card h3{ font-size:13px; color:#666; font-weight:500; }
.card span{ display:block; margin-top:5px; font-size:28px; font-weight:700; }
.bottom{ display:grid; grid-template-columns:2fr 1fr; gap:25px; }
.box{ background:white; border-radius:18px; padding:25px; box-shadow:0 5px 15px rgba(0,0,0,.06); }
.box h3{ margin-bottom:20px; color:#222; }
.progress-wrap{ display:flex; gap:35px; align-items:center; }
.circle{ width:150px; height:150px; border-radius:50%; border:10px solid #2ecc71; display:flex; justify-content:center; align-items:center; font-size:30px; font-weight:700; color:#333; }
.subject{ margin-bottom:18px; }
.subject label{ display:flex; justify-content:space-between; margin-bottom:6px; font-size:14px; }
.bar{ width:100%; height:8px; background:#ddd; border-radius:10px; overflow:hidden; }
.fill{ height:100%; background:#2b7cff; }
.activity{ display:flex; flex-direction:column; gap:18px; }
.item{ display:flex; justify-content:space-between; align-items:center; }
.item p{ font-size:14px; }
.item small{ color:#777; }
.view-btn{ margin-top:20px; float:right; background:#3568E8; color:white; padding:10px 18px; border:none; border-radius:8px; cursor:pointer; }
.empty-state { text-align: center; color: #777; font-size: 14px; margin-top: 10px; }
.error-msg { background: #fee2e2; color: #991b1b; padding: 10px; border-radius: 8px; margin-bottom: 20px; font-size: 14px; }
@media(max-width:768px){
    .main{ margin-left:0; padding:80px 20px 20px; }
    .cards{ grid-template-columns:1fr; }
    .bottom{ grid-template-columns:1fr; }
    .progress-wrap{ flex-direction:column; }
}
</style>
</head>
<body>

<?php include 'user_sidebar.php'; ?>

<div class="main">

    <div class="topbar">
        <div></div>
        <div class="user">
            <i class="fa-regular fa-bell"></i>
            <div style="width:45px; height:45px; border-radius:50%; background:#ccc; display:flex; align-items:center; justify-content:center; color:#fff; font-weight:bold;">
                <i class="fa-solid fa-user"></i>
            </div>
            <strong><?= htmlspecialchars($fullname); ?></strong>
        </div>
    </div>

    <div class="welcome">
        <h2>Welcome back, <?= htmlspecialchars($fullname); ?>! 👋</h2>
        <p>Keep reviewing and you will achieve your goals!</p>
    </div>
    
    <div class="box" style="margin-bottom:25px;">

<h3>
<i class="fa-solid fa-bullhorn"></i>
Latest Announcements
</h3>

<?php if(count($announcements)>0){ ?>

<?php foreach($announcements as $announcement){ ?>

<div style="padding:15px 0;border-bottom:1px solid #eee;">

<strong>
<?= htmlspecialchars($announcement['title']); ?>
</strong>

<p style="margin-top:8px;color:#666;">
<?= htmlspecialchars($announcement['content']); ?>
</p>

<small style="color:#999;">
<?= date("F d, Y",strtotime($announcement['created_at'])); ?>
</small>

</div>

<?php } ?>

<?php }else{ ?>

<p class="empty-state">
No announcements available.
</p>

<?php } ?>

</div>

    <?php if (isset($db_error)): ?>
        <div class="error-msg">
            <strong>Database Notice:</strong> <?= htmlspecialchars($db_error); ?>
        </div>
    <?php endif; ?>

    <div class="cards">
        <div class="card">
            <div class="icon green"><i class="fa-solid fa-file-pen"></i></div>
            <div>
                <h3>Quizzes Taken</h3>
                <span><?= $quizzes_taken; ?></span>
            </div>
        </div>

        <div class="card">
            <div class="icon blue"><i class="fa-solid fa-chart-column"></i></div>
            <div>
                <h3>Average Score</h3>
                <span><?= round($avg_score, 1); ?>%</span>
            </div>
        </div>

        <div class="card">
            <div class="icon purple"><i class="fa-solid fa-clipboard-list"></i></div>
            <div>
                <h3>Mock Exams</h3>
                <span><?= $mock_exams; ?></span>
            </div>
        </div>

        <div class="card">
            <div class="icon orange"><i class="fa-solid fa-star"></i></div>
            <div>
                <h3>Highest Score</h3>
                <span><?= round($highest_score, 1); ?>%</span>
            </div>
        </div>
    </div>

    <div class="bottom">
        <!-- PROGRESS BOX -->
        <div class="box">
            <h3>Your Progress</h3>
            <div class="progress-wrap">
                <div class="circle">
                    <?= round($avg_score, 0); ?>%
                </div>
                
                <div style="flex:1;">
                    <?php if (count($category_progress) > 0): ?>
                        <?php foreach ($category_progress as $cat): ?>
                            <div class="subject">
                                <label>
                                    <span><?= htmlspecialchars($cat['category_name']); ?></span>
                                    <span><?= round($cat['avg_percentage'], 0); ?>%</span>
                                </label>
                                <div class="bar">
                                    <div class="fill" style="width:<?= round($cat['avg_percentage'], 0); ?>%"></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p class="empty-state">No exam data available yet to display progress.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- RECENT ACTIVITY BOX -->
        <div class="box">
            <h3>Recent Activity</h3>
            <div class="activity">
                <?php if (count($recent_activity) > 0): ?>
                    <?php foreach ($recent_activity as $act): ?>
                        <?php 
                            $act_score = $act['score'];
                            $act_total = $act['total_questions'];
                            $act_percentage = ($act_total > 0) ? round(($act_score / $act_total) * 100, 0) : 0;
                            
                            // Format date dynamically
                            $date_display = "Recently";
                            if ($act['start_time']) {
                                $taken_date = new DateTime($act['start_time']);
                                $now = new DateTime();
                                $interval = $now->diff($taken_date);
                                
                                if ($interval->d == 0) {
                                    $date_display = "Today";
                                } elseif ($interval->d == 1) {
                                    $date_display = "Yesterday";
                                } else {
                                    $date_display = $interval->d . " days ago";
                                }
                            }
                        ?>
                        <div class="item">
                            <div>
                                <p><strong><?= htmlspecialchars($act['title']); ?></strong></p>
                                <small>Scored <?= $act_score; ?>/<?= $act_total; ?> (<?= $act_percentage; ?>%)</small>
                            </div>
                            <small><?= $date_display; ?></small>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="empty-state">You haven't taken any exams or quizzes yet.</p>
                <?php endif; ?>
            </div>
            
            <?php if (count($recent_activity) > 0): ?>
                <a href="user_myresults.php"><button class="view-btn">View All</button></a>
            <?php endif; ?>
        </div>
    </div>
</div>

</body>
</html>