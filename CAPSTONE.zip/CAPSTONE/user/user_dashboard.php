<?php

session_start();

require_once "../connection.php";


// Check login

if(!isset($_SESSION["user_id"])){

    header("Location: ../login.php");
    exit();

}



$user_id = $_SESSION["user_id"];


$fullname = "User";



$sql = "SELECT firstname, middlename, surname
        FROM logintbl
        WHERE ID = ?";



$stmt = mysqli_prepare($conn,$sql);



if($stmt){


    mysqli_stmt_bind_param(
        $stmt,
        "i",
        $user_id
    );


    mysqli_stmt_execute($stmt);


    $result = mysqli_stmt_get_result($stmt);



    if($row = mysqli_fetch_assoc($result)){


        $fullname =
        $row["firstname"] . " " .
        $row["surname"];


    }


    mysqli_stmt_close($stmt);


}


?>

<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>User Dashboard</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    background:#eef3fb;
}


/* MAIN CONTENT */

.main{

    margin-left:230px;
    padding:30px;
    min-height:100vh;

}


/* HEADER */

.topbar{

    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:30px;

}

.user{

    display:flex;
    align-items:center;
    gap:15px;

}

.user img{

    width:45px;
    height:45px;
    border-radius:50%;
    object-fit:cover;

}

.user i{

    font-size:20px;
    color:#666;
    cursor:pointer;

}


/* WELCOME */

.welcome{

    margin-bottom:25px;

}

.welcome h2{

    font-size:28px;
    color:#222;

}

.welcome p{

    color:#666;
    margin-top:5px;

}


/* STAT CARDS */

.cards{

    display:grid;
    grid-template-columns:repeat(4,1fr);
    gap:20px;
    margin-bottom:25px;

}

.card{

    background:white;
    border-radius:16px;
    padding:20px;
    display:flex;
    align-items:center;
    gap:18px;
    box-shadow:0 5px 15px rgba(0,0,0,.06);

}

.icon{

    width:55px;
    height:55px;
    border-radius:50%;
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:22px;

}

.green{
    background:#e9f9ef;
    color:#2ecc71;
}

.blue{
    background:#ebf3ff;
    color:#2b7cff;
}

.purple{
    background:#f2edff;
    color:#845ef7;
}

.orange{
    background:#fff3e8;
    color:#ff922b;
}

.card h3{

    font-size:13px;
    color:#666;
    font-weight:500;

}

.card span{

    display:block;
    margin-top:5px;
    font-size:28px;
    font-weight:700;

}


/* LOWER SECTION */

.bottom{

    display:grid;
    grid-template-columns:2fr 1fr;
    gap:25px;

}


/* BOX */

.box{

    background:white;
    border-radius:18px;
    padding:25px;
    box-shadow:0 5px 15px rgba(0,0,0,.06);

}

.box h3{

    margin-bottom:20px;
    color:#222;

}


/* PROGRESS */

.progress-wrap{

    display:flex;
    gap:35px;
    align-items:center;

}

.circle{

    width:150px;
    height:150px;
    border-radius:50%;
    border:10px solid #2ecc71;
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:30px;
    font-weight:700;
    color:#333;

}

.subject{

    margin-bottom:18px;

}

.subject label{

    display:flex;
    justify-content:space-between;
    margin-bottom:6px;
    font-size:14px;

}

.bar{

    width:100%;
    height:8px;
    background:#ddd;
    border-radius:10px;
    overflow:hidden;

}

.fill{

    height:100%;
    background:#2b7cff;

}


/* ACTIVITY */

.activity{

    display:flex;
    flex-direction:column;
    gap:18px;

}

.item{

    display:flex;
    justify-content:space-between;
    align-items:center;

}

.item p{

    font-size:14px;

}

.item small{

    color:#777;

}

.view-btn{

    margin-top:20px;
    float:right;
    background:#3568E8;
    color:white;
    padding:10px 18px;
    border:none;
    border-radius:8px;
    cursor:pointer;

}


/* MOBILE */

@media(max-width:768px){

.main{

margin-left:0;
padding:80px 20px 20px;

}

.cards{

grid-template-columns:1fr;

}

.bottom{

grid-template-columns:1fr;

}

.progress-wrap{

flex-direction:column;

}

}

</style>

</head>

<body>

<?php include 'user_sidebar.php'; ?>

<div class="main">

<div class="topbar">

<div></div>

<div class="user">

<i class="fa-regular fa-bell"></i>

<img src="images/avatar.png">

<strong><?= htmlspecialchars($fullname); ?></strong>

</div>

</div>

<div class="welcome">

<h2>Welcome back, <?= htmlspecialchars($fullname); ?>! 👋</h2>

<p>Keep reviewing and you will achieve your goals!</p>

</div>

<div class="cards">

<div class="card">

<div class="icon green">
<i class="fa-solid fa-file-pen"></i>
</div>

<div>

<h3>Quizzes Taken</h3>

<span>24</span>

</div>

</div>

<div class="card">

<div class="icon blue">
<i class="fa-solid fa-chart-column"></i>
</div>

<div>

<h3>Average Score</h3>

<span>78.4%</span>

</div>

</div>

<div class="card">

<div class="icon purple">
<i class="fa-solid fa-clipboard-list"></i>
</div>

<div>

<h3>Mock Exams</h3>

<span>5</span>

</div>

</div>

<div class="card">

<div class="icon orange">
<i class="fa-solid fa-star"></i>
</div>

<div>

<h3>Highest Score</h3>

<span>92%</span>

</div>

</div>

</div>


<div class="bottom">

<div class="box">

<h3>Your Progress</h3>

<div class="progress-wrap">

<div class="circle">

75%

</div>

<div style="flex:1;">

<div class="subject">

<label>

<span>Fundamentals of Nursing</span>

<span>80%</span>

</label>

<div class="bar">

<div class="fill" style="width:80%"></div>

</div>

</div>

<div class="subject">

<label>

<span>Med-Surg Nursing</span>

<span>72%</span>

</label>

<div class="bar">

<div class="fill" style="width:72%"></div>

</div>

</div>

<div class="subject">

<label>

<span>Maternal & Child Nursing</span>

<span>68%</span>

</label>

<div class="bar">

<div class="fill" style="width:68%"></div>

</div>

</div>

<div class="subject">

<label>

<span>Psychiatric Nursing</span>

<span>85%</span>

</label>

<div class="bar">

<div class="fill" style="width:85%"></div>

</div>

</div>

<div class="subject">

<label>

<span>Community Health Nursing</span>

<span>70%</span>

</label>

<div class="bar">

<div class="fill" style="width:70%"></div>

</div>

</div>

</div>

</div>

</div>


<div class="box">

<h3>Recent Activity</h3>

<div class="activity">

<div class="item">

<div>

<p><strong>Practice Quiz - Fundamentals</strong></p>

<small>Scored 18/20 (90%)</small>

</div>

<small>Today</small>

</div>

<div class="item">

<div>

<p><strong>Mock Exam</strong></p>

<small>Scored 85/100</small>

</div>

<small>Yesterday</small>

</div>

<div class="item">

<div>

<p><strong>Practice Quiz - Med Surg</strong></p>

<small>Scored 15/20</small>

</div>

<small>2 days ago</small>

</div>

</div>

<button class="view-btn">

View All

</button>

</div>

</div>

</div>

</body>
</html>