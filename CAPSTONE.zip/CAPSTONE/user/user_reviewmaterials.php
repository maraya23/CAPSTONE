<?php
session_start();
include("../connection.php");

// Search
$search = isset($_GET['search']) ? trim($_GET['search']) : "";

// Category Filter
$category = isset($_GET['category']) ? trim($_GET['category']) : "";

// Load Categories
$categoryQuery = mysqli_query($conn,"
SELECT DISTINCT category
FROM review_materials
ORDER BY category ASC
");

// Load Review Materials
$sql = "SELECT * FROM review_materials WHERE 1";

if($search != ""){
    $search = mysqli_real_escape_string($conn,$search);
    $sql .= " AND title LIKE '%$search%'";
}

if($category != ""){
    $category = mysqli_real_escape_string($conn,$category);
    $sql .= " AND category='$category'";
}

$sql .= " ORDER BY title ASC";

$result = mysqli_query($conn,$sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Review Materials</title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <link rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    
    <style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    background:#F4F7FC;
}

/* ===========================
   MAIN CONTENT
=========================== */

.main{

    margin-left:230px;
    padding:35px;

    min-height:100vh;

}

/* ===========================
   PAGE TITLE
=========================== */

.page-header{

    margin-bottom:30px;

}

.page-header h1{

    font-size:32px;
    color:#1E3A8A;
    font-weight:700;

}

.page-header p{

    color:#6B7280;
    margin-top:8px;
    font-size:15px;

}

/* ===========================
   TOOLBAR
=========================== */

.toolbar{

    display:flex;
    justify-content:space-between;
    align-items:center;

    gap:15px;

    margin-bottom:30px;

    flex-wrap:wrap;

}

.search-box{

    flex:1;

    min-width:280px;

    display:flex;
    align-items:center;

    background:#fff;

    border-radius:14px;

    padding:14px 18px;

    box-shadow:0 5px 18px rgba(0,0,0,.06);

}

.search-box i{

    color:#9CA3AF;

    margin-right:12px;

}

.search-box input{

    width:100%;

    border:none;

    outline:none;

    font-size:15px;

    background:transparent;

}

.toolbar select{

    width:220px;

    padding:14px;

    border:none;

    outline:none;

    border-radius:14px;

    background:#fff;

    box-shadow:0 5px 18px rgba(0,0,0,.06);

    cursor:pointer;

}

/* ===========================
   GRID
=========================== */

.materials-grid{

    display:grid;

    grid-template-columns:repeat(auto-fill,minmax(320px,1fr));

    gap:25px;

}

/* ===========================
   CARD
=========================== */

.material-card{

    background:#fff;

    border-radius:20px;

    padding:25px;

    box-shadow:0 10px 25px rgba(0,0,0,.06);

    transition:.3s;

    display:flex;

    flex-direction:column;

    justify-content:space-between;

}

.material-card:hover{

    transform:translateY(-6px);

    box-shadow:0 15px 35px rgba(53,104,232,.18);

}

/* ===========================
   CARD TOP
=========================== */

.card-top{

    display:flex;

    justify-content:space-between;

    align-items:center;

    margin-bottom:22px;

}

.file-icon{

    width:62px;

    height:62px;

    border-radius:18px;

    display:flex;

    align-items:center;

    justify-content:center;

    background:#EEF4FF;

    color:#3568E8;

    font-size:28px;

}
        
        .pdf-file{

background:#FFE8E8;
color:#E53935;

}

.word-file{

background:#E8F0FF;
color:#2563EB;

}

.ppt-file{

background:#FFF0E5;
color:#F97316;

}

.image-file{

background:#E8F9EE;
color:#16A34A;

}

.default-file{

background:#EEF2FF;
color:#6366F1;

}

.category{

    background:#EEF4FF;

    color:#3568E8;

    padding:7px 14px;

    border-radius:50px;

    font-size:12px;

    font-weight:600;

}

/* ===========================
   TITLE
=========================== */

.material-card h3{

    color:#1F2937;

    font-size:20px;

    line-height:1.4;

    margin-bottom:18px;

}

/* ===========================
   DATE
=========================== */

.upload-date{

    color:#6B7280;

    font-size:14px;

    margin-bottom:25px;

}

.upload-date i{

    margin-right:8px;

    color:#3568E8;

}

/* ===========================
   BUTTON
=========================== */

.card-footer{

    margin-top:auto;

}

.view-btn{

    width:100%;

    display:flex;

    justify-content:center;

    align-items:center;

    gap:10px;

    text-decoration:none;

    background:#3568E8;

    color:#fff;

    padding:13px;

    border-radius:12px;

    font-weight:600;

    transition:.3s;

}

.view-btn:hover{

    background:#1F4FD0;

}

.view-btn i{

    font-size:15px;

}

/* ===========================
   EMPTY
=========================== */

.empty-state{

    grid-column:1/-1;

    background:white;

    padding:70px 30px;

    border-radius:20px;

    text-align:center;

    box-shadow:0 10px 30px rgba(0,0,0,.05);

}

.empty-state i{

    font-size:70px;

    color:#3568E8;

    margin-bottom:20px;

}

.empty-state h2{

    color:#1F2937;

    margin-bottom:10px;

}

.empty-state p{

    color:#6B7280;

}

/* ===========================
   MOBILE
=========================== */

@media(max-width:768px){

.main{

    margin-left:0;

    padding:85px 18px 20px;

}

.toolbar{

    flex-direction:column;

    align-items:stretch;

}

.search-box{

    width:100%;

}

.toolbar select{

    width:100%;

}

.materials-grid{

    grid-template-columns:1fr;

}

.page-header h1{

    font-size:28px;

}

}
        
        .new-badge{

margin-left:8px;

background:#22C55E;

color:white;

padding:4px 10px;

border-radius:30px;

font-size:11px;

font-weight:600;

}

</style>

</head>

<body>

<?php include 'user_sidebar.php'; ?>

<div class="main">

    <!-- =========================
            PAGE HEADER
    ========================== -->

    <div class="page-header">

        <div>

            <h1>Review Materials</h1>

            <p>
                Browse all learning materials uploaded by the administrator.
            </p>

        </div>

    </div>



    <!-- =========================
            SEARCH & FILTER
    ========================== -->

    <form method="GET" class="toolbar">

        <div class="search-box">

            <i class="fa-solid fa-magnifying-glass"></i>

            <input
type="text"
name="search"
placeholder="Search review materials..."
value="<?php echo htmlspecialchars($search); ?>"
onkeyup="searchMaterial()">

        </div>

        <select name="category" onchange="this.form.submit()">

            <option value="">All Categories</option>

            <?php while($cat=mysqli_fetch_assoc($categoryQuery)){ ?>

                <option
                    value="<?php echo $cat['category']; ?>"
                    <?php if($category==$cat['category']) echo "selected"; ?>>

                    <?php echo htmlspecialchars($cat['category']); ?>

                </option>

            <?php } ?>

        </select>

    </form>



    <!-- =========================
            MATERIALS
    ========================== -->

    <div class="materials-grid">

<?php

if(mysqli_num_rows($result)>0){

while($row=mysqli_fetch_assoc($result)){

$file = strtolower(pathinfo($row['file_name'], PATHINFO_EXTENSION));

$icon = "fa-file";
$iconClass = "default-file";

switch($file){

    case "pdf":
        $icon = "fa-file-pdf";
        $iconClass = "pdf-file";
        break;

    case "doc":
    case "docx":
        $icon = "fa-file-word";
        $iconClass = "word-file";
        break;

    case "ppt":
    case "pptx":
        $icon = "fa-file-powerpoint";
        $iconClass = "ppt-file";
        break;

    case "jpg":
    case "jpeg":
    case "png":
        $icon = "fa-file-image";
        $iconClass = "image-file";
        break;
}
    
?>

<div class="material-card">

    <div class="card-top">

        <div class="file-icon <?php echo $iconClass; ?>">

            <i class="fa-solid <?php echo $icon; ?>"></i>

        </div>

        <div>

<span class="category">

<?php echo htmlspecialchars($row['category']); ?>

</span>

<?php

$days = floor((time()-strtotime($row['created_at']))/86400);

if($days <= 7){

?>

<span class="new-badge">

NEW

</span>

<?php } ?>

</div>

    </div>


    <h3>

        <?php echo htmlspecialchars($row['title']); ?>

    </h3>


    <div class="upload-date">

        <i class="fa-regular fa-calendar"></i>

        Uploaded

        <?php echo date("F d, Y",strtotime($row['created_at'])); ?>

    </div>


    <div class="card-footer">

        <a

        href="../uploads/review_materials/<?php echo urlencode($row['file_name']); ?>"

        target="_blank"

        class="view-btn">

            <i class="fa-solid fa-eye"></i>

Open Material

        </a>

    </div>

</div>

<?php

}

}else{

?>

<div class="empty-state">

    <i class="fa-solid fa-book-open-reader"></i>

    <h2>No Review Materials Available</h2>

    <p>

        The administrator hasn't uploaded any review materials yet.

    </p>

</div>

<?php

}

?>

    </div>

</div>

    <script>

let timer;

function searchMaterial(){

    clearTimeout(timer);

    timer=setTimeout(function(){

        document.querySelector(".toolbar").submit();

    },500);

}

</script>
    
</body>

</html>