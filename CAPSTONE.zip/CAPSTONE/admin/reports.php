<?php

session_start();

if(!isset($_SESSION['admin_id'])){

    header("Location: ../login.php");
    exit();

}

if($_SESSION['usertype'] != "admin"){

    header("Location: ../user.php");
    exit();

}


include "../connection.php";


// ===============================
// FILTERS
// ===============================

$category = isset($_GET['category']) 
? $_GET['category'] 
: "";

$exam = isset($_GET['exam']) 
? $_GET['exam'] 
: "";

$search = isset($_GET['search']) 
? $_GET['search'] 
: "";




// ===============================
// SUMMARY DATA
// ===============================


// Total Students

$totalStudents = mysqli_fetch_assoc(
mysqli_query($conn,"
SELECT COUNT(*) total
FROM logintbl
WHERE usertype='user'
")
)['total'];




// Total Exams

$totalExams = mysqli_fetch_assoc(
mysqli_query($conn,"
SELECT COUNT(*) total
FROM exams
")
)['total'];




// Total Attempts

$totalAttempts = mysqli_fetch_assoc(
mysqli_query($conn,"
SELECT COUNT(*) total
FROM exam_attempts
")
)['total'];




// Average Score

$averageScore = mysqli_fetch_assoc(
mysqli_query($conn,"
SELECT 
IFNULL(AVG(percentage),0) average
FROM exam_attempts
")
)['average'];





// Passed Students

$passed = mysqli_fetch_assoc(
mysqli_query($conn,"
SELECT COUNT(*) total
FROM exam_attempts
WHERE remarks='Passed'
")
)['total'];





// Failed Students

$failed = mysqli_fetch_assoc(
mysqli_query($conn,"
SELECT COUNT(*) total
FROM exam_attempts
WHERE remarks='Failed'
")
)['total'];





// Highest Score

$highest = mysqli_fetch_assoc(
mysqli_query($conn,"
SELECT IFNULL(MAX(percentage),0) score
FROM exam_attempts
")
)['score'];





// Lowest Score

$lowest = mysqli_fetch_assoc(
mysqli_query($conn,"
SELECT IFNULL(MIN(percentage),0) score
FROM exam_attempts
")
)['score'];





// ===============================
// LOAD FILTER DATA
// ===============================


$categories = mysqli_query($conn,"
SELECT category_id, category_name
FROM categories
WHERE status='Active'
ORDER BY category_name
");





$exams = mysqli_query($conn,"
SELECT exam_id,title
FROM exams
ORDER BY created_at DESC
");





// ===============================
// TOP STUDENTS REPORT
// ===============================


$sql = "

SELECT

CONCAT(
u.firstname,' ',
u.surname
) student_name,

e.title,

a.percentage,

a.remarks


FROM exam_attempts a


INNER JOIN logintbl u

ON a.user_id=u.id



INNER JOIN exams e

ON a.exam_id=e.exam_id



WHERE u.usertype='user'


";





$params=[];

$types="";





if($category!=""){


$sql.="

AND e.category_id=?

";


$params[]=$category;

$types.="i";


}





if($exam!=""){


$sql.="

AND e.exam_id=?

";


$params[]=$exam;

$types.="i";


}





if($search!=""){


$sql.="

AND CONCAT(u.firstname,' ',u.surname)
LIKE ?

";


$params[]="%".$search."%";

$types.="s";


}





$sql.="

ORDER BY a.percentage DESC

LIMIT 10

";






$stmt=mysqli_prepare($conn,$sql);





if(!empty($params)){


mysqli_stmt_bind_param(
$stmt,
$types,
...$params
);


}




mysqli_stmt_execute($stmt);


$topStudents=mysqli_stmt_get_result($stmt);

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">


<title>
Reports and Analytics - e-Nurse
</title>



<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">


<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">



<style>


*{

    margin:0;

    padding:0;

    box-sizing:border-box;

}



body{

    background:#edf2fb;

    font-family:'Poppins',sans-serif;

}





/* =========================
MAIN
========================= */


.main{

    margin-left:230px;

    width:calc(100% - 230px);

    min-height:100vh;

    padding:30px;

}





/* =========================
HEADER
========================= */


.page-header{

    background:white;

    border-radius:18px;

    padding:25px;

    margin-bottom:25px;

    box-shadow:0 4px 15px rgba(0,0,0,.08);

}



.page-header h1{

    font-size:32px;

    color:#111827;

}



.page-header p{

    color:#6b7280;

    margin-top:5px;

}







/* =========================
SUMMARY CARDS
========================= */


.stats{

    display:grid;

    grid-template-columns:repeat(4,1fr);

    gap:20px;

    margin-bottom:25px;

}





.stat-card{

    background:white;

    padding:22px;

    border-radius:18px;

    display:flex;

    align-items:center;

    gap:15px;

    box-shadow:0 4px 15px rgba(0,0,0,.08);

}



.stat-icon{

    width:55px;

    height:55px;

    border-radius:15px;

    display:flex;

    align-items:center;

    justify-content:center;

    font-size:24px;

}



.blue{

    background:#dbeafe;

    color:#2563eb;

}



.green{

    background:#dcfce7;

    color:#16a34a;

}



.orange{

    background:#fef3c7;

    color:#d97706;

}



.purple{

    background:#f3e8ff;

    color:#9333ea;

}



.stat-card h2{

    font-size:28px;

    color:#111827;

}



.stat-card p{

    font-size:14px;

    color:#6b7280;

}







/* =========================
FILTER CARD
========================= */


.filter-card{

    background:white;

    padding:22px;

    border-radius:18px;

    box-shadow:0 4px 15px rgba(0,0,0,.08);

    margin-bottom:25px;

}





.filter-form{

    display:flex;

    gap:15px;

    flex-wrap:wrap;

}





.filter-form input,
.filter-form select{

    height:45px;

    border:1px solid #d1d5db;

    border-radius:10px;

    padding:0 15px;

    font-family:'Poppins',sans-serif;

}



.filter-form input{

    min-width:220px;

}





.btn{

    border:none;

    padding:11px 18px;

    border-radius:10px;

    cursor:pointer;

    font-weight:600;

    font-family:'Poppins',sans-serif;

}



.btn-blue{

    background:#2563eb;

    color:white;

}



.btn-green{

    background:#16a34a;

    color:white;

}



.btn-gray{

    background:#6b7280;

    color:white;

}







/* =========================
REPORT TABLE
========================= */


.card{

    background:white;

    border-radius:18px;

    box-shadow:0 4px 15px rgba(0,0,0,.08);

    overflow:hidden;

}



.card-header{

    padding:22px 25px;

    border-bottom:1px solid #e5e7eb;

}



.card-header h2{

    font-size:24px;

}





.table-container{

    overflow-x:auto;

    padding:25px;

}





table{

    width:100%;

    border-collapse:collapse;

}



th{

    background:#2563eb;

    color:white;

    padding:14px;

    text-align:left;

}



td{

    padding:14px;

    border-bottom:1px solid #e5e7eb;

}





.badge{

    padding:6px 12px;

    border-radius:20px;

    font-size:12px;

    font-weight:600;

}



.pass{

    background:#dcfce7;

    color:#166534;

}



.fail{

    background:#fee2e2;

    color:#991b1b;

}






/* =========================
SUMMARY SIDE PANEL
========================= */


.analytics{

    margin-top:25px;

    display:grid;

    grid-template-columns:repeat(3,1fr);

    gap:20px;

}





.analytics-box{

    background:white;

    padding:22px;

    border-radius:18px;

    box-shadow:0 4px 15px rgba(0,0,0,.08);

}



.analytics-box h3{

    font-size:18px;

    margin-bottom:10px;

    color:#111827;

}



.analytics-box p{

    color:#6b7280;

}







/* =========================
RESPONSIVE
========================= */


@media(max-width:1200px){


.stats{

    grid-template-columns:repeat(2,1fr);

}


.analytics{

    grid-template-columns:1fr;

}


}






@media(max-width:992px){


.main{

    margin-left:0;

    width:100%;

    padding:85px 20px 20px;

}


}




@media(max-width:768px){


.stats{

    grid-template-columns:1fr;

}



.filter-form{

    flex-direction:column;

}



.filter-form input,
.filter-form select,
.filter-form button{

    width:100%;

}



.page-header h1{

    font-size:25px;

}



table{

    min-width:800px;

}



}



</style>


</head>
    
    <body>


<?php include 'admin_sidebar.php'; ?>


<main class="main">



<!-- =========================
PAGE HEADER
========================= -->


<div class="page-header">


<h1>
<i class="fa-solid fa-chart-line"></i>
Reports and Analytics
</h1>


<p>
Monitor student performance, examination results, and system statistics.
</p>


</div>






<!-- =========================
SUMMARY CARDS
========================= -->


<div class="stats">



<div class="stat-card">

<div class="stat-icon blue">

<i class="fa-solid fa-users"></i>

</div>


<div>

<h2>
<?php echo $totalStudents; ?>
</h2>

<p>
Total Students
</p>

</div>


</div>






<div class="stat-card">

<div class="stat-icon green">

<i class="fa-solid fa-file-lines"></i>

</div>


<div>

<h2>
<?php echo $totalExams; ?>
</h2>

<p>
Total Exams
</p>

</div>


</div>







<div class="stat-card">

<div class="stat-icon orange">

<i class="fa-solid fa-clipboard-check"></i>

</div>


<div>

<h2>
<?php echo $totalAttempts; ?>
</h2>

<p>
Exam Attempts
</p>

</div>


</div>







<div class="stat-card">

<div class="stat-icon purple">

<i class="fa-solid fa-chart-column"></i>

</div>


<div>

<h2>
<?php echo number_format($averageScore,2); ?>%
</h2>

<p>
Average Score
</p>

</div>


</div>



</div>










<!-- =========================
FILTERS
========================= -->


<div class="filter-card">


<form method="GET" class="filter-form">



<input

type="text"

name="search"

placeholder="Search student name..."

value="<?php echo htmlspecialchars($search); ?>"

>




<select name="category">


<option value="">
All Categories
</option>


<?php while($cat=mysqli_fetch_assoc($categories)){ ?>


<option

value="<?php echo $cat['category_id']; ?>"

<?php

if($category==$cat['category_id'])
echo "selected";

?>

>


<?php echo htmlspecialchars($cat['category_name']); ?>


</option>


<?php } ?>


</select>







<select name="exam">


<option value="">
All Exams
</option>


<?php while($ex=mysqli_fetch_assoc($exams)){ ?>


<option

value="<?php echo $ex['exam_id']; ?>"

<?php

if($exam==$ex['exam_id'])
echo "selected";

?>

>


<?php echo htmlspecialchars($ex['title']); ?>


</option>


<?php } ?>


</select>






<button class="btn btn-blue">

<i class="fa-solid fa-filter"></i>

Generate Report

</button>





<button

type="button"

onclick="window.print()"

class="btn btn-gray"

>


<i class="fa-solid fa-print"></i>

Print

</button>





</form>


</div>









<!-- =========================
TOP STUDENTS REPORT
========================= -->


<div class="card">



<div class="card-header">


<h2>

<i class="fa-solid fa-ranking-star"></i>

Top 10 Students

</h2>


</div>





<div class="table-container">


<table>


<thead>


<tr>

<th>
Rank
</th>


<th>
Student Name
</th>


<th>
Exam
</th>


<th>
Score
</th>


<th>
Remarks
</th>


</tr>


</thead>




<tbody>


<?php


$rank=1;


if(mysqli_num_rows($topStudents)>0){


while($row=mysqli_fetch_assoc($topStudents)){


?>


<tr>


<td>

<?php echo $rank++; ?>

</td>




<td>

<strong>

<?php echo htmlspecialchars($row['student_name']); ?>

</strong>

</td>





<td>

<?php echo htmlspecialchars($row['title']); ?>

</td>





<td>

<?php echo number_format($row['percentage'],2); ?>%

</td>





<td>


<?php if($row['remarks']=="Passed"){ ?>


<span class="badge pass">

Passed

</span>


<?php }else{ ?>


<span class="badge fail">

Failed

</span>


<?php } ?>


</td>



</tr>



<?php


}


}else{


?>


<tr>


<td colspan="5" style="text-align:center;padding:30px;">


No examination records found.


</td>


</tr>


<?php


}


?>



</tbody>



</table>



</div>


</div>









<!-- =========================
ANALYTICS SUMMARY
========================= -->


<div class="analytics">



<div class="analytics-box">


<h3>

Passed Students

</h3>


<p>

<?php echo $passed; ?>

students passed examinations.

</p>


</div>







<div class="analytics-box">


<h3>

Failed Students

</h3>


<p>

<?php echo $failed; ?>

students failed examinations.

</p>


</div>







<div class="analytics-box">


<h3>

Score Range

</h3>


<p>


Highest:

<strong>

<?php echo number_format($highest,2); ?>%

</strong>


<br>


Lowest:

<strong>

<?php echo number_format($lowest,2); ?>%

</strong>


</p>


</div>



</div>





</main>
        
        <script>


// ===============================
// AUTO SUBMIT FILTERS
// ===============================


document.querySelectorAll(
    ".filter-form select"
)
.forEach(function(select){


    select.addEventListener(
        "change",
        function(){

            this.form.submit();

        }
    );


});




// ===============================
// PRINT STYLE CLEANUP
// ===============================


window.onbeforeprint = function(){


    document.querySelector(".filter-card")
    .style.display="none";


};



window.onafterprint = function(){


    document.querySelector(".filter-card")
    .style.display="block";


};



</script>



</body>

</html>