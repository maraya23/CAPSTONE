<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Reports and Analytics</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}


body{

    margin:0;

    font-family:'Poppins',sans-serif;

    background:#f3f4f9;

}



/* MAIN */

.main{

    margin-left:230px;

    padding:30px;

    width:calc(100% - 230px);

}



.title{

    font-size:30px;

    font-weight:600;

    color:#111827;

    margin-bottom:25px;

}






/* FILTERS */


.filters{

    display:flex;

    gap:15px;

    align-items:flex-end;

    margin-bottom:30px;

    flex-wrap:wrap;

}



.filter-group{

    display:flex;

    flex-direction:column;

}



.filter-group label{

    margin-bottom:8px;

    color:#555;

    font-size:14px;

}



input,
select{

    width:220px;

    padding:10px 12px;

    border:1px solid #d1d5db;

    border-radius:10px;

    font-size:14px;

}





button{

    border:none;

    color:white;

    padding:11px 18px;

    border-radius:10px;

    font-size:14px;

    font-weight:600;

    cursor:pointer;

    white-space:nowrap;

}



.generate{

    background:#28A745;

}



.download{

    background:#0D6EFD;

}



.print{

    background:#6C757D;

}







/* CONTENT */


.content{

    display:flex;

    gap:20px;

    align-items:flex-start;

}



.report-box{

    flex:1;

    background:#fff;

    border-radius:18px;

    padding:25px;

    box-shadow:0 4px 18px rgba(0,0,0,.08);

}



.summary-box{

    width:300px;

    background:#fff;

    border-radius:18px;

    padding:25px;

    box-shadow:0 4px 18px rgba(0,0,0,.08);

}



.section-title{

    font-size:22px;

    font-weight:600;

    color:#111827;

    margin-bottom:20px;

}






/* TABLE */


.table-container{

    width:100%;

    overflow-x:auto;

}



table{

    width:100%;

    border-collapse:collapse;

    min-width:600px;

}



th{

    background:#2563eb;

    color:white;

    padding:14px;

    font-weight:600;

}



td{

    padding:12px;

    border-bottom:1px solid #e5e7eb;

    text-align:center;

    font-size:14px;

}





.pass{

    color:green;

    font-weight:bold;

}



.fail{

    color:red;

    font-weight:bold;

}






/* SUMMARY */


.summary-item{

    margin-bottom:25px;

    border-bottom:1px solid #eee;

    padding-bottom:15px;

}



.summary-item:last-child{

    border:none;

}



.summary-item h4{

    color:#12396E;

    font-size:16px;

    margin-bottom:5px;

}



.summary-item p{

    color:#555;

    font-size:14px;

}









/* TABLET */

@media(max-width:1100px){


.main{

    margin-left:0;

    width:100%;

    padding:25px;

}



.content{

    flex-direction:column;

}



.summary-box{

    width:100%;

}



}









/* MOBILE */


@media(max-width:600px){



.main{

    padding:20px 15px;

}



.title{

    font-size:24px;

}



.filters{

    flex-direction:column;

    align-items:stretch;

    gap:12px;

}



.filter-group{

    width:100%;

}



input,
select{

    width:100%;

}



button{

    width:100%;

}



.content{

    flex-direction:column;

}



.report-box,
.summary-box{

    width:100%;

    padding:18px;

}



.section-title{

    font-size:18px;

}



}
</style>
</head>

<body>
    
    <?php include 'admin_sidebar.php'; ?>

<div class="main">

<div class="title">Reports and Analytics</div>

<div class="filters">

<div class="filter-group">
<label>Search Student</label>
<input type="text" placeholder="Search by Name">
</div>

<div class="filter-group">
<label>Category</label>
<select name="category">
        <option value="">All Categories</option>
    </select>
</div>

<div class="filter-group">
<label>View</label>
<select name="category">
        <option value="">View</option>
    </select>
</div>

<button class="generate">Generate Report</button>
<button class="download">Download</button>
<button class="print" onclick="window.print()">Print</button>

</div>

<div class="content">

<div class="report-box">

<div class="section-title">
Top 10 Students
</div>
    
    <div class="table-container">

<table>

<tr>
<th>Rank</th>
<th>Student Name</th>
<th>Score</th>
<th>Status</th>
</tr>

</table>
        
        </div>

</div>

<div class="summary-box">

<div class="summary-item">
<h4>Total Students</h4>
<p></p>
</div>

<div class="summary-item">
<h4>Passed Students</h4>
<p></p>
</div>

<div class="summary-item">
<h4>Failed Students</h4>
<p></p>
</div>

<div class="summary-item">
<h4>Highest Score</h4>
<p></p>
</div>

<div class="summary-item">
<h4>Lowest Score</h4>
<p></p>
</div>

<div class="summary-item">
<h4>Current Category</h4>
<p></p>
</div>

</div>

</div>

</div>

</body>
</html>