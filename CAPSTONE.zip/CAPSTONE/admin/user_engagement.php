<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - User Engagement</title>
    
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
       body*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Poppins',sans-serif;
    background:#f3f5fb;
}

        .main{

    margin-left:230px;
    width:calc(100% - 230px);

    min-height:100vh;

    padding:30px;

    overflow-x:auto;

}
        .topbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; }
        .topbar h1{
    font-size:30px;
    font-weight:600;
    color:#111827;
    margin:0;
}
        .topbar p{
    color:#6b7280;
    font-size:15px;
    margin-top:6px;
}

        .grid-4{

    display:grid;

    grid-template-columns:repeat(auto-fit,minmax(240px,1fr));

    gap:24px;

    margin-bottom:35px;

}
        .grid-2{

    display:grid;

    grid-template-columns:repeat(auto-fit,minmax(400px,1fr));

    gap:24px;

    margin-bottom:35px;

}

        .card{

    background:#fff;

    border-radius:18px;

    padding:24px;

    box-shadow:0 4px 18px rgba(0,0,0,.08);

    transition:.25s;

}

.card:hover{

    transform:translateY(-2px);

}
        .card-header{
    font-size:18px;
    font-weight:600;
    color:#374151;
    margin-bottom:20px;
}

        .stat-card { display: flex; align-items: center; gap: 20px; }
        .stat-icon{
    width:60px;
    height:60px;
    border-radius:14px;
    display:flex;
    justify-content:center;
    align-items:center;
    font-size:24px;
}
        .stat-info h3{
    font-size:30px;
    margin:4px 0;
    color:#111827;
    font-weight:700;
}
        .stat-info p { font-size: 14px; color: #6b7280; font-weight: bold; margin-bottom: 0; }
        .empty-trend { color: #9ca3af; font-size: 13px; font-style: italic; }
        
        .bg-blue { background: #e8f0ff; color: #2563eb; }
        .bg-green { background: #e8f7ea; color: #2f9e44; }
        .bg-indigo { background: #e0e7ff; color: #6366f1; }
        .bg-purple { background: #f1e9ff; color: #7c3aed; }

        .feature-row { margin-bottom: 20px; }
        .feature-label { display: flex; justify-content: space-between; font-size: 14px; margin-bottom: 8px; color: #4b5563; font-weight: bold; }
        .progress-bar-bg { height: 10px; background: #f3f4f6; border-radius: 5px; overflow: hidden; }
        .progress-bar-fill { height: 100%; background: #2563eb; border-radius: 5px; }

        .list-item { display: flex; align-items: center; justify-content: space-between; padding: 16px 0; border-bottom: 1px solid #f3f4f6; font-size: 15px; color: #4b5563; }
        .list-item:last-child { border-bottom: none; }
        .empty-state{

    justify-content:center;

    align-items:center;

    text-align:center;

    color:#9ca3af;

    font-style:italic;

    padding:40px 0;

    min-height:120px;

}
        
        .btn-outline{
    display:block;
    width:100%;
    text-align:center;
    padding:12px;
    border:1px solid #e5e7eb;
    border-radius:10px;
    color:#2563eb;
    text-decoration:none;
    font-size:14px;
    font-weight:600;
    margin-top:20px;
    transition:.25s;
}
        .btn-outline:hover { background: #f9fafb; }
       .chart-container{

    position:relative;

    width:100%;

    height:320px;

}
                            
@media(max-width:768px){

.main{

    margin-left:0;

    width:100%;

    padding:85px 15px 20px;

}

.topbar{

    flex-direction:column;

    align-items:flex-start;

    gap:12px;

}

.topbar h1{

    font-size:26px;

}

.grid-2{

    grid-template-columns:1fr;

}

.grid-4{

    grid-template-columns:1fr;

}

.chart-container{

    height:260px;

}

.stat-card{

    display:flex;

    align-items:center;

    gap:20px;

    min-height:120px;

}

.btn-outline{

    width:100%;

}

}
                            
    </style>
</head>
<body>
        <?php include 'admin_sidebar.php'; ?>

    <main class="main">
        <div class="topbar">
            <div>
                <h1>User Engagement</h1>
                <p>Monitor user activity and engagement metrics.</p>
            </div>
        </div>

        <div class="grid-4">
            <div class="card stat-card">
                <div class="stat-icon bg-blue"><i class="fa-solid fa-users"></i></div>
                <div class="stat-info">
                    <p>Total Users</p>
                    <h3>0</h3>
                    <span class="empty-trend">No data yet</span>
                </div>
            </div>
            <div class="card stat-card">
                <div class="stat-icon bg-green"><i class="fa-solid fa-user-check"></i></div>
                <div class="stat-info">
                    <p>Active Users</p>
                    <h3>0</h3>
                    <p style="font-weight: normal;">0% of total</p>
                </div>
            </div>
            <div class="card stat-card">
                <div class="stat-icon bg-indigo"><i class="fa-solid fa-shield-alt"></i></div>
                <div class="stat-info">
                    <p>Engagement Rate</p>
                    <h3>0%</h3>
                    <span class="empty-trend">No data yet</span>
                </div>
            </div>
            <div class="card stat-card">
                <div class="stat-icon bg-purple"><i class="fa-solid fa-clock"></i></div>
                <div class="stat-info">
                    <p>Avg. Session</p>
                    <h3>0m</h3>
                    <span class="empty-trend">No data yet</span>
                </div>
            </div>
        </div>

        <div class="grid-2">
            <div class="card">
                <div class="card-header">Engagement Overview</div>
                <div class="chart-container">
                    <canvas id="engagementChart"></canvas>
                </div>
            </div>

            <div class="card">
                <div class="card-header">Engagement by Feature</div>
                <div class="feature-row">
                    <div class="feature-label"><span>Practice Quizzes</span> <span>0%</span></div>
                    <div class="progress-bar-bg"><div class="progress-bar-fill" style="width: 0%;"></div></div>
                </div>
                <div class="feature-row">
                    <div class="feature-label"><span>Mock Examinations</span> <span>0%</span></div>
                    <div class="progress-bar-bg"><div class="progress-bar-fill" style="width: 0%;"></div></div>
                </div>
                <div class="feature-row">
                    <div class="feature-label"><span>Review Materials</span> <span>0%</span></div>
                    <div class="progress-bar-bg"><div class="progress-bar-fill" style="width: 0%;"></div></div>
                </div>
                <div class="feature-row">
                    <div class="feature-label"><span>Performance Reports</span> <span>0%</span></div>
                    <div class="progress-bar-bg"><div class="progress-bar-fill" style="width: 0%;"></div></div>
                </div>
                <a href="#" class="btn-outline">View All Features</a>
            </div>
        </div>

        <div class="grid-2">
            <div class="card">
                <div class="card-header">User Activity Feed</div>
                <div class="list-item empty-state">No recent activity to show.</div>
                <a href="#" class="btn-outline">View All Activity</a>
            </div>

            <div class="card">
                <div class="card-header">Top Engaged Users</div>
                <div class="list-item empty-state">No users have registered yet.</div>
                <a href="#" class="btn-outline">View Leaderboard</a>
            </div>
        </div>
    </main>

<script>
    const ctx = document.getElementById('engagementChart').getContext('2d');
    
    let gradientBlue = ctx.createLinearGradient(0, 0, 0, 400);
    gradientBlue.addColorStop(0, 'rgba(37, 99, 235, 0.2)');   
    gradientBlue.addColorStop(1, 'rgba(37, 99, 235, 0)');

    let gradientGreen = ctx.createLinearGradient(0, 0, 0, 400);
    gradientGreen.addColorStop(0, 'rgba(47, 158, 68, 0.2)');   
    gradientGreen.addColorStop(1, 'rgba(47, 158, 68, 0)');

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5', 'Day 6', 'Day 7'],
            datasets: [
                {
                    label: 'Active Users',
                    data: [0, 0, 0, 0, 0, 0, 0],
                    borderColor: '#2563eb', 
                    backgroundColor: gradientBlue, 
                    borderWidth: 2,
                    pointBackgroundColor: '#2563eb',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 4,
                    fill: true, 
                    tension: 0.4 
                },
                {
                    label: 'New Users',
                    data: [0, 0, 0, 0, 0, 0, 0],
                    borderColor: '#2f9e44', 
                    backgroundColor: gradientGreen, 
                    borderWidth: 2,
                    pointBackgroundColor: '#2f9e44',
                    pointBorderColor: '#fff',
                    pointBorderWidth: 2,
                    pointRadius: 4,
                    fill: true, 
                    tension: 0.4
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { position: 'top', labels: { usePointStyle: true, boxWidth: 8, font: { family: 'Poppins' } } }
            },
            scales: {
                y: { beginAtZero: true, max: 100, grid: { borderDash: [5, 5], color: '#e5e7eb' } },
                x: { grid: { display: false } }
            }
        }
    });
</script>
</body>
</html>