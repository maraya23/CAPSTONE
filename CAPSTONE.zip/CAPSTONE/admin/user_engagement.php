<?php

session_start();

require_once "../connection.php";


/*====================================
ADMIN AUTHENTICATION
====================================*/

if(!isset($_SESSION['admin_id'])){

    header("Location: ../login.php");
    exit();

}


if(strtolower($_SESSION['usertype'])!="admin"){

    header("Location: ../user.php");
    exit();

}



/*====================================
TOTAL USERS
====================================*/


$totalUsers=0;


$result=mysqli_query(
$conn,

"
SELECT COUNT(*) AS total
FROM logintbl
WHERE usertype='user'
"

);


if($result){

$row=mysqli_fetch_assoc($result);

$totalUsers=$row['total'];

}






/*====================================
ACTIVE USERS
====================================*/


$activeUsers=0;


$result=mysqli_query(
$conn,

"
SELECT COUNT(DISTINCT user_id) AS total
FROM user_activity
"

);


if($result){

$row=mysqli_fetch_assoc($result);

$activeUsers=$row['total'];

}






/*====================================
ENGAGEMENT RATE
====================================*/


$engagementRate=0;


if($totalUsers>0){

$engagementRate=
round(
($activeUsers/$totalUsers)*100
);

}







/*====================================
TOTAL ACTIVITIES
====================================*/


$totalActivities=0;


$result=mysqli_query(
$conn,

"
SELECT COUNT(*) AS total
FROM user_activity
"

);



if($result){

$row=mysqli_fetch_assoc($result);

$totalActivities=$row['total'];

}








/*====================================
FEATURE DATA
====================================*/


// Exams

$examCount=0;


$result=mysqli_query(
$conn,

"
SELECT COUNT(*) AS total
FROM exam_attempts
"

);


if($result){

$row=mysqli_fetch_assoc($result);

$examCount=$row['total'];

}




// Review

$reviewCount=0;


$result=mysqli_query(
$conn,

"
SELECT COUNT(*) AS total
FROM review_progress
WHERE status='Completed'
"

);


if($result){

$row=mysqli_fetch_assoc($result);

$reviewCount=$row['total'];

}





// Feedback

$feedbackCount=0;


$result=mysqli_query(
$conn,

"
SELECT COUNT(*) AS total
FROM feedback
"

);



if($result){

$row=mysqli_fetch_assoc($result);

$feedbackCount=$row['total'];

}







/*====================================
ACTIVITY FEED
====================================*/


$activities=mysqli_query(
$conn,

"
SELECT

ua.activity,
ua.activity_date,


CONCAT(
l.firstname,' ',
l.surname
) AS fullname


FROM user_activity ua


INNER JOIN logintbl l

ON ua.user_id=l.id


ORDER BY ua.activity_date DESC


LIMIT 5

"

);







/*====================================
TOP ENGAGED USERS
====================================*/


$topUsers=mysqli_query(
$conn,

"
SELECT


CONCAT(
l.firstname,' ',
l.surname
) AS fullname,


COUNT(ua.activity_id) AS total_activity


FROM logintbl l


LEFT JOIN user_activity ua

ON l.id=ua.user_id


WHERE l.usertype='user'


GROUP BY l.id


ORDER BY total_activity DESC


LIMIT 5

"

);







/*====================================
CHART DATA
LAST 7 DAYS
====================================*/


$chartLabels=[];

$activityData=[];

$newUserData=[];



for($i=6;$i>=0;$i--){


$date=date(
"Y-m-d",
strtotime("-".$i." days")
);



$chartLabels[]=
date(
"M d",
strtotime($date)
);




/* USER ACTIVITY */


$result=mysqli_query(
$conn,

"
SELECT COUNT(*) AS total
FROM user_activity
WHERE DATE(activity_date)='$date'
"

);


$row=mysqli_fetch_assoc($result);


$activityData[]=$row['total'];






/* NEW USERS */


$result=mysqli_query(
$conn,

"
SELECT COUNT(*) AS total
FROM logintbl
WHERE DATE(created_at)='$date'
"

);


$row=mysqli_fetch_assoc($result);


$newUserData[]=$row['total'];



}


?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">


<title>User Engagement | e-Nurse</title>


<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">


<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>


    <style>


*{

    margin:0;
    padding:0;
    box-sizing:border-box;

}



body{

    font-family:'Poppins',sans-serif;

    background:#f3f5fb;

    color:#111827;

}





/*==============================
MAIN CONTENT
==============================*/


.main{

    margin-left:230px;

    width:calc(100% - 230px);

    min-height:100vh;

    padding:30px;

}







/*==============================
TOP HEADER
==============================*/


.topbar{

    margin-bottom:30px;

}



.topbar h1{

    font-size:30px;

    font-weight:600;

    color:#111827;

}



.topbar p{

    color:#6b7280;

    margin-top:6px;

    font-size:15px;

}








/*==============================
GRID
==============================*/


.grid-4{

    display:grid;

    grid-template-columns:
    repeat(auto-fit,minmax(240px,1fr));

    gap:24px;

    margin-bottom:30px;

}





.grid-2{

    display:grid;

    grid-template-columns:
    repeat(auto-fit,minmax(400px,1fr));

    gap:24px;

    margin-bottom:30px;

}







/*==============================
CARD
==============================*/


.card{

    background:#ffffff;

    border-radius:18px;

    padding:24px;

    box-shadow:
    0 5px 18px rgba(0,0,0,.08);

    transition:.25s;

}



.card:hover{

    transform:translateY(-3px);

}







/*==============================
STAT CARD
==============================*/


.stat-card{

    display:flex;

    align-items:center;

    gap:20px;

}



.stat-icon{

    width:60px;

    height:60px;

    border-radius:15px;

    display:flex;

    justify-content:center;

    align-items:center;

    font-size:25px;

}




.stat-info p{

    font-size:14px;

    color:#6b7280;

    font-weight:600;

}



.stat-info h3{

    font-size:30px;

    margin:5px 0;

    font-weight:700;

}



.stat-info span{

    font-size:13px;

    color:#9ca3af;

}







/* ICON BACKGROUNDS */


.bg-blue{

    background:#e8f0ff;

    color:#2563eb;

}



.bg-green{

    background:#e8f7ea;

    color:#16a34a;

}



.bg-indigo{

    background:#e0e7ff;

    color:#6366f1;

}



.bg-purple{

    background:#f3e8ff;

    color:#9333ea;

}








/*==============================
CARD TITLE
==============================*/


.card-header{

    font-size:18px;

    font-weight:600;

    margin-bottom:20px;

    color:#374151;

}








/*==============================
CHART
==============================*/


.chart-container{

    height:320px;

    width:100%;

}








/*==============================
FEATURE PROGRESS
==============================*/


.feature-row{

    margin-bottom:20px;

}



.feature-label{

    display:flex;

    justify-content:space-between;

    margin-bottom:8px;

    font-size:14px;

    color:#4b5563;

    font-weight:600;

}



.progress-bar-bg{

    height:10px;

    background:#f3f4f6;

    border-radius:10px;

    overflow:hidden;

}



.progress-bar-fill{

    height:100%;

    background:#2563eb;

    border-radius:10px;

}








/*==============================
LIST
==============================*/


.list-item{

    display:flex;

    justify-content:space-between;

    align-items:center;

    padding:15px 0;

    border-bottom:1px solid #f3f4f6;

    font-size:14px;

}



.list-item:last-child{

    border-bottom:none;

}



.list-item span{

    color:#6b7280;

}





.list-item small{

    color:#9ca3af;

}








/*==============================
EMPTY STATE
==============================*/


.empty-state{

    text-align:center;

    padding:40px 10px;

    color:#9ca3af;

    font-style:italic;

}








/*==============================
BADGE
==============================*/


.badge{

    background:#eff6ff;

    color:#2563eb!important;

    padding:6px 12px;

    border-radius:20px;

    font-size:12px;

    font-weight:600;

}








/*==============================
BUTTON
==============================*/


.btn-outline{

    display:block;

    width:100%;

    text-align:center;

    margin-top:20px;

    padding:12px;

    border-radius:10px;

    border:1px solid #e5e7eb;

    text-decoration:none;

    color:#2563eb;

    font-size:14px;

    font-weight:600;

    transition:.25s;

}



.btn-outline:hover{

    background:#f9fafb;

}








/*==============================
MOBILE RESPONSIVE
==============================*/


@media(max-width:768px){


.main{


    margin-left:0;

    width:100%;

    padding:85px 15px 20px;

}



.topbar h1{

    font-size:26px;

}



.grid-4{


    grid-template-columns:1fr;

}



.grid-2{


    grid-template-columns:1fr;

}



.stat-card{


    min-height:110px;

}



.chart-container{

    height:260px;

}



}





</style>
    
</head>


<body>


<?php include 'admin_sidebar.php'; ?>



<main class="main">



<!-- PAGE HEADER -->


<div class="topbar">


<div>


<h1>

User Engagement

</h1>


<p>

Monitor user activity and engagement metrics.

</p>


</div>


</div>





<!--==============================
STAT CARDS
===============================-->



<div class="grid-4">





<!-- TOTAL USERS -->


<div class="card stat-card">


<div class="stat-icon bg-blue">

<i class="fa-solid fa-users"></i>

</div>



<div class="stat-info">


<p>

Total Users

</p>



<h3>

<?php echo $totalUsers; ?>

</h3>



<span>

Registered Accounts

</span>


</div>



</div>







<!-- ACTIVE USERS -->


<div class="card stat-card">


<div class="stat-icon bg-green">

<i class="fa-solid fa-user-check"></i>

</div>



<div class="stat-info">


<p>

Active Users

</p>



<h3>

<?php echo $activeUsers; ?>

</h3>



<span>

<?php echo $engagementRate; ?>% of total

</span>


</div>



</div>








<!-- ENGAGEMENT RATE -->


<div class="card stat-card">


<div class="stat-icon bg-indigo">

<i class="fa-solid fa-chart-line"></i>

</div>



<div class="stat-info">


<p>

Engagement Rate

</p>



<h3>

<?php echo $engagementRate; ?>%

</h3>



<span>

Based on activity

</span>


</div>



</div>








<!-- TOTAL ACTIVITY -->


<div class="card stat-card">


<div class="stat-icon bg-purple">

<i class="fa-solid fa-clock"></i>

</div>



<div class="stat-info">


<p>

Total Activities

</p>



<h3>

<?php echo $totalActivities; ?>

</h3>



<span>

User interactions

</span>


</div>



</div>





</div>
    
    <!--==============================
CHART + FEATURE SECTION
===============================-->

<div class="grid-2">


<!-- CHART -->


<div class="card">


<div class="card-header">

Engagement Overview

</div>



<div class="chart-container">

<canvas id="engagementChart"></canvas>

</div>



</div>





<!-- FEATURE ENGAGEMENT -->


<div class="card">


<div class="card-header">

Engagement by Feature

</div>




<?php


$totalFeature =
$totalActivities > 0 ? $totalActivities : 1;



$examPercent =
round(($examCount/$totalFeature)*100);



$reviewPercent =
round(($reviewCount/$totalFeature)*100);



$feedbackPercent =
round(($feedbackCount/$totalFeature)*100);



$activityPercent =
round(($totalActivities/$totalFeature)*100);



?>





<div class="feature-row">


<div class="feature-label">

<span>

Mock Examinations

</span>


<span>

<?php echo $examPercent; ?>%

</span>


</div>



<div class="progress-bar-bg">


<div class="progress-bar-fill"

style="width:<?php echo $examPercent; ?>%">

</div>


</div>


</div>







<div class="feature-row">


<div class="feature-label">


<span>

Review Materials

</span>


<span>

<?php echo $reviewPercent; ?>%

</span>


</div>



<div class="progress-bar-bg">


<div class="progress-bar-fill"

style="width:<?php echo $reviewPercent; ?>%">

</div>


</div>


</div>








<div class="feature-row">


<div class="feature-label">


<span>

Feedback

</span>


<span>

<?php echo $feedbackPercent; ?>%

</span>


</div>



<div class="progress-bar-bg">


<div class="progress-bar-fill"

style="width:<?php echo $feedbackPercent; ?>%">

</div>


</div>


</div>








<div class="feature-row">


<div class="feature-label">


<span>

User Activity

</span>


<span>

<?php echo $activityPercent; ?>%

</span>


</div>



<div class="progress-bar-bg">


<div class="progress-bar-fill"

style="width:<?php echo $activityPercent; ?>%">

</div>


</div>


</div>



<a href="#" class="btn-outline">

View All Features

</a>



</div>



</div>







<!--==============================
ACTIVITY + TOP USERS
===============================-->



<div class="grid-2">





<!-- ACTIVITY FEED -->


<div class="card">


<div class="card-header">

User Activity Feed

</div>




<?php


if(mysqli_num_rows($activities)>0){


while($row=mysqli_fetch_assoc($activities)){


?>


<div class="list-item">


<div>


<strong>

<?php

echo htmlspecialchars(
$row['fullname']
);

?>

</strong>


<br>


<span>

<?php

echo htmlspecialchars(
$row['activity']
);

?>

</span>


</div>




<small>

<?php

echo date(
"M d, Y",
strtotime($row['activity_date'])
);

?>

</small>



</div>



<?php


}


}else{


?>


<div class="empty-state">

No recent activity to show.

</div>



<?php

}


?>



<a href="#" class="btn-outline">

View All Activity

</a>



</div>









<!-- TOP USERS -->


<div class="card">


<div class="card-header">

Top Engaged Users

</div>





<?php


if(mysqli_num_rows($topUsers)>0){



while($row=mysqli_fetch_assoc($topUsers)){



?>



<div class="list-item">



<strong>

<?php

echo htmlspecialchars(
$row['fullname']
);

?>

</strong>




<span class="badge">


<?php

echo $row['total_activity'];

?>

Activities


</span>



</div>



<?php


}


}else{


?>


<div class="empty-state">

No users have registered yet.

</div>


<?php


}


?>





<a href="#" class="btn-outline">

View Leaderboard

</a>



</div>



</div>

    </div> <!-- END ACTIVITY + TOP USERS GRID -->


</main>


<script>


const ctx = document
.getElementById('engagementChart')
.getContext('2d');



const gradientBlue = ctx.createLinearGradient(
0,
0,
0,
300
);


gradientBlue.addColorStop(
0,
'rgba(37,99,235,0.25)'
);


gradientBlue.addColorStop(
1,
'rgba(37,99,235,0)'
);





const gradientGreen = ctx.createLinearGradient(
0,
0,
0,
300
);


gradientGreen.addColorStop(
0,
'rgba(22,163,74,0.25)'
);


gradientGreen.addColorStop(
1,
'rgba(22,163,74,0)'
);






new Chart(ctx,{


type:'line',


data:{


labels:

<?php echo json_encode($chartLabels); ?>,


datasets:[



{

label:'Active Users',

data:

<?php echo json_encode($activityData); ?>,


borderColor:'#2563eb',

backgroundColor:gradientBlue,

borderWidth:3,

pointRadius:5,

pointBackgroundColor:'#2563eb',

fill:true,

tension:.4


},




{

label:'New Users',

data:

<?php echo json_encode($newUserData); ?>,


borderColor:'#16a34a',

backgroundColor:gradientGreen,

borderWidth:3,

pointRadius:5,

pointBackgroundColor:'#16a34a',

fill:true,

tension:.4


}


]


},





options:{


responsive:true,


maintainAspectRatio:false,


plugins:{


legend:{


position:'top'


}


},





scales:{



y:{


beginAtZero:true,


ticks:{


precision:0


}


},



x:{


grid:{


display:false


}


}



}



}



});



</script>


</body>

</html>