<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: /CAPSTONE/login.php");
    exit();
}

if ($_SESSION['usertype'] != "admin") {
    header("Location: ../user.php");
    exit();
}

include "../connection.php";


// =====================================
// LOAD ACTIVE CATEGORIES
// =====================================

$categories = mysqli_query($conn,"
SELECT
category_id,
category_name
FROM categories
WHERE status='Active'
ORDER BY category_name ASC
");


// =====================================
// LOAD ACTIVE QUESTIONS
// =====================================

$questions = mysqli_query($conn,"
SELECT
q.question_id,
q.question,
q.difficulty,
c.category_name
FROM questions q
INNER JOIN categories c
ON q.category_id=c.category_id
WHERE q.status='Active'
ORDER BY c.category_name ASC,
q.question_id DESC
");
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Test Construction</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    background:#edf2fb;
    font-family:'Poppins',sans-serif;
}

/* =========================
MAIN
========================= */

.main{

    margin-left:230px;
    width:calc(100% - 230px);

    min-height:100vh;

    padding:30px;

}

/* =========================
TOPBAR
========================= */

.topbar{

    background:#fff;

    border-radius:18px;

    padding:22px 28px;

    margin-bottom:25px;

    box-shadow:0 4px 15px rgba(0,0,0,.08);

}

.topbar h1{

    font-size:32px;

    color:#111827;

}

.topbar p{

    margin-top:5px;

    color:#6b7280;

}

/* =========================
CARD
========================= */

.card{

    background:#fff;

    border-radius:18px;

    overflow:hidden;

    box-shadow:0 4px 15px rgba(0,0,0,.08);

}

.card-header{

    display:flex;

    justify-content:space-between;

    align-items:center;

    flex-wrap:wrap;

    gap:12px;

    padding:22px 24px;

    border-bottom:1px solid #e5e7eb;

}

.card-header h2{

    font-size:28px;

    color:#111827;

}

.header-actions{

    display:flex;

    gap:10px;

    flex-wrap:wrap;

}

/* =========================
BUTTONS
========================= */

.btn{

    border:none;

    border-radius:10px;

    padding:12px 18px;

    cursor:pointer;

    font-size:14px;

    font-weight:600;

    font-family:Poppins;

    transition:.25s;

}

.btn:hover{

    transform:translateY(-2px);

}

.btn-blue{

    background:#2563eb;

    color:#fff;

}

.btn-blue:hover{

    background:#1d4ed8;

}

.btn-green{

    background:#16a34a;

    color:#fff;

}

.btn-green:hover{

    background:#15803d;

}

.btn-outline{

    background:#fff;

    border:1px solid #d1d5db;

}

/* =========================
FORM
========================= */

.form-grid{

    display:grid;

    grid-template-columns:repeat(2,1fr);

    gap:20px;

    padding:24px;

    border-bottom:1px solid #e5e7eb;

}

.form-group label{

    display:block;

    margin-bottom:8px;

    font-weight:600;

    color:#374151;

}

.form-group input,
.form-group select,
.form-group textarea{

    width:100%;

    border:1px solid #d1d5db;

    border-radius:10px;

    padding:12px 15px;

    font-family:Poppins;

    font-size:14px;

}

.form-group input,
.form-group select{

    height:48px;

}

.form-group textarea{

    resize:vertical;

    min-height:90px;

}

.full-width{

    grid-column:1 / -1;

}

/* =========================
QUESTION SECTION
========================= */

.question-section{

    padding:24px;

}

.question-section h3{

    font-size:24px;

    margin-bottom:20px;

}

/* =========================
FILTERS
========================= */

.filters{

    display:flex;

    gap:15px;

    flex-wrap:wrap;

    margin-bottom:20px;

}

.filters input,
.filters select{

    height:48px;

    border:1px solid #d1d5db;

    border-radius:10px;

    padding:0 15px;

    font-family:Poppins;

}

.filters input{

    flex:1;

    min-width:280px;

}

.filters select{

    width:220px;

}

/* =========================
TABLE
========================= */

.table-wrapper{

    overflow-x:auto;

}

.question-table{

    width:100%;

    border-collapse:collapse;

}

.question-table th{

    background:#2563eb;

    color:#fff;

    text-align:left;

    padding:14px;

}

.question-table td{

    padding:14px;

    border-top:1px solid #e5e7eb;

    vertical-align:top;

}

/* =========================
BADGES
========================= */

.badge{

    display:inline-block;

    padding:6px 12px;

    border-radius:999px;

    font-size:12px;

    font-weight:bold;

}

.easy{

    background:#dcfce7;

    color:#166534;

}

.medium{

    background:#fef3c7;

    color:#92400e;

}

.hard{

    background:#fee2e2;

    color:#991b1b;

}

/* =========================
FOOTER
========================= */

.footer{

    padding:24px;

    display:flex;

    justify-content:space-between;

    align-items:center;

    flex-wrap:wrap;

    gap:15px;

    border-top:1px solid #e5e7eb;

}

/* =========================
RESPONSIVE
========================= */

@media(max-width:992px){

.main{

margin-left:0;

width:100%;

padding:85px 20px 20px;

}

.form-grid{

grid-template-columns:1fr;

}

}

@media(max-width:768px){

.card-header{

flex-direction:column;

align-items:stretch;

}

.header-actions{

flex-direction:column;

width:100%;

}

.header-actions .btn{

width:100%;

}

.filters{

flex-direction:column;

}

.filters input,
.filters select{

width:100%;

}

.footer{

flex-direction:column;

}

.footer .btn{

width:100%;

}

.question-table{

min-width:900px;

}

}

</style>

</head>

<body>

<?php include "admin_sidebar.php"; ?>

<main class="main">
    
    <!-- =========================
TOP BAR
========================= -->

<div class="topbar">

    <h1>Test Construction</h1>

    <p>
        Create a Mock Examination or Practice Quiz using questions from the Test Bank.
    </p>

</div>


<!-- =========================
CARD
========================= -->

<div class="card">


<!-- HEADER -->

<div class="card-header">

    <h2>Create New Examination</h2>

    <div class="header-actions">

        <button
        type="button"
        class="btn btn-outline"
        onclick="window.location='test_bank.php'">

            <i class="fa-solid fa-book"></i>

            Test Bank

        </button>

        <button
        type="submit"
        form="examForm"
        class="btn btn-green">

            <i class="fa-solid fa-floppy-disk"></i>

            Save Examination

        </button>

    </div>

</div>


<!-- =========================
FORM
========================= -->

<form
id="examForm"
action="save_exam.php"
method="POST">


<div class="form-grid">


<!-- Exam Title -->

<div class="form-group">

<label>Exam Title</label>

<input
type="text"
name="title"
required
placeholder="Enter examination title">

</div>


<!-- Category -->

<div class="form-group">

<label>Category</label>

<select
name="category_id"
required>

<option value="">
Select Category
</option>

<?php
mysqli_data_seek($categories,0);

while($cat=mysqli_fetch_assoc($categories)){
?>

<option value="<?php echo $cat['category_id']; ?>">

<?php echo htmlspecialchars($cat['category_name']); ?>

</option>

<?php
}
?>

</select>

</div>


<!-- Exam Type -->

<div class="form-group">

<label>Exam Type</label>

<select
name="exam_type"
required>

<option value="">
Select Type
</option>

<option value="Mock Exam">
Mock Exam
</option>

<option value="Practice Quiz">
Practice Quiz
</option>

</select>

</div>


<!-- Duration -->

<div class="form-group">

<label>Duration (Minutes)</label>

<input
type="number"
name="duration"
required
min="1"
placeholder="Example: 60">

</div>


<!-- Passing Score -->

<div class="form-group">

<label>Passing Score (%)</label>

<input
type="number"
name="passing_score"
required
value="75"
min="1"
max="100">

</div>


<!-- Status -->

<div class="form-group">

<label>Status</label>

<select
name="status"
required>

<option value="Draft">
Draft
</option>

<option value="Published">
Published
</option>

<option value="Closed">
Closed
</option>

</select>

</div>


<!-- Description -->

<!-- Description -->

<div class="form-group full-width">

<label>Description</label>

<textarea
name="description"
placeholder="Enter examination description (optional)">
</textarea>

</div>

<!-- Examination Instructions -->

<div class="form-group full-width">

<label>Examination Instructions</label>

<textarea
name="instructions"
placeholder="Example:

• Read every question carefully.
• Select only one answer.
• Do not refresh or close the browser.
• Once submitted, answers cannot be changed.
• Finish within the allotted time.">
</textarea>

</div>

<!-- Total Questions -->

<div class="form-group">

<label>Total Selected Questions</label>

<input

type="text"

id="totalQuestions"

value="0"

readonly>

</div>

</div>


<!-- =========================
QUESTION BANK
========================= -->

<div class="question-section">

<h3>

Question Bank

</h3>
    
    <!-- =========================
FILTERS
========================= -->

<div class="filters">

<input
type="text"
id="searchQuestion"
placeholder="Search question...">


<select id="categoryFilter">

<option value="">
All Categories
</option>

<?php

mysqli_data_seek($categories,0);

while($cat=mysqli_fetch_assoc($categories)){

?>

<option
value="<?php echo htmlspecialchars($cat['category_name']); ?>">

<?php echo htmlspecialchars($cat['category_name']); ?>

</option>

<?php

}

?>

</select>


<select id="difficultyFilter">

<option value="">
All Difficulty
</option>

<option value="Easy">
Easy
</option>

<option value="Medium">
Medium
</option>

<option value="Hard">
Hard
</option>

</select>

</div>


<?php

$totalQuestions = mysqli_num_rows($questions);

mysqli_data_seek($questions,0);

?>

<p style="margin-bottom:15px;color:#6b7280;">

Available Questions :

<strong>

<?php echo $totalQuestions; ?>

</strong>

</p>


<div class="table-wrapper">

<table class="question-table">

<thead>

<tr>

<th width="60">

<input
type="checkbox"
id="selectAll">

</th>

<th>Question</th>

<th width="230">
Category
</th>

<th width="120">
Difficulty
</th>

</tr>

</thead>

<tbody id="questionTable">

<?php

while($row=mysqli_fetch_assoc($questions)){

$class = strtolower($row['difficulty']);

?>

<tr>

<td>

<input
type="checkbox"
class="question-check"
name="questions[]"
value="<?php echo $row['question_id']; ?>">

</td>

<td>

<?php echo htmlspecialchars($row['question']); ?>

</td>

<td>

<?php echo htmlspecialchars($row['category_name']); ?>

</td>

<td>

<span class="badge <?php echo $class; ?>">

<?php echo htmlspecialchars($row['difficulty']); ?>

</span>

</td>

</tr>

<?php

}

?>

</tbody>

</table>

</div>
    
    <!-- =========================
FOOTER
========================= -->

<div class="footer">

    <div>

        <strong>Selected Questions :</strong>

        <span id="selectedCount">0</span>

    </div>

    <div style="display:flex;gap:10px;flex-wrap:wrap;">

        <button
        type="button"
        class="btn btn-outline"
        onclick="window.location='admin_dashboard.php'">

            Cancel

        </button>

        <button
        type="submit"
        class="btn btn-green">

            <i class="fa-solid fa-floppy-disk"></i>

            Save Examination

        </button>

    </div>

</div>

</div>

</form>

</div>

</main>


<script>

// =====================================
// SEARCH + FILTER
// =====================================

function filterQuestions(){

    let keyword =
    document.getElementById("searchQuestion")
    .value.toLowerCase();

    let category =
    document.getElementById("categoryFilter")
    .value;

    let difficulty =
    document.getElementById("difficultyFilter")
    .value;

    let rows =
    document.querySelectorAll("#questionTable tr");

    rows.forEach(function(row){

        let question =
        row.cells[1].innerText.toLowerCase();

        let cat =
        row.cells[2].innerText;

        let diff =
        row.cells[3].innerText;

        let show =
        question.includes(keyword)
        &&
        (category=="" || cat==category)
        &&
        (difficulty=="" || diff==difficulty);

        row.style.display = show ? "" : "none";

    });

}

document
.getElementById("searchQuestion")
.addEventListener("keyup",filterQuestions);

document
.getElementById("categoryFilter")
.addEventListener("change",filterQuestions);

document
.getElementById("difficultyFilter")
.addEventListener("change",filterQuestions);


// =====================================
// COUNT SELECTED QUESTIONS
// =====================================

function updateSelectedCount(){

    let total =
    document.querySelectorAll(
    ".question-check:checked"
    ).length;

    document.getElementById("selectedCount")
    .innerHTML = total;

    document.getElementById("totalQuestions")
    .value = total;

}


// =====================================
// CHECKBOX EVENTS
// =====================================

document
.querySelectorAll(".question-check")
.forEach(function(box){

    box.addEventListener(
    "change",
    updateSelectedCount
    );

});


// =====================================
// SELECT ALL
// =====================================

document
.getElementById("selectAll")
.addEventListener("change",function(){

    let status = this.checked;

    document
    .querySelectorAll(".question-check")
    .forEach(function(box){

        box.checked = status;

    });

    updateSelectedCount();

});


// =====================================
// FORM VALIDATION
// =====================================

document
.getElementById("examForm")
.addEventListener("submit",function(e){

    let total =
    document.querySelectorAll(
    ".question-check:checked"
    ).length;

    if(total==0){

        alert(
        "Please select at least one question from the Test Bank."
        );

        e.preventDefault();

        return;

    }

});

</script>

</body>
</html>