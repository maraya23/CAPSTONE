<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: /CAPSTONE/login.php');
    exit();
}

if ($_SESSION['usertype'] != 'admin') {
    header('Location: ../user.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang='en'>
<head>
<meta charset='UTF-8'>
<meta name='viewport' content='width=device-width, initial-scale=1.0'>
<title>Test Construction - e-Nurse</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet"> 
    
<link rel='stylesheet'
href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css'>

<style>

*{
    box-sizing:border-box;
}

body{
    margin:0;
    font-family:'Poppins',sans-serif;
    background:#edf2fb;
}

/* Main */

.main{
    margin-left:230px;
    width:calc(100% - 230px);
    min-height:100vh;
    padding:30px;
    box-sizing:border-box;
    overflow-x:auto;
}

/* Topbar */

.topbar{
    background:white;
    padding:18px 28px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    flex-wrap:wrap;
    gap:15px;
}

.topbar h1{
    margin:0;
    font-size:34px;
    color:#111827;
}

.topbar p{
    margin:4px 0 0;
    color:#6b7280;
}

.profile{
    display:flex;
    align-items:center;
    gap:14px;
}

.avatar{
    width:50px;
    height:50px;
    border-radius:50%;
    background:#dbeafe;
    display:flex;
    align-items:center;
    justify-content:center;
    color:#2563eb;
    font-size:24px;
}

.profile-info strong{
    display:block;
}

/* Content */

.content{
    padding:24px;
}

/* Card */

.card{
    background:white;
    border-radius:18px;
    box-shadow:0 4px 15px rgba(0,0,0,.08);
    overflow:hidden;
}

.card-header{
    padding:20px 24px;
    border-bottom:1px solid #e5e7eb;
    display:flex;
    justify-content:space-between;
    align-items:center;
    flex-wrap:wrap;
    gap:10px;
}

.card-header h2{
    margin:0;
    font-size:28px;
}

.header-actions{
    display:flex;
    gap:10px;
    flex-wrap:wrap;
}

/* Buttons */

.btn{
    border:none;
    border-radius:10px;
    padding:12px 18px;
    cursor:pointer;
    font-weight:bold;
}

.btn-outline{
    background:white;
    border:1px solid #d1d5db;
}

.btn-blue{
    background:#2563eb;
    color:white;
}

.btn-blue:hover{
    background:#1d4ed8;
}

.btn-green{
    background:#16a34a;
    color:white;
}

.btn-green:hover{
    background:#15803d;
}

.btn-red{
    background:white;
    color:#dc2626;
    border:1px solid #fca5a5;
}

/* Top form */

.top-form{
    padding:24px;
    display:grid;
    grid-template-columns:repeat(2,1fr);
    gap:20px;
    border-bottom:1px solid #e5e7eb;
}

.form-group label{
    display:block;
    margin-bottom:8px;
    font-weight:bold;
    color:#374151;
}

.form-group input,
.form-group select{
    width:100%;
    height:48px;
    padding:0 14px;
    border:1px solid #d1d5db;
    border-radius:10px;
    font-size:14px;
    font-family:'Poppins',sans-serif;
}

.form-group textarea{
    width:100%;
    min-height:120px;
    padding:14px;
    border:1px solid #d1d5db;
    border-radius:10px;
    font-size:14px;
    font-family:'Poppins',sans-serif;
    resize:vertical;
}

.form-group textarea{
    min-height:90px;
    resize:vertical;
}

/* Body */

.body{
    display:grid;
    grid-template-columns:280px 1fr;
    gap:0;
}

/* Outline */

.outline{
    border-right:1px solid #e5e7eb;
    padding:20px;
}

.outline h3{
    margin-top:0;
}

.section{
    margin-bottom:20px;
}

.section-title{
    font-weight:bold;
    margin-bottom:6px;
}

.question-list{
    margin-top:12px;
}

.question-item{
    padding:10px 12px;
    border-radius:8px;
    cursor:pointer;
    margin-bottom:8px;
}

.question-item.active{
    background:#2563eb;
    color:white;
}

.question-item:hover{
    background:#dbeafe;
}

.add-section{
    width:100%;
    margin-top:10px;
}

/* Editor */

.editor{
    padding:24px;
}

.editor-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:20px;
    flex-wrap:wrap;
    gap:10px;
}

.editor-header h3{
    margin:0;
    font-size:30px;
}

.choice{
    display:grid;
    grid-template-columns:50px 1fr 50px;
    gap:12px;
    align-items:center;
    margin-bottom:14px;
}

.choice-label{
    border:1px solid #d1d5db;
    border-radius:10px;
    height:46px;
    display:flex;
    align-items:center;
    justify-content:center;
    font-weight:bold;
    background:#f9fafb;
}

.choice input{
    width:100%;
    padding:12px 14px;
    border:1px solid #d1d5db;
    border-radius:10px;
}

.choice button{
    height:46px;
    border:1px solid #d1d5db;
    border-radius:10px;
    background:white;
    cursor:pointer;
}

.navigation{
    display:flex;
    justify-content:space-between;
    margin-top:28px;
    flex-wrap:wrap;
    gap:10px;
}

/* ===========================
   Responsive Design
=========================== */

@media (max-width:1200px){

    .top-form{
        grid-template-columns:repeat(2,1fr);
    }

    .body{
        grid-template-columns:1fr;
    }

    .outline{
        border-right:none;
        border-bottom:1px solid #e5e7eb;
    }

}

/* Tablet */

@media (max-width:992px){

    .main{
        margin-left:0;
        width:100%;
        padding:85px 20px 20px;
    }

    .topbar{
        flex-direction:column;
        align-items:flex-start;
        gap:18px;
    }

    .profile{
        width:100%;
        justify-content:flex-start;
        flex-wrap:wrap;
    }

    .card-header{
        flex-direction:column;
        align-items:flex-start;
    }

    .header-actions{
        width:100%;
        flex-wrap:wrap;
    }

    .header-actions .btn{
        flex:1;
        min-width:160px;
    }

}

/* Mobile */

@media (max-width:768px){

    .main{
        margin-left:0;
        width:100%;
        padding:80px 15px 20px;
    }

    .content{
        padding:0;
    }

    .topbar{
        padding:18px;
    }

    .topbar h1{
        font-size:26px;
    }

    .topbar p{
        font-size:14px;
    }

    .profile{
        gap:10px;
    }

    .avatar{
        width:42px;
        height:42px;
        font-size:18px;
    }

    .card-header h2{
        font-size:24px;
    }

    .top-form{
        grid-template-columns:1fr;
    }

    .header-actions{
        flex-direction:column;
        width:100%;
    }

    .header-actions .btn{
        width:100%;
    }

    .choice{
        grid-template-columns:45px 1fr 45px;
    }

    .choice input{
        min-width:0;
    }

    .navigation{
        flex-direction:column;
    }

    .navigation .btn{
        width:100%;
    }

    textarea{
        min-height:120px;
    }

}

/* Small Phones */

@media (max-width:480px){

    .topbar h1{
        font-size:22px;
    }

    .card{
        border-radius:14px;
    }

    .card-header{
        padding:18px;
    }

    .editor,
    .outline,
    .top-form{
        padding:18px;
    }

    .choice{
        grid-template-columns:40px 1fr 40px;
        gap:8px;
    }

    .choice-label{
        height:42px;
    }

    .choice button{
        height:42px;
    }

}
    
</style>
</head>

<body>

<?php include 'admin_sidebar.php'; ?>
 
    <!-- Main -->
    <main class='main'>

        <div class='topbar'>

    <div>
        <h1>Test Construction</h1>
        <p>Create and manage mock examination</p>
    </div>

    <div class='profile'>

        <i class='fa-regular fa-bell'></i>

        <div class='avatar'>
            <i class='fa-solid fa-user'></i>
        </div>

        <div class='profile-info'>
            <strong>Admin User</strong>
            <span>Administrator</span>
        </div>

        <i class='fa-solid fa-chevron-down'></i>

    </div>

</div>

        <div class='content'>

            <div class='card'>

                <!-- Header -->
                <div class='card-header'>
                    <h2>Create New Test</h2>

                    <div class='header-actions'>
                       <button class='btn btn-outline' onclick="window.history.back()">
    						Cancel
						</button>

                        <button class='btn btn-blue'>
                            <i class='fa-regular fa-eye'></i> Preview Test
                        </button>

                        <button class='btn btn-green'>
                            <i class='fa-regular fa-floppy-disk'></i> Save Test
                        </button>
                    </div>
                </div>

                <!-- Top Form -->
              <div class="top-form">

    <div class="form-group">
        <label>Test Title</label>
        <input type="text" placeholder="Enter Test Title">
    </div>

    <div class="form-group">
        <label>Category</label>
        <select>
            <option>Select Category</option>
            <option>Medical-Surgical Nursing</option>
            <option>Fundamentals of Nursing</option>
            <option>Maternal and Child Nursing</option>
            <option>Psychiatric Nursing</option>
            <option>Community Health Nursing</option>
        </select>
    </div>

    <div class="form-group">
        <label>Time Limit (minutes)</label>
        <input type="number" placeholder="Enter time limit">
    </div>

    <div class="form-group">
        <label>Passing Score (%)</label>
        <input type="number" placeholder="Enter passing score">
    </div>

    <div class="form-group">
        <label>Total Questions</label>
        <input type="number" placeholder="Total questions">
    </div>

</div>
                <!-- Body -->
                <div class='body'>

                    <!-- Outline -->
                    <aside class='outline'>

                        <h3>Test Outline</h3>

                        <div class="section">
    <div class="section-title">
        No section created yet
    </div>

    <div style="color:#6b7280">
        Add sections and questions from Test Banking
    </div>
</div>
                        
                     

                        <button class='btn btn-outline add-section' onclick="addSection()">
    <i class='fa-solid fa-plus'></i> Add Section
</button>

                    </aside>

                    <!-- Editor -->
                    <section class='editor'>

                        <div class='editor-header'>

                            <h3>New Question</h3>

                            <div class='header-actions'>
                                <button class='btn btn-red'>
                                    <i class='fa-regular fa-trash-can'></i> Remove Question
                                </button>

                                <button class='btn btn-outline'>
                                    <i class='fa-regular fa-copy'></i> Duplicate Question
                                </button>
                            </div>

                        </div>

                        <div class='form-group'>
                            <label>Question</label>

                           <textarea placeholder="Enter question here..."></textarea>
                        </div>

                        <div class='form-group'>
                            <label>Answer Choices</label>

                            <div class='choice'>
                                <div class='choice-label'>A</div>
                                <input type='text' placeholder='Enter answer choice'>
                                <button><i class='fa-solid fa-xmark'></i></button>
                            </div>

                            <div class='choice'>
                                <div class='choice-label'>B</div>
                                <input type='text' placeholder='Enter answer choice'>
                                <button><i class='fa-solid fa-xmark'></i></button>
                            </div>

                            <div class='choice'>
                                <div class='choice-label'>C</div>
                               <input type='text' placeholder='Enter answer choice'>
                                <button><i class='fa-solid fa-xmark'></i></button>
                            </div>

                            <div class='choice'>
                                <div class='choice-label'>D</div>
                               <input type='text' placeholder='Enter answer choice'>
                                <button><i class='fa-solid fa-xmark'></i></button>
                            </div>

                        </div>

                        <div class='form-group'>
                            <label>Correct Answer</label>

                           <select>
   							<option value="">Select correct answer</option>
    						<option>A</option>
    						<option>B</option>
    						<option>C</option>
    						<option>D</option>
						</select>
                        </div>

                        <div class='form-group'>
                            <label>Explanation (Optional)</label>

                           <textarea placeholder="Enter explanation (optional)"></textarea>
                        </div>

                        <div class='navigation'>

                          <button class='btn btn-outline' onclick="previousQuestion()">
    <i class='fa-solid fa-arrow-left'></i> Previous Question
</button>

<button class='btn btn-blue' onclick="nextQuestion()">
    Next Question <i class='fa-solid fa-arrow-right'></i>
</button>

                        </div>

                    </section>

                </div>

            </div>

        </div>

    </main>

    <script>

function previousQuestion(){
    alert("Previous question");
}

function nextQuestion(){
    alert("Next question");
}

</script>
    
    <script>

function addSection(){
    alert("New section added");
}

</script>
    
    <script>

document.querySelector('.btn-green').addEventListener('click', function(){
    alert("Test saved successfully!");
});


document.querySelector('.btn-blue').addEventListener('click', function(){
    alert("Opening test preview...");
});


document.querySelector('.btn-red').addEventListener('click', function(){
    alert("Question removed!");
});


</script>
    
</body>
</html>