<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: /CAPSTONE/login.php");
    exit();
}

if ($_SESSION['usertype'] != "admin") {
    header("Location: ../user.php");
    exit();
}

require_once "../connection.php";

/*=========================================
CHECK EXAM ID
=========================================*/

if (!isset($_GET['id'])) {
    header("Location: test_administration.php");
    exit();
}

$exam_id = (int)$_GET['id'];

/*=========================================
GET EXAM DETAILS
=========================================*/

$sql = "

SELECT

e.exam_id,
e.title,
e.description,
e.instructions,
e.exam_type,
e.duration,
e.total_questions,
e.passing_score,
e.status,
e.created_at,

c.category_name,

l.firstname,
l.middlename,
l.surname

FROM exams e

INNER JOIN categories c
ON e.category_id = c.category_id

INNER JOIN logintbl l
ON e.created_by = l.id

WHERE e.exam_id = ?

LIMIT 1

";

$stmt = mysqli_prepare($conn, $sql);

mysqli_stmt_bind_param(
    $stmt,
    "i",
    $exam_id
);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) == 0) {
    header("Location: test_administration.php");
    exit();
}

$exam = mysqli_fetch_assoc($result);

/*=========================================
GET EXAM QUESTIONS
=========================================*/

$qsql = "

SELECT

q.question_id,
q.question,

q.option_a,
q.option_b,
q.option_c,
q.option_d,

q.correct_answer,

q.rationale,

q.difficulty

FROM exam_items ei

INNER JOIN questions q
ON ei.question_id = q.question_id

WHERE ei.exam_id = ?

ORDER BY ei.exam_item_id ASC

";

$qstmt = mysqli_prepare($conn, $qsql);

mysqli_stmt_bind_param(
    $qstmt,
    "i",
    $exam_id
);

mysqli_stmt_execute($qstmt);

$questions = mysqli_stmt_get_result($qstmt);

$totalQuestions = mysqli_num_rows($questions);

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>View Examination</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    background:#edf2fb;
    font-family:'Poppins',sans-serif;
}

/* =========================
MAIN
========================= */

.main{
    margin-left:230px;
    width:calc(100% - 230px);
    min-height:100vh;
    padding:30px;
}

/* =========================
PAGE HEADER
========================= */

.page-header{
    background:#fff;
    border-radius:18px;
    padding:24px 28px;
    margin-bottom:25px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    flex-wrap:wrap;
    gap:15px;
    box-shadow:0 4px 15px rgba(0,0,0,.08);
}

.page-header h1{
    font-size:32px;
    color:#111827;
}

.page-header p{
    margin-top:5px;
    color:#6b7280;
}

/* =========================
BUTTONS
========================= */

.btn{
    border:none;
    border-radius:10px;
    padding:12px 18px;
    cursor:pointer;
    text-decoration:none;
    font-size:14px;
    font-weight:600;
    font-family:Poppins;
    display:inline-flex;
    align-items:center;
    gap:8px;
    transition:.25s;
}

.btn:hover{
    transform:translateY(-2px);
}

.btn-blue{
    background:#2563eb;
    color:white;
}

.btn-blue:hover{
    background:#1d4ed8;
}

/* =========================
CARD
========================= */

.card{
    background:white;
    border-radius:18px;
    overflow:hidden;
    margin-bottom:25px;
    box-shadow:0 4px 15px rgba(0,0,0,.08);
}

.card-header{
    padding:22px 25px;
    border-bottom:1px solid #e5e7eb;
}

.card-header h2{
    font-size:24px;
    color:#111827;
}

/* =========================
INFO GRID
========================= */

.info-grid{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:20px;
    padding:25px;
}

.info-box{
    background:#f8fafc;
    border-radius:12px;
    padding:18px;
}

.info-box label{
    display:block;
    color:#6b7280;
    margin-bottom:8px;
    font-size:13px;
}

.info-box strong{
    color:#111827;
    font-size:16px;
}

/* =========================
STATUS BADGES
========================= */

.badge{
    display:inline-block;
    padding:6px 14px;
    border-radius:999px;
    font-size:12px;
    font-weight:600;
}

.published{
    background:#dcfce7;
    color:#166534;
}

.draft{
    background:#fef3c7;
    color:#92400e;
}

.closed{
    background:#fee2e2;
    color:#991b1b;
}

/* =========================
DESCRIPTION
========================= */

.section{
    padding:25px;
    border-top:1px solid #e5e7eb;
}

.section h3{
    color:#111827;
    font-size:20px;
    margin-bottom:12px;
}

.section p{
    color:#374151;
    line-height:1.8;
    white-space:pre-line;
}

/* =========================
QUESTION LIST
========================= */

.question-container{
    padding:25px;
}

.question-box{
    border:1px solid #e5e7eb;
    border-radius:15px;
    padding:20px;
    margin-bottom:22px;
}

.question-number{
    color:#2563eb;
    font-size:15px;
    font-weight:700;
    margin-bottom:10px;
}

.question-text{
    font-size:17px;
    font-weight:600;
    color:#111827;
    margin-bottom:18px;
    line-height:1.6;
}

/* =========================
OPTIONS
========================= */

.choice{
    background:#f8fafc;
    border:1px solid #e5e7eb;
    border-radius:10px;
    padding:13px 15px;
    margin-bottom:10px;
}

.choice strong{
    color:#2563eb;
}

.correct{
    background:#dcfce7;
    border-color:#22c55e;
}

/* =========================
ANSWER BOX
========================= */

.answer-box{
    margin-top:18px;
    background:#eff6ff;
    border-left:4px solid #2563eb;
    border-radius:10px;
    padding:15px;
}

.answer-box strong{
    color:#2563eb;
}

/* =========================
RATIONALE
========================= */

.rationale{
    margin-top:15px;
    background:#fafafa;
    border-radius:10px;
    padding:15px;
    line-height:1.8;
    color:#374151;
}

/* =========================
EMPTY
========================= */

.empty{
    text-align:center;
    color:#6b7280;
    padding:45px;
    font-size:15px;
}

/* =========================
RESPONSIVE
========================= */

@media(max-width:992px){

.main{
    margin-left:0;
    width:100%;
    padding:85px 20px 20px;
}

.info-grid{
    grid-template-columns:repeat(2,1fr);
}

}

@media(max-width:768px){

.page-header{
    flex-direction:column;
    align-items:flex-start;
}

.page-header .btn{
    width:100%;
    justify-content:center;
}

.info-grid{
    grid-template-columns:1fr;
}

.question-box{
    padding:16px;
}

.question-text{
    font-size:16px;
}

}

</style>

</head>

<body>

<?php include "admin_sidebar.php"; ?>

<main class="main">

<!-- ==========================
PAGE HEADER
========================== -->


<div class="page-header">


<div>

<h1>
View Examination
</h1>


<p>
Review exam details and selected questions from Test Bank.
</p>


</div>



<a href="test_administration.php" class="btn btn-blue">

<i class="fa-solid fa-arrow-left"></i>

Back

</a>



</div>






<!-- ==========================
EXAM INFORMATION
========================== -->


<div class="card">


<div class="card-header">


<h2>

<?php echo htmlspecialchars($exam['title']); ?>

</h2>


</div>





<div class="info-grid">



<div class="info-box">

<label>
Exam Type
</label>

<strong>

<?php echo htmlspecialchars($exam['exam_type']); ?>

</strong>

</div>





<div class="info-box">

<label>
Category
</label>

<strong>

<?php echo htmlspecialchars($exam['category_name']); ?>

</strong>

</div>





<div class="info-box">

<label>
Duration
</label>

<strong>

<?php echo $exam['duration']; ?> Minutes

</strong>

</div>





<div class="info-box">

<label>
Total Questions
</label>

<strong>

<?php echo $exam['total_questions']; ?>

</strong>

</div>





<div class="info-box">

<label>
Passing Score
</label>

<strong>

<?php echo $exam['passing_score']; ?>%

</strong>

</div>





<div class="info-box">

<label>
Status
</label>


<?php

$statusClass = strtolower($exam['status']);

?>


<span class="badge <?php echo $statusClass; ?>">

<?php echo $exam['status']; ?>

</span>


</div>





<div class="info-box">

<label>
Created By
</label>

<strong>

<?php

echo htmlspecialchars(

$exam['firstname']." ".

$exam['middlename']." ".

$exam['surname']

);

?>

</strong>


</div>





<div class="info-box">

<label>
Created Date
</label>

<strong>

<?php

echo date(
"M d, Y",
strtotime($exam['created_at'])
);

?>

</strong>


</div>



</div>


</div>







<!-- ==========================
QUESTIONS
========================== -->


<div class="card">



<div class="card-header">


<h2>

Exam Questions

</h2>


</div>





<div class="question-container">



<?php



if(mysqli_num_rows($questions)>0){


$count = 1;



while($q=mysqli_fetch_assoc($questions)){



?>




<div class="question-box">



<div class="question-number">

Question <?php echo $count; ?>

</div>





<div class="question-text">

<?php echo htmlspecialchars($q['question']); ?>

</div>







<div class="choice 
<?php echo ($q['correct_answer']=="A") ? "correct" : ""; ?>">

<strong>A.</strong>

<?php echo htmlspecialchars($q['choice_a']); ?>

</div>






<div class="choice 
<?php echo ($q['correct_answer']=="B") ? "correct" : ""; ?>">

<strong>B.</strong>

<?php echo htmlspecialchars($q['choice_b']); ?>

</div>






<div class="choice 
<?php echo ($q['correct_answer']=="C") ? "correct" : ""; ?>">

<strong>C.</strong>

<?php echo htmlspecialchars($q['choice_c']); ?>

</div>






<div class="choice 
<?php echo ($q['correct_answer']=="D") ? "correct" : ""; ?>">

<strong>D.</strong>

<?php echo htmlspecialchars($q['choice_d']); ?>

</div>








<div class="answer-box">


<strong>
Correct Answer:
</strong>


<?php echo htmlspecialchars($q['correct_answer']); ?>


</div>





<?php if(!empty($q['explanation'])){ ?>


<div class="explanation">


<strong>
Explanation:
</strong>


<br>


<?php echo htmlspecialchars($q['explanation']); ?>


</div>



<?php } ?>





</div>





<?php


$count++;


}



}else{


?>


<div class="empty">

No questions found for this examination.

</div>


<?php


}



?>



</div>



</div>





</main>


</body>


</html>
    
    