<?php

session_start();

if(!isset($_SESSION['admin_id'])){

    header("Location: /CAPSTONE/login.php");
    exit();

}

if($_SESSION['usertype'] != "admin"){

    header("Location: ../user.php");
    exit();

}


include "../connection.php";


// ===============================
// CHECK EXAM ID
// ===============================

if(!isset($_GET['id'])){

    header("Location: test_administration.php");
    exit();

}


$exam_id = intval($_GET['id']);



// ===============================
// GET EXAM DETAILS
// ===============================

$sql = "

SELECT

e.exam_id,
e.title,
e.description,
e.exam_type,
e.duration,
e.total_questions,
e.passing_score,
e.status,
e.created_at,

c.category_name,

l.firstname,
l.middlename,
l.surname


FROM exams e


INNER JOIN categories c

ON e.category_id = c.category_id


INNER JOIN logintbl l

ON e.created_by = l.ID


WHERE e.exam_id = ?

";


$stmt = mysqli_prepare($conn,$sql);


mysqli_stmt_bind_param(
    $stmt,
    "i",
    $exam_id
);


mysqli_stmt_execute($stmt);


$result = mysqli_stmt_get_result($stmt);



if(mysqli_num_rows($result)==0){

    header("Location: test_administration.php");
    exit();

}



$exam = mysqli_fetch_assoc($result);




// ===============================
// GET EXAM QUESTIONS
// ===============================


$qsql = "

SELECT

q.question_id,
q.question,
q.choice_a,
q.choice_b,
q.choice_c,
q.choice_d,
q.correct_answer,
q.explanation,
q.difficulty


FROM exam_questions eq


INNER JOIN questions q

ON eq.question_id = q.question_id


WHERE eq.exam_id = ?


ORDER BY eq.exam_question_id ASC


";



$qstmt = mysqli_prepare($conn,$qsql);



mysqli_stmt_bind_param(
    $qstmt,
    "i",
    $exam_id
);



mysqli_stmt_execute($qstmt);



$questions = mysqli_stmt_get_result($qstmt);



?>

<!DOCTYPE html>

<html lang="en">

<head>


<meta charset="UTF-8">


<meta name="viewport" content="width=device-width, initial-scale=1.0">


<title>
View Exam - e-Nurse
</title>



<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">


<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">



<style>


*{

    margin:0;
    padding:0;
    box-sizing:border-box;

}



body{

    background:#edf2fb;

    font-family:'Poppins',sans-serif;

}




/* ==========================
MAIN
========================== */


.main{

    margin-left:230px;

    width:calc(100% - 230px);

    min-height:100vh;

    padding:30px;

}






/* ==========================
HEADER
========================== */


.page-header{

    background:white;

    padding:25px;

    border-radius:18px;

    box-shadow:0 4px 15px rgba(0,0,0,.08);

    margin-bottom:25px;

    display:flex;

    justify-content:space-between;

    align-items:center;

    flex-wrap:wrap;

    gap:15px;

}



.page-header h1{

    font-size:32px;

    color:#111827;

}



.page-header p{

    color:#6b7280;

    margin-top:5px;

}







/* ==========================
BUTTONS
========================== */


.btn{

    border:none;

    padding:12px 18px;

    border-radius:10px;

    cursor:pointer;

    font-family:'Poppins',sans-serif;

    font-weight:600;

    text-decoration:none;

    display:inline-flex;

    align-items:center;

    gap:8px;

}



.btn-blue{

    background:#2563eb;

    color:white;

}



.btn-blue:hover{

    background:#1d4ed8;

}






/* ==========================
CARD
========================== */


.card{

    background:white;

    border-radius:18px;

    box-shadow:0 4px 15px rgba(0,0,0,.08);

    margin-bottom:25px;

    overflow:hidden;

}



.card-header{

    padding:22px 25px;

    border-bottom:1px solid #e5e7eb;

}



.card-header h2{

    font-size:24px;

}






/* ==========================
DETAIL INFORMATION
========================== */


.info-grid{

    padding:25px;

    display:grid;

    grid-template-columns:repeat(3,1fr);

    gap:20px;

}



.info-box{

    background:#f8fafc;

    border-radius:12px;

    padding:18px;

}



.info-box label{

    display:block;

    color:#6b7280;

    font-size:13px;

    margin-bottom:6px;

}



.info-box strong{

    color:#111827;

    font-size:16px;

}






/* ==========================
STATUS BADGE
========================== */


.badge{

    display:inline-block;

    padding:6px 14px;

    border-radius:999px;

    font-size:12px;

    font-weight:600;

}



.published{

    background:#dcfce7;

    color:#166534;

}



.draft{

    background:#fef3c7;

    color:#92400e;

}



.closed{

    background:#fee2e2;

    color:#991b1b;

}






/* ==========================
QUESTION CARD
========================== */


.question-container{

    padding:25px;

}



.question-box{

    border:1px solid #e5e7eb;

    border-radius:15px;

    padding:20px;

    margin-bottom:20px;

}



.question-number{

    color:#2563eb;

    font-weight:700;

    margin-bottom:10px;

}



.question-text{

    font-size:16px;

    font-weight:600;

    margin-bottom:18px;

}





.choice{

    padding:12px 15px;

    background:#f8fafc;

    border-radius:10px;

    margin-bottom:10px;

    border:1px solid #e5e7eb;

}



.correct{

    background:#dcfce7;

    border-color:#16a34a;

}





.answer-box{

    margin-top:15px;

    padding:15px;

    background:#eff6ff;

    border-radius:10px;

}



.answer-box strong{

    color:#2563eb;

}





.explanation{

    margin-top:10px;

    color:#374151;

}





.empty{

    text-align:center;

    padding:40px;

    color:#6b7280;

}






/* ==========================
RESPONSIVE
========================== */


@media(max-width:992px){


.main{

    margin-left:0;

    width:100%;

    padding:85px 20px 20px;

}



.info-grid{

    grid-template-columns:1fr 1fr;

}


}





@media(max-width:768px){


.info-grid{

    grid-template-columns:1fr;

}



.page-header{

    flex-direction:column;

    align-items:flex-start;

}



.page-header .btn{

    width:100%;

    justify-content:center;

}



}


</style>

</head>


<body>


<?php include 'admin_sidebar.php'; ?>


<main class="main">



<!-- ==========================
PAGE HEADER
========================== -->


<div class="page-header">


<div>

<h1>
View Examination
</h1>


<p>
Review exam details and selected questions from Test Bank.
</p>


</div>



<a href="test_administration.php" class="btn btn-blue">

<i class="fa-solid fa-arrow-left"></i>

Back

</a>



</div>






<!-- ==========================
EXAM INFORMATION
========================== -->


<div class="card">


<div class="card-header">


<h2>

<?php echo htmlspecialchars($exam['title']); ?>

</h2>


</div>





<div class="info-grid">



<div class="info-box">

<label>
Exam Type
</label>

<strong>

<?php echo htmlspecialchars($exam['exam_type']); ?>

</strong>

</div>





<div class="info-box">

<label>
Category
</label>

<strong>

<?php echo htmlspecialchars($exam['category_name']); ?>

</strong>

</div>





<div class="info-box">

<label>
Duration
</label>

<strong>

<?php echo $exam['duration']; ?> Minutes

</strong>

</div>





<div class="info-box">

<label>
Total Questions
</label>

<strong>

<?php echo $exam['total_questions']; ?>

</strong>

</div>





<div class="info-box">

<label>
Passing Score
</label>

<strong>

<?php echo $exam['passing_score']; ?>%

</strong>

</div>





<div class="info-box">

<label>
Status
</label>


<?php

$statusClass = strtolower($exam['status']);

?>


<span class="badge <?php echo $statusClass; ?>">

<?php echo $exam['status']; ?>

</span>


</div>





<div class="info-box">

<label>
Created By
</label>

<strong>

<?php

echo htmlspecialchars(

$exam['firstname']." ".

$exam['middlename']." ".

$exam['surname']

);

?>

</strong>


</div>





<div class="info-box">

<label>
Created Date
</label>

<strong>

<?php

echo date(
"M d, Y",
strtotime($exam['created_at'])
);

?>

</strong>


</div>



</div>


</div>







<!-- ==========================
QUESTIONS
========================== -->


<div class="card">



<div class="card-header">


<h2>

Exam Questions

</h2>


</div>





<div class="question-container">



<?php



if(mysqli_num_rows($questions)>0){


$count = 1;



while($q=mysqli_fetch_assoc($questions)){



?>




<div class="question-box">



<div class="question-number">

Question <?php echo $count; ?>

</div>





<div class="question-text">

<?php echo htmlspecialchars($q['question']); ?>

</div>







<div class="choice 
<?php echo ($q['correct_answer']=="A") ? "correct" : ""; ?>">

<strong>A.</strong>

<?php echo htmlspecialchars($q['choice_a']); ?>

</div>






<div class="choice 
<?php echo ($q['correct_answer']=="B") ? "correct" : ""; ?>">

<strong>B.</strong>

<?php echo htmlspecialchars($q['choice_b']); ?>

</div>






<div class="choice 
<?php echo ($q['correct_answer']=="C") ? "correct" : ""; ?>">

<strong>C.</strong>

<?php echo htmlspecialchars($q['choice_c']); ?>

</div>






<div class="choice 
<?php echo ($q['correct_answer']=="D") ? "correct" : ""; ?>">

<strong>D.</strong>

<?php echo htmlspecialchars($q['choice_d']); ?>

</div>








<div class="answer-box">


<strong>
Correct Answer:
</strong>


<?php echo htmlspecialchars($q['correct_answer']); ?>


</div>





<?php if(!empty($q['explanation'])){ ?>


<div class="explanation">


<strong>
Explanation:
</strong>


<br>


<?php echo htmlspecialchars($q['explanation']); ?>


</div>



<?php } ?>





</div>





<?php


$count++;


}



}else{


?>


<div class="empty">

No questions found for this examination.

</div>


<?php


}



?>



</div>



</div>





</main>


</body>


</html>
    
    