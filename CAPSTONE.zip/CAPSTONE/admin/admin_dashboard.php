<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once __DIR__ . '/../connection.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

$admin_id = $_SESSION['admin_id'];

/* =========================
   ADMIN INFORMATION
========================= */

$adminName = "Administrator";

$stmt = mysqli_prepare($conn, "
    SELECT firstname, surname
    FROM logintbl
    WHERE id = ?
    LIMIT 1
");

mysqli_stmt_bind_param($stmt, "i", $admin_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($row = mysqli_fetch_assoc($result)) {
    $adminName = $row['firstname'] . " " . $row['surname'];
}

/* =========================
   DASHBOARD COUNTS
========================= */

// Registered Users
$totalUsers = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM logintbl WHERE usertype='user'")
)['total'];

$totalQuestions = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM questions")
)['total'];

$totalExams = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM exams")
)['total'];

$totalMaterials = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM review_materials")
)['total'];
?>

<!DOCTYPE html>

<html>

<head>

<meta charset='UTF-8'>

<meta name='viewport' content='width=device-width, initial-scale=1.0'>

<title>e-Nurse Admin Dashboard</title>

<link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css'>

<style>

body{
    margin:0;
    font-family:'Poppins',sans-serif;
    background:#f3f5fb;
}

.main{
    margin-left:230px;
    padding:30px;
}

.topbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:30px;
}

.topbar h1{
    font-size:32px;
    color:#111827;
    margin:0;
    font-weight:600;
}

.welcome{
    background:#fff;
    padding:12px 20px;
    border-radius:12px;
    box-shadow:0 2px 10px rgba(0,0,0,.06);
    font-size:15px;
    font-weight:500;
}

.cards{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:20px;
    margin-bottom:30px;
}

.card{
    background:#fff;
    padding:24px;
    border-radius:18px;
    text-align:center;
    box-shadow:0 4px 18px rgba(0,0,0,.08);
}

.icon{
    width:65px;
    height:65px;
    border-radius:16px;
    margin:0 auto 15px;
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:28px;
}

.blue{
    background:#e8f0ff;
    color:#2563eb;
}

.green{
    background:#e8f7ea;
    color:#2f9e44;
}

.yellow{
    background:#fff6db;
    color:#d4a000;
}

.purple{
    background:#f1e9ff;
    color:#7c3aed;
}

.card h3{
    color:#4b5563;
    margin-bottom:12px;
    font-size:18px;
    font-weight:600;
}

.num{
    font-size:42px;
    font-weight:700;
}

.panel{
    background:#fff;
    padding:28px;
    border-radius:18px;
    box-shadow:0 4px 18px rgba(0,0,0,.08);
}

.panel h2{
    margin-top:0;
    margin-bottom:20px;
    font-size:24px;
    font-weight:600;
}

.actions{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(220px,1fr));
    gap:20px;
}

.btn{
    display:flex;
    align-items:center;
    justify-content:center;
    gap:10px;
    text-decoration:none;
    color:#fff;
    padding:18px;
    border-radius:14px;
    font-weight:600;
    font-size:16px;
    transition:.25s;
}

.btn:hover{
    transform:translateY(-2px);
}

.btn-blue{
    background:#2563eb;
}

.btn-green{
    background:#34a853;
}

.btn-orange{
    background:#f97316;
}

.btn-purple{
    background:#7c3aed;
}
    
    @media (max-width:768px){

    .main,
    .content{
        margin-left:0 !important;
        padding:80px 20px 20px;
    }

}

</style>

</head>

<body>
    
    <?php include 'admin_sidebar.php'; ?>

<main class='main'>

<div class='topbar'>

<h1>Admin Dashboard</h1>

<div class='welcome'>
<i class='fa-solid fa-user'></i>
Welcome, <?php echo htmlspecialchars($adminName); ?>
</div>

</div>

<div class='cards'>

<div class='card'>
    <div class='icon blue'>
        <i class='fa-solid fa-users'></i>
    </div>

    <h3>Total Users</h3>

    <div class='num' style='color:#2563eb;'>
        <?php echo $totalUsers; ?>
    </div>
</div>

<div class='card'>
    <div class='icon green'>
        <i class='fa-solid fa-file-lines'></i>
    </div>

    <h3>Review Materials</h3>

    <div class='num' style='color:#2f9e44;'>
        <?php echo $totalMaterials; ?>
    </div>
</div>

<div class='card'>
    <div class='icon yellow'>
        <i class='fa-solid fa-circle-question'></i>
    </div>

    <h3>Total Questions</h3>

    <div class='num' style='color:#d4a000;'>
        <?php echo $totalQuestions; ?>
    </div>
</div>
    
<div class='card'>
    <div class='icon purple'>
        <i class='fa-solid fa-clipboard-check'></i>
    </div>

    <h3>Mock Exams</h3>

    <div class='num' style='color:#7c3aed;'>
        <?php echo $totalExams; ?>
    </div>
</div>
    
    <?php

$recentUsers = mysqli_query($conn,"
SELECT firstname,surname,created_at
FROM logintbl
WHERE usertype='user'
ORDER BY created_at DESC
LIMIT 5
");

?>
    
</div>

<div class='panel'>

<h2>Quick Actions</h2>

<div class='actions'>

<a href='announcement_management.php' class='btn btn-blue'>
    <i class='fa-solid fa-bullhorn'></i> Manage Announcements
</a>

<a href='manage_users.php' class='btn btn-green'><i class='fa-solid fa-users'></i> Manage Users</a>

<a href='review_management.php' class='btn btn-orange'>
    <i class='fa-solid fa-cloud-arrow-up'></i> Upload Review Material
</a>

<a href='test_construction.php' class='btn btn-purple'>
    <i class='fa-solid fa-clipboard-list'></i> Create Mock Exam
</a>

</div>

</div>

</main>

</body>

</html>