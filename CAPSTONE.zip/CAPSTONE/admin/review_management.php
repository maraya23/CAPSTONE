<?php

session_start();

require_once __DIR__ . '/../connection.php';

if (!isset($_SESSION['admin_id'])) {

    header('Location: /CAPSTONE/login.php');

    exit();

}

// Create upload folder if it doesn't exist

$uploadDir = __DIR__ . '/../uploads/review_materials/';

if (!is_dir($uploadDir)) {

    mkdir($uploadDir, 0777, true);

}

// Upload file

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $title = trim($_POST['title']);

    $category = trim($_POST['category']);

    $fileName = '';

    if (isset($_FILES['file']) && $_FILES['file']['error'] == 0) {

        $originalName = basename($_FILES['file']['name']);

        $fileName = time() . '_' . preg_replace('/[^A-Za-z0-9._-]/', '_', $originalName);

        move_uploaded_file($_FILES['file']['tmp_name'], $uploadDir . $fileName);

    }

    $stmt = mysqli_prepare($conn, 'INSERT INTO review_materials(title, category, file_name) VALUES(?,?,?)');

    mysqli_stmt_bind_param($stmt, 'sss', $title, $category, $fileName);

    mysqli_stmt_execute($stmt);

    mysqli_stmt_close($stmt);

    header('Location: review_management.php');

    exit();

}

// Delete

if (isset($_GET['delete'])) {

    $id = (int)$_GET['delete'];

    $result = mysqli_query($conn, "SELECT file_name FROM review_materials WHERE id=$id");

    if ($row = mysqli_fetch_assoc($result)) {

        $path = $uploadDir . $row['file_name'];

        if (file_exists($path)) unlink($path);

    }

    mysqli_query($conn, "DELETE FROM review_materials WHERE id=$id");

    header('Location: review_management.php');

    exit();

}

// Filters

$search = $_GET['search'] ?? '';

$categoryFilter = $_GET['category'] ?? '';

$sql = "SELECT * FROM review_materials WHERE 1=1";

if ($search != '') {

    $searchEsc = mysqli_real_escape_string($conn, $search);

    $sql .= " AND title LIKE '%$searchEsc%'";

}

if ($categoryFilter != '') {

    $catEsc = mysqli_real_escape_string($conn, $categoryFilter);

    $sql .= " AND category='$catEsc'";

}

$sql .= " ORDER BY id DESC";

$materials = mysqli_query($conn, $sql);

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Review Management</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{

    background:#f3f5fb;
    font-family:'Poppins',sans-serif;

}

.main{

    margin-left:230px;
    width:calc(100% - 230px);
    min-height:100vh;

    padding:30px;

}

.card{

    background:#fff;
    border-radius:18px;
    padding:28px;
    margin-bottom:25px;

    box-shadow:0 5px 18px rgba(0,0,0,.08);

}

.top{

    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:20px;
    flex-wrap:wrap;

}

.top h1{

    font-size:30px;
    color:#111827;
    font-weight:600;

}

.top p{

    margin-top:6px;
    color:#6b7280;

}

.btn{

    height:48px;

    padding:0 22px;

    border:none;

    border-radius:12px;

    background:#2563eb;

    color:#fff;

    font-size:14px;

    font-weight:600;

    cursor:pointer;

    display:inline-flex;

    align-items:center;

    justify-content:center;

    gap:8px;

    transition:.25s;

    text-decoration:none;

}

.btn:hover{

    background:#1d4ed8;

}

.filters{

    display:flex;
    align-items:center;
    gap:15px;
    flex-wrap:wrap;

    margin-top:25px;

}

.search-box{

    position:relative;
    flex:1;
    min-width:320px;
    max-width:500px;

}

.search-box input{

    width:100%;
    height:48px;

    padding-left:45px;
    padding-right:45px;

    border:1px solid #d1d5db;

    border-radius:12px;

    font-size:14px;

    background:white;

    transition:.25s;

}

.search-box input:focus{

    outline:none;

    border-color:#2563eb;

    box-shadow:0 0 0 4px rgba(37,99,235,.15);

}

.search-icon{

    position:absolute;

    left:15px;

    top:50%;

    transform:translateY(-50%);

    color:#9ca3af;

}

.clear-btn{

    position:absolute;

    right:12px;

    top:50%;

    transform:translateY(-50%);

    width:24px;

    height:24px;

    border:none;

    border-radius:50%;

    background:#e5e7eb;

    cursor:pointer;

    display:none;

}

select{

    width:260px;

    height:48px;

    border:1px solid #d1d5db;

    border-radius:12px;

    padding:0 15px;

    font-size:14px;

}

select:focus{

    outline:none;

    border-color:#2563eb;

    box-shadow:0 0 0 4px rgba(37,99,235,.15);

}

.upload-box{

    display:none;

    margin-top:30px;

    padding-top:25px;

    border-top:1px solid #eee;

}

.upload-box form{

    display:grid;

    gap:15px;

}
    
    .form-group{
    display:flex;
    flex-direction:column;
    gap:8px;
}

.form-group label{
    font-size:14px;
    font-weight:600;
    color:#374151;
}

.form-control{

    width:100%;
    height:48px;

    padding:0 15px;

    border:1px solid #d1d5db;
    border-radius:12px;

    background:#fff;

    font-size:14px;
    font-family:'Poppins',sans-serif;

    transition:.25s;

}

.form-control:focus{

    outline:none;

    border-color:#2563eb;

    box-shadow:0 0 0 4px rgba(37,99,235,.15);

}

.form-control::placeholder{

    color:#9ca3af;

}

.upload-box input,
.upload-box select{

    width:100%;

}

.table-responsive{

    width:100%;

    overflow-x:auto;

}

table{

    width:100%;
    min-width:900px;

    border-collapse:collapse;

}

th{

    background:#2563eb;

    color:white;

    padding:14px;

    text-align:left;

}

td{

    padding:14px;

    border-bottom:1px solid #e5e7eb;

}

.action-btn{

    display:inline-flex;

    align-items:center;

    gap:6px;

    padding:8px 14px;

    border-radius:8px;

    color:white;

    text-decoration:none;

    font-size:13px;

}

.view-btn{

    background:#2563eb;

}

.delete-btn{

    background:#dc2626;

}

@media(max-width:768px){

.main{

    margin-left:0;
    width:100%;
    padding:85px 15px 20px;

}

.top{

    flex-direction:column;
    align-items:flex-start;

}

.filters{

    flex-direction:column;
    align-items:stretch;

}

.search-box{

    max-width:100%;
    min-width:100%;

}

select{

    width:100%;

}

.btn{

    width:100%;

}

table{

    min-width:850px;

}

}
    
    .file-input{

    width:100%;

    padding:12px;

    border:2px dashed #cbd5e1;

    border-radius:12px;

    background:#f8fafc;

    cursor:pointer;

    font-family:'Poppins',sans-serif;

}

.file-input:hover{

    border-color:#2563eb;

    background:#eff6ff;

}

</style>

</head>

<body>

<?php include 'admin_sidebar.php'; ?>

<main class="main">

    <!-- Header Card -->
    <div class="card">

        <div class="top">

            <div>

                <h1>Review Management</h1>

                <p>Upload and manage review materials.</p>

            </div>

            <button class="btn"
                onclick="document.getElementById('uploadBox').style.display='block'">

                <i class="fa-solid fa-cloud-arrow-up"></i>
                Upload Review Material

            </button>

        </div>

        <!-- Search & Filter -->
        <form method="GET" class="filters">

            <div class="search-box">

                <i class="fa-solid fa-magnifying-glass search-icon"></i>

                <input
                    type="text"
                    id="searchInput"
                    name="search"
                    placeholder="Search review materials..."
                    value="<?php echo htmlspecialchars($search); ?>">

                <button
                    type="button"
                    class="clear-btn"
                    id="clearBtn"
                    onclick="clearSearch()">

                    &times;

                </button>

            </div>

            <select name="category">

                <option value="">All Categories</option>

                <option value="Fundamentals of Nursing"
                    <?php if($categoryFilter=="Fundamentals of Nursing") echo "selected"; ?>>
                    Fundamentals of Nursing
                </option>

                <option value="Medical-Surgical Nursing"
                    <?php if($categoryFilter=="Medical-Surgical Nursing") echo "selected"; ?>>
                    Medical-Surgical Nursing
                </option>

                <option value="Maternal and Child Nursing"
                    <?php if($categoryFilter=="Maternal and Child Nursing") echo "selected"; ?>>
                    Maternal and Child Nursing
                </option>

                <option value="Psychiatric Nursing"
                    <?php if($categoryFilter=="Psychiatric Nursing") echo "selected"; ?>>
                    Psychiatric Nursing
                </option>

                <option value="Community Health Nursing"
                    <?php if($categoryFilter=="Community Health Nursing") echo "selected"; ?>>
                    Community Health Nursing
                </option>

            </select>

            <button type="submit" class="btn">

                <i class="fa-solid fa-filter"></i>

                Filter

            </button>

        </form>

        <!-- Upload Form -->
        <div id="uploadBox" class="upload-box">

            <h3 style="margin-bottom:20px;">

                Upload Review Material

            </h3>

            <form method="POST" enctype="multipart/form-data">

                <div class="form-group">

    <label for="title">Material Title</label>

    <input
        type="text"
        id="title"
        name="title"
        class="form-control"
        placeholder="Enter review material title"
        required>

</div>

               <div class="form-group">

<label>Category</label>

<select name="category" class="form-control" required>

                    <option value="">Select Category</option>

                    <option value="Fundamentals of Nursing">
                        Fundamentals of Nursing
                    </option>

                    <option value="Medical-Surgical Nursing">
                        Medical-Surgical Nursing
                    </option>

                    <option value="Maternal and Child Nursing">
                        Maternal and Child Nursing
                    </option>

                    <option value="Psychiatric Nursing">
                        Psychiatric Nursing
                    </option>

                    <option value="Community Health Nursing">
                        Community Health Nursing
                    </option>

                </select>
                </div>

                <div class="form-group">

<label>Upload File</label>

<input
    type="file"
    name="file"
    class="file-input"
    required>

</div>

                <button class="btn" type="submit">

                    <i class="fa-solid fa-floppy-disk"></i>

                    Save Material

                </button>

            </form>

        </div>

    </div>

    <!-- Materials Table -->
    <div class="card">

        <div class="table-responsive">

            <table>

                <tr>

                    <th>Review Material</th>
                    <th>Category</th>
                    <th>File</th>
                    <th>Date</th>
                    <th>Actions</th>

                </tr>
                
<?php while($row = mysqli_fetch_assoc($materials)) { ?>

<tr>

    <td>
        <?php echo htmlspecialchars($row['title']); ?>
    </td>

    <td>
        <?php echo htmlspecialchars($row['category']); ?>
    </td>

    <td>

        <?php if(!empty($row['file_name'])){ ?>

            <a href="/CAPSTONE/uploads/review_materials/<?php echo urlencode($row['file_name']); ?>"
               target="_blank"
               class="action-btn view-btn">

                <i class="fa-solid fa-eye"></i>

                View File

            </a>

        <?php } else { ?>

            <span style="color:#9ca3af;">
                No File
            </span>

        <?php } ?>

    </td>

    <td>

        <?php
        if(!empty($row['created_at'])){

            echo date("M d, Y", strtotime($row['created_at']));

        }else{

            echo "-";

        }
        ?>

    </td>

    <td>

        <a href="?delete=<?php echo $row['id']; ?>"
           class="action-btn delete-btn"
           onclick="return confirm('Delete this review material?');">

            <i class="fa-solid fa-trash"></i>

            Delete

        </a>

    </td>

</tr>

<?php } ?>

</table>

</div>

</div>

</main>

<script>

const searchInput = document.getElementById("searchInput");

const clearBtn = document.getElementById("clearBtn");

function toggleClearButton(){

    if(searchInput.value.trim() !== ""){

        clearBtn.style.display = "block";

    }else{

        clearBtn.style.display = "none";

    }

}

function clearSearch(){

    window.location.href = "review_management.php";

}

searchInput.addEventListener("input", toggleClearButton);

toggleClearButton();

</script>

</body>

</html>

<script>

const searchInput = document.getElementById('searchInput');

const clearBtn = document.getElementById('clearBtn');

function toggleClearButton() {

    clearBtn.style.display = searchInput.value.trim() !== '' ? 'block' : 'none';

}

function clearSearch() {

    // Reload page without search and category parameters

    window.location.href = 'review_management.php';

}

// Show or hide the X button while typing

searchInput.addEventListener('input', toggleClearButton);

// Run once when the page loads

toggleClearButton();

</script>

</body>

</html>