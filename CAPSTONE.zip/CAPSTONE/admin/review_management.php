<?php

session_start();

require_once "../connection.php";


/*========================================
 ADMIN AUTHENTICATION
========================================*/


if(!isset($_SESSION['admin_id'])){

    header("Location: ../login.php");
    exit();

}


if(strtolower($_SESSION['usertype']) != "admin"){

    header("Location: ../user.php");
    exit();

}



/*========================================
 UPLOAD DIRECTORY
========================================*/


$uploadDir = __DIR__ . "/../uploads/review_materials/";


if(!is_dir($uploadDir)){

    mkdir($uploadDir,0777,true);

}



/*========================================
 LOAD CATEGORIES
========================================*/


$categories = mysqli_query(
    $conn,
    "
    SELECT category_id, category_name
    FROM categories
    WHERE status='Active'
    ORDER BY category_name ASC
    "
);



/*========================================
 UPLOAD REVIEW MATERIAL
========================================*/


if($_SERVER["REQUEST_METHOD"]=="POST"){


    $title = trim($_POST['title']);

    $category_id = intval($_POST['category_id']);

    $description = trim($_POST['description']);


    $uploaded_by = $_SESSION['admin_id'];


    $fileName = "";



    if(isset($_FILES['file']) && $_FILES['file']['error']==0){


        $allowed = [
            "pdf",
            "doc",
            "docx",
            "ppt",
            "pptx"
        ];



        $extension = strtolower(
            pathinfo(
                $_FILES['file']['name'],
                PATHINFO_EXTENSION
            )
        );



        if(!in_array($extension,$allowed)){


            header(
                "Location: review_management.php?error=filetype"
            );

            exit();

        }



        if($_FILES['file']['size'] > 10*1024*1024){


            header(
                "Location: review_management.php?error=filesize"
            );

            exit();

        }




        $fileName =
        time()
        ."_".
        preg_replace(
            "/[^A-Za-z0-9._-]/",
            "_",
            basename($_FILES['file']['name'])
        );



        move_uploaded_file(
            $_FILES['file']['tmp_name'],
            $uploadDir.$fileName
        );


    }





    $sql="
    INSERT INTO review_materials
    (
        category_id,
        title,
        description,
        file_name,
        uploaded_by
    )

    VALUES
    (?,?,?,?,?)

    ";



    $stmt=mysqli_prepare($conn,$sql);



    mysqli_stmt_bind_param(
        $stmt,
        "isssi",
        $category_id,
        $title,
        $description,
        $fileName,
        $uploaded_by
    );



    mysqli_stmt_execute($stmt);



    mysqli_stmt_close($stmt);



    header(
        "Location: review_management.php?success=upload"
    );

    exit();


}






/*========================================
 DELETE MATERIAL
========================================*/


if(isset($_GET['delete'])){


    $id=intval($_GET['delete']);



    $stmt=mysqli_prepare(
        $conn,
        "
        SELECT file_name
        FROM review_materials
        WHERE material_id=?
        "
    );



    mysqli_stmt_bind_param(
        $stmt,
        "i",
        $id
    );



    mysqli_stmt_execute($stmt);



    $result=mysqli_stmt_get_result($stmt);



    if($row=mysqli_fetch_assoc($result)){



        if(!empty($row['file_name'])){


            $file=$uploadDir.$row['file_name'];



            if(file_exists($file)){


                unlink($file);


            }


        }


    }



    mysqli_stmt_close($stmt);




    $stmt=mysqli_prepare(
        $conn,
        "
        DELETE FROM review_materials
        WHERE material_id=?
        "
    );



    mysqli_stmt_bind_param(
        $stmt,
        "i",
        $id
    );



    mysqli_stmt_execute($stmt);



    mysqli_stmt_close($stmt);



    header(
        "Location: review_management.php?success=deleted"
    );

    exit();


}







/*========================================
 SEARCH AND FILTER
========================================*/


$search="";

$categoryFilter="";



if(isset($_GET['search'])){

    $search=trim($_GET['search']);

}



if(isset($_GET['category'])){

    $categoryFilter=trim($_GET['category']);

}




$sql="
SELECT

rm.*,

c.category_name,

CONCAT(
l.firstname,' ',
l.surname
)
AS uploader


FROM review_materials rm


INNER JOIN categories c

ON rm.category_id=c.category_id


INNER JOIN logintbl l

ON rm.uploaded_by=l.id


WHERE 1=1

";





if($search!=""){


    $safe=mysqli_real_escape_string(
        $conn,
        $search
    );


    $sql.="

    AND rm.title LIKE '%$safe%'

    ";


}




if($categoryFilter!=""){


    $safe=mysqli_real_escape_string(
        $conn,
        $categoryFilter
    );


    $sql.="

    AND rm.category_id='$safe'

    ";

}




$sql.="

ORDER BY rm.material_id DESC

";



$materials=mysqli_query(
    $conn,
    $sql
);



?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Review Management | e-Nurse</title>


<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">


<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap"
rel="stylesheet">


<link rel="stylesheet" href="review_management.css">

    <style>
        
        *{
    margin:0;
    padding:0;
    box-sizing:border-box;
}


body{

    background:#f3f5fb;
    font-family:'Poppins',sans-serif;

}



/*========================
MAIN CONTENT
========================*/


.main{

    margin-left:230px;

    width:calc(100% - 230px);

    min-height:100vh;

    padding:30px;

}





/*========================
CARD
========================*/


.card{

    background:white;

    padding:28px;

    border-radius:20px;

    margin-bottom:25px;

    box-shadow:0 5px 18px rgba(0,0,0,.08);

}





/*========================
HEADER
========================*/


.top{

    display:flex;

    justify-content:space-between;

    align-items:center;

    gap:20px;

    flex-wrap:wrap;

}



.top h1{

    font-size:30px;

    color:#111827;

}



.top p{

    color:#6b7280;

    margin-top:5px;

}





/*========================
BUTTON
========================*/


.btn{

    display:inline-flex;

    align-items:center;

    justify-content:center;

    gap:8px;

    padding:13px 22px;

    border:none;

    border-radius:12px;

    background:#2563eb;

    color:white;

    font-weight:600;

    cursor:pointer;

    text-decoration:none;

}



.btn:hover{

    background:#1d4ed8;

}





/*========================
ALERT
========================*/


.success,
.error{


    padding:15px;

    border-radius:12px;

    margin-bottom:20px;

    font-weight:600;

}



.success{

    background:#ecfdf5;

    color:#166534;

    border-left:5px solid #22c55e;

}



.error{

    background:#fef2f2;

    color:#991b1b;

    border-left:5px solid #ef4444;

}





/*========================
FILTER
========================*/


.filters{

    display:flex;

    gap:15px;

    margin-top:25px;

    flex-wrap:wrap;

}



/*========================
SEARCH BOX
========================*/


.search-box{

    position:relative;

    flex:1;

    min-width:300px;

}



.search-box input{

    width:100%;

    height:48px;

    padding-left:45px;

    padding-right:45px;

    border:1px solid #d1d5db;

    border-radius:12px;

    font-size:14px;

    font-family:'Poppins',sans-serif;

}



.search-box input:focus{

    outline:none;

    border-color:#2563eb;

    box-shadow:0 0 0 4px rgba(37,99,235,.15);

}





/* Magnifying Glass */

.search-icon{


    position:absolute;

    left:16px;

    top:50%;

    transform:translateY(-50%);

    color:#9ca3af;

    font-size:15px;

    pointer-events:none;


}





/* X Clear Button */

.clear-btn{


    position:absolute;

    right:12px;

    top:50%;

    transform:translateY(-50%);


    width:26px;

    height:26px;


    border:none;

    border-radius:50%;


    background:#e5e7eb;

    color:#6b7280;


    font-size:18px;

    line-height:26px;


    cursor:pointer;


    display:flex;

    align-items:center;

    justify-content:center;


}



.clear-btn:hover{


    background:#d1d5db;

    color:#111827;


}




select{

    height:48px;

    min-width:250px;

    border:1px solid #d1d5db;

    border-radius:12px;

    padding:0 15px;

}





/*========================
UPLOAD FORM
========================*/


.upload-box{

    display:none;

    margin-top:30px;

    border-top:1px solid #e5e7eb;

    padding-top:25px;

}



.form-group{

    margin-bottom:18px;

    display:flex;

    flex-direction:column;

    gap:8px;

}



.form-group label{

    font-weight:600;

    color:#374151;

}



.form-control{

    width:100%;

    padding:12px 15px;

    border:1px solid #d1d5db;

    border-radius:12px;

    font-family:'Poppins';

}



textarea.form-control{

    resize:none;

}



.file-input{

    padding:12px;

    border:2px dashed #cbd5e1;

    border-radius:12px;

    background:#f8fafc;

}





/*========================
TABLE
========================*/


.table-responsive{

    overflow-x:auto;

}



table{

    width:100%;

    min-width:1000px;

    border-collapse:collapse;

}



thead th{

    background:#2563eb;

    color:white;

    padding:14px;

    text-align:left;

}



td{

    padding:14px;

    border-bottom:1px solid #e5e7eb;

}





/*========================
BADGE
========================*/


.badge{


    background:#eff6ff;

    color:#2563eb;

    padding:6px 12px;

    border-radius:20px;

    font-size:13px;

    font-weight:600;


}






/*========================
ACTION BUTTON
========================*/


.action-btn{


    display:inline-flex;

    align-items:center;

    gap:6px;

    padding:8px 14px;

    color:white;

    border-radius:8px;

    text-decoration:none;

    font-size:13px;


}



.view-btn{

    background:#2563eb;

}



.delete-btn{

    background:#dc2626;

}





/*========================
MOBILE
========================*/


@media(max-width:768px){


.main{


    margin-left:0;

    width:100%;

    padding:80px 15px 20px;


}




.top{

    flex-direction:column;

    align-items:flex-start;

}



.top h1{

    font-size:24px;

}



.btn{

    width:100%;

}



.filters{

    flex-direction:column;

}



.search-box{

    min-width:100%;

}



select{

    width:100%;

}



table{

    min-width:900px;

}



.card{

    padding:20px;

}



}
        
    </style>

</head>


<body>


<?php include 'admin_sidebar.php'; ?>



<main class="main">



<!-- ===========================
HEADER CARD
=========================== -->


<div class="card">


<?php


if(isset($_GET['success'])){


    if($_GET['success']=="upload"){


        echo '

        <div class="success">

        <i class="fa-solid fa-circle-check"></i>

        Review material uploaded successfully.

        </div>

        ';


    }



    if($_GET['success']=="deleted"){


        echo '

        <div class="success">

        <i class="fa-solid fa-trash"></i>

        Review material deleted successfully.

        </div>

        ';


    }


}




if(isset($_GET['error'])){


    if($_GET['error']=="filetype"){


        echo '

        <div class="error">

        <i class="fa-solid fa-circle-xmark"></i>

        Only PDF, DOC, DOCX, PPT and PPTX files are allowed.

        </div>

        ';


    }



    if($_GET['error']=="filesize"){


        echo '

        <div class="error">

        <i class="fa-solid fa-circle-xmark"></i>

        Maximum upload size is 10MB.

        </div>

        ';


    }


}



?>




<div class="top">


<div>


<h1>

Review Management

</h1>


<p>

Upload, organize and manage nursing review materials.

</p>


</div>




<button

type="button"

class="btn"

onclick="showUpload()">


<i class="fa-solid fa-cloud-arrow-up"></i>


Upload Review Material


</button>



</div>







<!-- ===========================
SEARCH FILTER
=========================== -->



<form method="GET" class="filters">



<div class="search-box">


<i class="fa-solid fa-magnifying-glass search-icon"></i>


<input

type="text"

name="search"

id="searchInput"

placeholder="Search review materials..."

value="<?php echo htmlspecialchars($search); ?>">



<button

type="button"

class="clear-btn"

onclick="clearSearch()">

<i class="fa-solid fa-xmark"></i>

</button>



</div>







<select name="category">


<option value="">

All Categories

</option>



<?php


mysqli_data_seek($categories,0);



while($cat=mysqli_fetch_assoc($categories)){


?>


<option

value="<?php echo $cat['category_id']; ?>"

<?php

if($categoryFilter==$cat['category_id']){

echo "selected";

}

?>

>


<?php

echo htmlspecialchars(
    $cat['category_name']
);

?>


</option>



<?php

}


?>



</select>







<button

type="submit"

class="btn">


<i class="fa-solid fa-filter"></i>


Filter


</button>



</form>







<!-- ===========================
UPLOAD FORM
=========================== -->



<div id="uploadBox" class="upload-box">



<h3>

<i class="fa-solid fa-file-circle-plus"></i>

Upload Review Material

</h3>





<form

method="POST"

enctype="multipart/form-data">







<div class="form-group">


<label>

Title

</label>



<input

type="text"

name="title"

class="form-control"

placeholder="Example: Fundamentals of Nursing Module 1"

required>


</div>







<div class="form-group">


<label>

Category

</label>



<select

name="category_id"

class="form-control"

required>



<option value="">

Select Category

</option>




<?php


mysqli_data_seek($categories,0);



while($cat=mysqli_fetch_assoc($categories)){


?>


<option

value="<?php echo $cat['category_id']; ?>"

>


<?php

echo htmlspecialchars(
$cat['category_name']
);

?>


</option>



<?php

}


?>



</select>



</div>








<div class="form-group">


<label>

Description

</label>



<textarea

name="description"

class="form-control"

rows="4"

placeholder="Enter short description of the material">

</textarea>



</div>







<div class="form-group">


<label>

Upload File

</label>



<input

type="file"

name="file"

class="file-input"

accept=".pdf,.doc,.docx,.ppt,.pptx"

required>


<small>

Allowed:
<strong>
PDF, DOC, DOCX, PPT, PPTX
</strong>

<br>

Maximum:
<strong>
10MB
</strong>

</small>



</div>







<button

type="submit"

class="btn">


<i class="fa-solid fa-floppy-disk"></i>


Save Review Material


</button>





</form>




</div>




</div>
    
    <!-- ===========================
REVIEW MATERIALS TABLE
=========================== -->


<div class="card">


<h2 style="margin-bottom:20px;">

<i class="fa-solid fa-folder-open"></i>

Uploaded Review Materials

</h2>





<div class="table-responsive">


<table>


<thead>


<tr>


<th>
Title
</th>


<th>
Category
</th>


<th>
Uploaded By
</th>


<th>
File
</th>


<th>
Date Uploaded
</th>


<th>
Status
</th>


<th>
Action
</th>


</tr>


</thead>





<tbody>



<?php



if(mysqli_num_rows($materials)>0){



while($row=mysqli_fetch_assoc($materials)){



?>



<tr>




<td>


<strong>


<?php

echo htmlspecialchars(
$row['title']
);

?>


</strong>



<br>



<small style="color:#6b7280;">


<?php

echo htmlspecialchars(
$row['description']
);

?>


</small>



</td>






<td>


<span class="badge">


<?php

echo htmlspecialchars(
$row['category_name']
);

?>


</span>



</td>








<td>


<?php

echo htmlspecialchars(
$row['uploader']
);

?>


</td>









<td>



<?php


if(!empty($row['file_name'])){


?>



<a


href="../uploads/review_materials/<?php echo urlencode($row['file_name']); ?>"


target="_blank"


class="action-btn view-btn"



>


<i class="fa-solid fa-file"></i>


View



</a>




<?php


}else{


echo "

<span style='color:#9ca3af;'>

No File

</span>

";


}



?>



</td>








<td>


<?php


echo date(
"M d, Y",
strtotime($row['uploaded_at'])
);


?>


</td>









<td>



<?php


if($row['status']=="Active"){



echo '

<span style="

background:#dcfce7;

color:#166534;

padding:6px 12px;

border-radius:20px;

font-size:13px;

font-weight:600;

">

Active

</span>

';



}else{



echo '

<span style="

background:#fee2e2;

color:#991b1b;

padding:6px 12px;

border-radius:20px;

font-size:13px;

font-weight:600;

">

Hidden

</span>

';



}



?>



</td>








<td>



<a


href="review_management.php?delete=<?php echo $row['material_id']; ?>"


class="action-btn delete-btn"


onclick="return confirm('Delete this review material?');"



>


<i class="fa-solid fa-trash"></i>


Delete


</a>




</td>






</tr>




<?php



}



}else{



?>



<tr>


<td colspan="7" style="text-align:center;padding:40px;">



<i class="fa-solid fa-folder-open"

style="font-size:40px;color:#9ca3af;display:block;margin-bottom:15px;">

</i>



No review materials found.



</td>


</tr>



<?php



}



?>





</tbody>



</table>



</div>




</div>





</main>





<script>


function showUpload(){


    document.getElementById("uploadBox").style.display="block";


}





function clearSearch(){


    window.location.href="review_management.php";


}






setTimeout(function(){


let msg=document.querySelector(".success");


let err=document.querySelector(".error");



if(msg){


msg.style.opacity="0";


}



if(err){


err.style.opacity="0";


}



},4000);



</script>



</body>


</html>