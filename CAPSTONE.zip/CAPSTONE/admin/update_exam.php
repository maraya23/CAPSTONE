<?php

session_start();


if(!isset($_SESSION['admin_id'])){

    header("Location: ../login.php");
    exit();

}


if($_SESSION['usertype'] != "admin"){

    header("Location: ../user.php");
    exit();

}


include "../connection.php";




// ==============================
// CHECK REQUEST
// ==============================


if($_SERVER['REQUEST_METHOD'] != "POST"){

    header("Location:test_administration.php");
    exit();

}




$exam_id = intval($_POST['exam_id']);

$title = trim($_POST['title']);

$category_id = intval($_POST['category_id']);

$exam_type = $_POST['exam_type'];

$duration = intval($_POST['duration']);

$passing_score = intval($_POST['passing_score']);

$status = $_POST['status'];





if(isset($_POST['questions'])){


    $questions = $_POST['questions'];


}else{


    $questions = [];


}




$total_questions = count($questions);






// ==============================
// UPDATE EXAM
// ==============================


$sql = "

UPDATE exams

SET

title=?,

category_id=?,

exam_type=?,

duration=?,

total_questions=?,

passing_score=?,

status=?


WHERE exam_id=?

";




$stmt=mysqli_prepare($conn,$sql);



mysqli_stmt_bind_param(

$stmt,

"sisiiisi",

$title,

$category_id,

$exam_type,

$duration,

$total_questions,

$passing_score,

$status,

$exam_id

);



$update=mysqli_stmt_execute($stmt);





if(!$update){


    die("Update Error: ".mysqli_error($conn));


}







// ==============================
// REMOVE OLD QUESTIONS
// ==============================


$delete=mysqli_query($conn,

"

DELETE FROM exam_items

WHERE exam_id='$exam_id'

"

);






// ==============================
// INSERT NEW QUESTIONS
// ==============================


if(!empty($questions)){



    foreach($questions as $question_id){



        $question_id=intval($question_id);



        mysqli_query($conn,

        "

        INSERT INTO exam_items

        (

        exam_id,

        question_id

        )


        VALUES

        (

        '$exam_id',

        '$question_id'

        )

        "

        );



    }



}








// ==============================
// SUCCESS
// ==============================


echo "

<script>

alert('Exam updated successfully!');

window.location='test_administration.php';

</script>

";



?>

