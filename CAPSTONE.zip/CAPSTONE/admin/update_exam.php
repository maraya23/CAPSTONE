<?php

session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

if ($_SESSION['usertype'] != "admin") {
    header("Location: ../user.php");
    exit();
}

include "../connection.php";


// =====================================
// CHECK REQUEST
// =====================================

if ($_SERVER['REQUEST_METHOD'] != "POST") {
    header("Location: test_administration.php");
    exit();
}


// =====================================
// GET FORM DATA
// =====================================

$exam_id          = (int)$_POST['exam_id'];
$title            = trim($_POST['title']);
$description      = trim($_POST['description']);
$instructions     = trim($_POST['instructions']);
$category_id      = (int)$_POST['category_id'];
$exam_type        = $_POST['exam_type'];
$duration         = (int)$_POST['duration'];
$passing_score    = (int)$_POST['passing_score'];
$status           = $_POST['status'];

$questions = isset($_POST['questions'])
    ? $_POST['questions']
    : [];

$total_questions = count($questions);


// =====================================
// UPDATE EXAM
// =====================================

$sql = "

UPDATE exams

SET

title=?,
description=?,
instructions=?,
category_id=?,
exam_type=?,
duration=?,
total_questions=?,
passing_score=?,
status=?

WHERE exam_id=?

";

$stmt = mysqli_prepare($conn,$sql);

mysqli_stmt_bind_param(

$stmt,

"sssisiiisi",

$title,
$description,
$instructions,
$category_id,
$exam_type,
$duration,
$total_questions,
$passing_score,
$status,
$exam_id

);

if(!mysqli_stmt_execute($stmt)){

    die("Update Error : ".mysqli_error($conn));

}

mysqli_stmt_close($stmt);


// =====================================
// REMOVE OLD QUESTIONS
// =====================================

$stmt = mysqli_prepare($conn,"
DELETE FROM exam_items
WHERE exam_id=?
");

mysqli_stmt_bind_param($stmt,"i",$exam_id);
mysqli_stmt_execute($stmt);
mysqli_stmt_close($stmt);


// =====================================
// INSERT NEW QUESTIONS
// =====================================

if(!empty($questions)){

    $stmt = mysqli_prepare($conn,"
    INSERT INTO exam_items
    (exam_id,question_id)
    VALUES (?,?)
    ");

    foreach($questions as $question_id){

        $question_id = (int)$question_id;

        mysqli_stmt_bind_param(
            $stmt,
            "ii",
            $exam_id,
            $question_id
        );

        mysqli_stmt_execute($stmt);

    }

    mysqli_stmt_close($stmt);

}


// =====================================
// SUCCESS
// =====================================

echo "

<script>

alert('Examination updated successfully!');

window.location='test_administration.php';

</script>

";

?>