<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

if ($_SESSION['usertype'] != "admin") {
    header("Location: ../user.php");
    exit();
}

require_once "../connection.php";

if (!isset($_GET['id'])) {
    header("Location: test_bank.php");
    exit();
}

$question_id = (int)$_GET['id'];

$sql = "
SELECT
    q.*,
    c.category_name,
    CONCAT(l.firstname,' ',l.surname) AS created_by_name

FROM questions q

INNER JOIN categories c
ON q.category_id=c.category_id

INNER JOIN logintbl l
ON q.created_by=l.id

WHERE q.question_id=?
";

$stmt = mysqli_prepare($conn,$sql);

mysqli_stmt_bind_param($stmt,"i",$question_id);

mysqli_stmt_execute($stmt);

$result=mysqli_stmt_get_result($stmt);

if(mysqli_num_rows($result)==0){
    die("Question not found.");
}

$row=mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>View Question | e-Nurse</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Poppins',sans-serif;
    background:#edf2fb;
}

/* Main */

.main{
    margin-left:230px;
    width:calc(100% - 230px);
    min-height:100vh;
    padding:30px;
}

/* Page */

.page-title{
    font-size:30px;
    font-weight:600;
    color:#111827;
}

.page-subtitle{
    color:#6b7280;
    margin-top:5px;
    margin-bottom:25px;
}

/* Card */

.card{
    background:#fff;
    border-radius:18px;
    padding:30px;
    box-shadow:0 5px 18px rgba(0,0,0,.08);
}

/* Header */

.card-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    flex-wrap:wrap;
    gap:15px;
    margin-bottom:25px;
}

.card-header h2{
    font-size:24px;
    color:#111827;
}

/* Buttons */

.btn{
    display:inline-flex;
    align-items:center;
    gap:8px;
    padding:11px 18px;
    border:none;
    border-radius:10px;
    text-decoration:none;
    font-size:14px;
    font-weight:600;
    cursor:pointer;
    transition:.25s;
}

.btn:hover{
    transform:translateY(-2px);
}

.btn-blue{
    background:#2563eb;
    color:#fff;
}

.btn-blue:hover{
    background:#1d4ed8;
}

.btn-outline{
    background:#fff;
    border:1px solid #d1d5db;
    color:#374151;
}

.btn-outline:hover{
    background:#f9fafb;
}

/* Information Grid */

.info-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(240px,1fr));
    gap:18px;
    margin-bottom:30px;
}

.info-box{
    background:#f9fafb;
    border-radius:12px;
    padding:18px;
}

.info-box label{
    display:block;
    color:#6b7280;
    font-size:13px;
    margin-bottom:6px;
}

.info-box strong{
    color:#111827;
    font-size:15px;
}

/* Question */

.section-title{
    font-size:18px;
    font-weight:600;
    color:#111827;
    margin-bottom:15px;
}

.question-box{
    background:#f9fafb;
    border-left:5px solid #2563eb;
    border-radius:12px;
    padding:18px;
    margin-bottom:30px;
    line-height:1.8;
}

/* Choices */

.choice{
    display:flex;
    align-items:flex-start;
    gap:15px;
    padding:15px;
    border:1px solid #e5e7eb;
    border-radius:12px;
    margin-bottom:12px;
}

.choice.correct{
    background:#dcfce7;
    border-color:#22c55e;
}

.choice-letter{
    width:38px;
    height:38px;
    border-radius:50%;
    background:#2563eb;
    color:#fff;
    display:flex;
    justify-content:center;
    align-items:center;
    font-weight:bold;
    flex-shrink:0;
}

.choice.correct .choice-letter{
    background:#16a34a;
}

.choice-text{
    flex:1;
    line-height:1.7;
}

.correct-badge{
    background:#16a34a;
    color:#fff;
    padding:6px 12px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
}

/* Rationale */

.rationale{
    margin-top:30px;
    background:#eff6ff;
    border-left:5px solid #2563eb;
    padding:20px;
    border-radius:12px;
}

/* Badges */

.badge{
    display:inline-block;
    padding:6px 12px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
}

.easy{
    background:#dcfce7;
    color:#166534;
}

.medium{
    background:#fef3c7;
    color:#92400e;
}

.hard{
    background:#fee2e2;
    color:#991b1b;
}

.active{
    background:#dbeafe;
    color:#1d4ed8;
}

.inactive{
    background:#e5e7eb;
    color:#374151;
}

/* Responsive */

@media(max-width:768px){

.main{
    margin-left:0;
    width:100%;
    padding:85px 15px 20px;
}

.card{
    padding:20px;
}

.card-header{
    flex-direction:column;
    align-items:flex-start;
}

.card-header div{
    display:flex;
    flex-direction:column;
    width:100%;
    gap:10px;
}

.btn{
    width:100%;
    justify-content:center;
}

}

</style>

</head>

<body>

<?php include 'admin_sidebar.php'; ?>

<main class="main">

<div class="page-title">
View Question
</div>

<p class="page-subtitle">
Review question details and correct answer.
</p>

<div class="card">

<div class="card-header">

<h2>Question Information</h2>

<div>

<a href="test_bank.php" class="btn btn-outline">
<i class="fa-solid fa-arrow-left"></i>
Back
</a>

<a href="edit_question.php?id=<?php echo $row['question_id']; ?>" class="btn btn-blue">
<i class="fa-solid fa-pen"></i>
Edit Question
</a>

</div>

</div>
    
    <!-- Information -->

<div class="info-grid">

    <div class="info-box">
        <label>Category</label>
        <strong><?php echo htmlspecialchars($row['category_name']); ?></strong>
    </div>

    <div class="info-box">
        <label>Difficulty</label>

        <?php
        $difficultyClass = strtolower($row['difficulty']);
        ?>

        <span class="badge <?php echo $difficultyClass; ?>">
            <?php echo htmlspecialchars($row['difficulty']); ?>
        </span>
    </div>

    <div class="info-box">
        <label>Status</label>

        <?php
        $statusClass = strtolower($row['status']);
        ?>

        <span class="badge <?php echo $statusClass; ?>">
            <?php echo htmlspecialchars($row['status']); ?>
        </span>
    </div>

    <div class="info-box">
        <label>Created By</label>
        <strong><?php echo htmlspecialchars($row['created_by_name']); ?></strong>
    </div>

    <div class="info-box">
        <label>Date Created</label>
        <strong>
            <?php echo date("F d, Y h:i A", strtotime($row['created_at'])); ?>
        </strong>
    </div>

</div>


<!-- Question -->

<div class="section-title">
Question
</div>

<div class="question-box">
    <?php echo nl2br(htmlspecialchars($row['question'])); ?>
</div>


<!-- Choices -->

<div class="section-title">
Answer Choices
</div>


<?php

$choices = [
    "A" => $row['option_a'],
    "B" => $row['option_b'],
    "C" => $row['option_c'],
    "D" => $row['option_d']
];

foreach($choices as $letter=>$choice){

$correct = ($row['correct_answer']==$letter);

?>

<div class="choice <?php echo $correct ? 'correct' : ''; ?>">

    <div class="choice-letter">
        <?php echo $letter; ?>
    </div>

    <div class="choice-text">

        <?php echo htmlspecialchars($choice); ?>

    </div>

    <?php if($correct){ ?>

        <span class="correct-badge">

            Correct Answer

        </span>

    <?php } ?>

</div>

<?php } ?>


<!-- Rationale -->

<div class="section-title">
Explanation / Rationale
</div>

<div class="rationale">

<?php

if(!empty($row['rationale'])){

    echo nl2br(htmlspecialchars($row['rationale']));

}else{

    echo "<em>No rationale provided.</em>";

}

?>

</div>

</div>

</main>

</body>
</html>