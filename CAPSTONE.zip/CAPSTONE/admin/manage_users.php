<?php

error_reporting(0);
ini_set('display_errors', 0);

session_start();

include "../connection.php";

if (!isset($_SESSION['ID'])) {
    header("Location: ../login.php");
    exit();
}

if ($_SESSION['usertype'] != "admin") {
    header("Location: ../user.php");
    exit();
}

$search = "";

if (isset($_GET['search'])) {
    $search = trim($_GET['search']);
}

if ($search != "") {

    $sql = "SELECT * FROM logintbl
            WHERE firstname LIKE ?
            OR middlename LIKE ?
            OR surname LIKE ?
            OR username LIKE ?
            OR email LIKE ?
            ORDER BY id ASC";

    $stmt = mysqli_prepare($conn, $sql);

    $keyword = "%".$search."%";

    mysqli_stmt_bind_param(
        $stmt,
        "sssss",
        $keyword,
        $keyword,
        $keyword,
        $keyword,
        $keyword
    );

    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);

} else {

    $sql = "SELECT * FROM logintbl ORDER BY id ASC";

    $result = mysqli_query($conn,$sql);

}

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Manage Users - e-Nurse</title>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<style>

body{
    margin:0;
    font-family:'Poppins',sans-serif;
    background:#f3f5fb;
}

/* MAIN */

.main{

    margin-left:230px;
    width:calc(100% - 230px);

    min-height:100vh;

    padding:30px;

    box-sizing:border-box;

    overflow-x:auto;

}



.topbar{

    display:flex;
    justify-content:space-between;
    align-items:center;
    flex-wrap:wrap;
    gap:15px;

    margin-bottom:25px;

}


.topbar h1{
    margin:0;
    font-size:30px;
    font-weight:600;
    color:#111827;
}



.welcome{

    background:white;

    padding:14px 22px;

    border-radius:16px;

    box-shadow:0 3px 12px rgba(0,0,0,.08);

}



/* CONTENT */

.card{
    background:#fff;
    padding:28px;
    border-radius:18px;
    box-shadow:0 4px 18px rgba(0,0,0,.08);
}



/* SEARCH */

.search-box{

    display:flex;
    align-items:center;
    gap:12px;
    margin-bottom:25px;
    flex-wrap:wrap;

}

.search-left{

    position:relative;
    flex:1;
    min-width:300px;
    max-width:550px;

}

.search-icon{

    position:absolute;
    left:15px;
    top:50%;
    transform:translateY(-50%);
    color:#9ca3af;
    font-size:15px;

}

.search-left input{

    width:100%;
    padding:12px 15px 12px 42px;
    border:1px solid #d1d5db;
    border-radius:12px;
    font-size:14px;
    font-family:'Poppins',sans-serif;
    background:#fff;
    transition:.25s;
    box-shadow:0 2px 8px rgba(0,0,0,.05);

}

.search-left input:focus{

    outline:none;
    border-color:#2563eb;
    box-shadow:0 0 0 4px rgba(37,99,235,.15);

}

.search-btn{

    background:#2563eb;
    color:#fff;
    padding:12px 22px;
    border:none;
    border-radius:12px;
    font-size:14px;
    font-weight:600;
    cursor:pointer;
    white-space:nowrap;

}

.search-btn:hover{

    background:#1d4ed8;

}

.clear-btn{

    background:#f3f4f6;
    color:#374151;
    padding:12px 20px;
    border:none;
    border-radius:12px;
    font-size:14px;
    font-weight:600;
    cursor:pointer;
    white-space:nowrap;

}

.clear-btn:hover{

    background:#e5e7eb;

}
    
button{
    background:#2563eb;
    color:#fff;
    border:none;
    padding:11px 18px;
    border-radius:10px;
    cursor:pointer;
    font-family:'Poppins',sans-serif;
    font-size:14px;
    font-weight:500;
}


button:hover{

    background:#1d4ed8;

}



table{

    width:100%;

    border-collapse:collapse;

}



th{
    background:#2563eb;
    color:#fff;
    padding:14px;
    font-size:14px;
}



td{
    padding:12px;
    border-bottom:1px solid #e5e7eb;
    font-size:14px;
}



td input{
    width:100%;
    padding:8px 10px;
    border:1px solid #d1d5db;
    border-radius:8px;
    font-size:14px;
    font-family:'Poppins',sans-serif;
}



.delete{

    background:#dc2626;

}


.delete:hover{

    background:#b91c1c;

}


.success{

    color:green;

    font-weight:bold;

}


.error{

    color:red;

    font-weight:bold;

}


.info{

    color:#2563eb;

    font-weight:bold;

}
    
   .button-group{

    display:flex;
    gap:10px;
    flex-wrap:wrap;

}


.add-user{

    background:#16a34a;

}


.add-user:hover{

    background:#15803d;

}
    
    @media (max-width:768px){

    .main{

        margin-left:0;
        width:100%;

        padding:80px 15px 20px;

    }

    .topbar{

        flex-direction:column;
        align-items:flex-start;

    }

    .topbar h1{

        font-size:25px;

    }

    .card{

        padding:18px;

    }

   .search-box{

    flex-direction:column;
    align-items:stretch;

}

.search-left{

    width:100%;
    max-width:100%;
    min-width:100%;

}

.search-btn,
.clear-btn{

    width:100%;

}
    .button-group{

        flex-direction:column;

    }

    .button-group button{

        width:100%;

    }

    table{

        min-width:900px;

    }

}

</style>

</head>


<body>
    
    <?php include 'admin_sidebar.php'; ?>

<main class="main">


<div class="topbar">

<h1>Manage User Accounts</h1>

</div>



<div class="card">

<?php

if(isset($_GET['success'])){
echo "<p class='success'>Changes saved successfully.</p>";
}

if(isset($_GET['nochanges'])){
echo "<p class='info'>No changes were made.</p>";
}

if(isset($_GET['deleted'])){
echo "<p class='success'>User account deleted successfully.</p>";
}

if(isset($_GET['error'])){
echo "<p class='error'>Unable to process request.</p>";
}

?>



<form method="GET" class="search-box">

    <div class="search-left">

        <i class="fa-solid fa-magnifying-glass search-icon"></i>

        <input
            type="text"
            name="search"
            placeholder="Search by name, username or email..."
            value="<?php echo htmlspecialchars($search); ?>">

    </div>

    <button type="submit" class="search-btn">
        <i class="fa-solid fa-search"></i> Search
    </button>

    <?php if($search!=""){ ?>

    <a href="manage_users.php">
        <button type="button" class="clear-btn">
            <i class="fa-solid fa-xmark"></i> Clear
        </button>
    </a>

    <?php } ?>

</form>

<form action="update_user.php" method="POST">


<div class="button-group" style="margin-bottom:25px;">

<button type="submit">

<i class="fa-solid fa-save"></i>
Save Changes

</button>


<a href="create_user.php">

<button type="button" class="add-user">

<i class="fa-solid fa-user-plus"></i>
Add User

</button>

</a>

</div>


<br><br>


<div style="overflow-x:auto;">
<table>


<tr>

<th>First Name</th>
<th>Middle Name</th>
<th>Surname</th>
<th>Username</th>
<th>Email</th>
<th>User Type</th>
<th>Action</th>

</tr>



<?php while($row=mysqli_fetch_assoc($result)){ ?>


<tr>


<td>

<input
type="text"
name="firstname[<?php echo $row['id']; ?>]"
value="<?php echo htmlspecialchars($row['firstname']); ?>">

</td>


<td>

<input
type="text"
name="middlename[<?php echo $row['id']; ?>]"
value="<?php echo htmlspecialchars($row['middlename']); ?>">

</td>


<td>

<input
type="text"
name="surname[<?php echo $row['id']; ?>]"
value="<?php echo htmlspecialchars($row['surname']); ?>">

</td>


<td>

<?php echo htmlspecialchars($row['username']); ?>

</td>


<td>

<input
type="email"
name="email[<?php echo $row['id']; ?>]"
value="<?php echo htmlspecialchars($row['email']); ?>">

</td>


<td>

<?php echo htmlspecialchars($row['usertype']); ?>

</td>


<td>


<?php if($row['id'] != $_SESSION['ID']){ ?>


<a href="delete_user.php?id=<?php echo $row['id']; ?>"
onclick="return confirm('Delete this account?');">


<button type="button" class="delete">

<i class="fa-solid fa-trash"></i>

</button>


</a>


<?php }else{ ?>


<button type="button" disabled>

<i class="fa-solid fa-lock"></i>

</button>


<?php } ?>


</td>


</tr>


<?php } ?>


</table>
    
    </div>


</form>


</div>


</main>

</body>

</html>