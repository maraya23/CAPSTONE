<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

if ($_SESSION['usertype'] != "admin") {
    header("Location: ../user.php");
    exit();
}

require_once "../connection.php";

/* ===========================
   CHECK QUESTION ID
=========================== */

if (!isset($_GET['id'])) {

    header("Location: test_bank.php");
    exit();

}

$question_id = (int)$_GET['id'];


/* ===========================
   CHECK IF QUESTION EXISTS
=========================== */

$check = mysqli_prepare(
    $conn,
    "SELECT question_id
     FROM questions
     WHERE question_id = ?"
);

mysqli_stmt_bind_param(
    $check,
    "i",
    $question_id
);

mysqli_stmt_execute($check);

$result = mysqli_stmt_get_result($check);

if (mysqli_num_rows($result) == 0) {

    echo "<script>
            alert('Question not found.');
            window.location='test_bank.php';
          </script>";

    exit();

}

mysqli_stmt_close($check);


/* ===========================
   DELETE QUESTION
=========================== */

$delete = mysqli_prepare(
    $conn,
    "DELETE FROM questions
     WHERE question_id = ?"
);

mysqli_stmt_bind_param(
    $delete,
    "i",
    $question_id
);

if (mysqli_stmt_execute($delete)) {

    echo "<script>
            alert('Question deleted successfully.');
            window.location='test_bank.php';
          </script>";

} else {

    echo "<script>
            alert('Unable to delete the question.');
            window.location='test_bank.php';
          </script>";

}

mysqli_stmt_close($delete);
mysqli_close($conn);
?>