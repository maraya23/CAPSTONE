<?php
session_start();
include '../connection.php';

if (!isset($_SESSION['admin_id'])) {
    header('Location: /CAPSTONE/login.php');
    exit();
}

if ($_SESSION['usertype'] != 'admin') {
    header('Location: ../user.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $duration = (int)$_POST['duration'];
    $passing_score = (int)$_POST['passing_score'];

    // Count all questions
    $q = mysqli_query($conn, 'SELECT COUNT(*) AS total FROM questions');
    $r = mysqli_fetch_assoc($q);
    $total_questions = $r['total'];

    $sql = 'INSERT INTO exams (title, description, duration, passing_score, total_questions)
            VALUES (?, ?, ?, ?, ?)';

    $stmt = mysqli_prepare($conn, $sql);

    mysqli_stmt_bind_param(
        $stmt,
        'ssiii',
        $title,
        $description,
        $duration,
        $passing_score,
        $total_questions
    );

    if (mysqli_stmt_execute($stmt)) {
        header('Location: test_construction.php?success=1');
        exit();
    } else {
        die('Database Error: ' . mysqli_error($conn));
    }
}

header('Location: test_construction.php');
exit();
?>