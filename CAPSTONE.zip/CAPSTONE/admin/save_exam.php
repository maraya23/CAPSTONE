<?php

session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: /CAPSTONE/login.php");
    exit();
}

if ($_SESSION['usertype'] != "admin") {
    header("Location: ../user.php");
    exit();
}

include "../connection.php";

if ($_SERVER['REQUEST_METHOD'] != "POST") {
    header("Location: test_construction.php");
    exit();
}

// ======================================
// GET FORM DATA
// ======================================

$title = trim($_POST['title']);
$description = trim($_POST['description']);
$instructions = trim($_POST['instructions']);
$category_id = (int)$_POST['category_id'];
$exam_type = trim($_POST['exam_type']);
$duration = (int)$_POST['duration'];
$passing_score = (int)$_POST['passing_score'];
$status = trim($_POST['status']);
$created_by = $_SESSION['admin_id'];

$questions = isset($_POST['questions'])
    ? $_POST['questions']
    : [];

// ======================================
// VALIDATION
// ======================================

if (
    $title == "" ||
    $category_id == 0 ||
    $exam_type == "" ||
    $duration <= 0 ||
    count($questions) == 0
) {
    echo "<script>
        alert('Please complete all required fields and select at least one question.');
        window.history.back();
    </script>";
    exit();
}

$total_questions = count($questions);

// ======================================
// START TRANSACTION
// ======================================

mysqli_begin_transaction($conn);

try {

    // ==================================
    // SAVE EXAM
    // ==================================

    $sql = "

    INSERT INTO exams (

        title,
        description,
        instructions,
        category_id,
        exam_type,
        duration,
        total_questions,
        passing_score,
        status,
        created_by

    )

    VALUES (

        ?,?,?,?,?,?,?,?,?,?

    )

    ";

    $stmt = mysqli_prepare($conn, $sql);

    mysqli_stmt_bind_param(

        $stmt,

        "sssisiiisi",

        $title,
        $description,
        $instructions,
        $category_id,
        $exam_type,
        $duration,
        $total_questions,
        $passing_score,
        $status,
        $created_by

    );

    mysqli_stmt_execute($stmt);

    $exam_id = mysqli_insert_id($conn);

    mysqli_stmt_close($stmt);

    // ==================================
    // SAVE EXAM QUESTIONS
    // ==================================

    $sqlItem = "

    INSERT INTO exam_items (

        exam_id,
        question_id

    )

    VALUES (?,?)

    ";

    $stmtItem = mysqli_prepare($conn, $sqlItem);

    foreach ($questions as $qid) {

        $qid = (int)$qid;

        mysqli_stmt_bind_param(
            $stmtItem,
            "ii",
            $exam_id,
            $qid
        );

        mysqli_stmt_execute($stmtItem);
    }

    mysqli_stmt_close($stmtItem);

    // ==================================
    // COMMIT
    // ==================================

    mysqli_commit($conn);

    echo "<script>

        alert('Examination created successfully.');

        window.location='test_administration.php';

    </script>";

} catch (Exception $e) {

    mysqli_rollback($conn);

    echo "<script>

        alert('Failed to save examination.');

        window.location='test_construction.php';

    </script>";

}
?>