<?php

session_start();


if(!isset($_SESSION['admin_id'])){

    header("Location: ../login.php");
    exit();

}


if($_SESSION['usertype'] != "admin"){

    header("Location: ../user.php");
    exit();

}


include "../connection.php";



// ======================================
// CHECK POST
// ======================================


if($_SERVER["REQUEST_METHOD"] != "POST"){

    header("Location: test_construction.php");
    exit();

}




// ======================================
// GET DATA
// ======================================


$title = trim($_POST['title']);

$category_id = intval($_POST['category_id']);

$duration = intval($_POST['duration']);

$passing_score = intval($_POST['passing_score']);

$status = $_POST['status'];



/*
    Since your current test_construction.php
    does not yet have exam type,
    default is Practice Quiz.

    Later it can be changed from the page.
*/


$exam_type = isset($_POST['exam_type'])
? $_POST['exam_type']
: "Practice Quiz";




$questions = isset($_POST['questions'])
? $_POST['questions']
: [];



$total_questions = count($questions);



$created_by = $_SESSION['admin_id'];





// ======================================
// VALIDATION
// ======================================


if(
empty($title) ||
empty($category_id) ||
empty($duration) ||
$total_questions == 0
){


echo "

<script>

alert('Please complete the exam information and select questions.');

window.history.back();

</script>

";


exit();

}




// ======================================
// START TRANSACTION
// ======================================


mysqli_begin_transaction($conn);



try{



// ======================================
// INSERT EXAM
// ======================================


$sql = "

INSERT INTO exams

(
title,
category_id,
duration,
total_questions,
passing_score,
status,
exam_type,
created_by
)

VALUES

(?,?,?,?,?,?,?,?)

";



$stmt = mysqli_prepare($conn,$sql);



if(!$stmt){

    throw new Exception(mysqli_error($conn));

}



mysqli_stmt_bind_param(

$stmt,

"siiisssi",

$title,

$category_id,

$duration,

$total_questions,

$passing_score,

$status,

$exam_type,

$created_by

);



if(!mysqli_stmt_execute($stmt)){


    throw new Exception(mysqli_stmt_error($stmt));


}





// GET EXAM ID


$exam_id = mysqli_insert_id($conn);






// ======================================
// INSERT QUESTIONS
// ======================================


$item_sql = "

INSERT INTO exam_items

(
exam_id,
question_id
)

VALUES

(?,?)

";



$item_stmt = mysqli_prepare($conn,$item_sql);



if(!$item_stmt){

    throw new Exception(mysqli_error($conn));

}





foreach($questions as $question_id){



    $question_id = intval($question_id);



    mysqli_stmt_bind_param(

        $item_stmt,

        "ii",

        $exam_id,

        $question_id

    );



    if(!mysqli_stmt_execute($item_stmt)){


        throw new Exception(mysqli_stmt_error($item_stmt));


    }



}





// ======================================
// COMMIT
// ======================================


mysqli_commit($conn);



echo "

<script>

alert('Exam created successfully!');

window.location='test_administration.php';

</script>

";




}

catch(Exception $e){



mysqli_rollback($conn);



echo "

<script>

alert('Failed to create exam.');

window.history.back();

</script>

";



}



?>