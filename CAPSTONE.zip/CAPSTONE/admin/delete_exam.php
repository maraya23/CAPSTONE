<?php

session_start();


if(!isset($_SESSION['admin_id'])){

    header("Location: ../login.php");
    exit();

}



if($_SESSION['usertype'] != "admin"){

    header("Location: ../user.php");
    exit();

}



include "../connection.php";




// ==============================
// CHECK EXAM ID
// ==============================


if(!isset($_GET['id'])){

    header("Location:test_administration.php");
    exit();

}



$exam_id = intval($_GET['id']);






// ==============================
// DELETE EXAM QUESTIONS FIRST
// ==============================


$delete_items = mysqli_query(

$conn,

"

DELETE FROM exam_items

WHERE exam_id='$exam_id'

"

);





if(!$delete_items){

    die("Error deleting exam questions: ".mysqli_error($conn));

}






// ==============================
// DELETE EXAM
// ==============================


$delete_exam = mysqli_query(

$conn,

"

DELETE FROM exams

WHERE exam_id='$exam_id'

"

);






if(!$delete_exam){

    die("Error deleting exam: ".mysqli_error($conn));

}






// ==============================
// SUCCESS
// ==============================


echo "

<script>

alert('Exam deleted successfully!');

window.location='test_administration.php';

</script>

";


?>