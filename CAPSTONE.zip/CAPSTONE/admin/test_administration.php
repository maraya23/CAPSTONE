<?php

session_start();

require_once '../connection.php';


if(!isset($_SESSION['admin_id'])){

    header("Location: ../login.php");
    exit();

}

?>


<!DOCTYPE html>

<html lang="en">

<head>


<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">


<title>
Test Administration
</title>



<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">


<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">



<style>


body{

    margin:0;

    background:#f3f5fb;

    font-family:'Poppins',sans-serif;

}




.content{

    margin-left:230px;

    width:calc(100% - 230px);

    min-height:100vh;

    padding:30px;

}





/* HEADER */


.page-header{

    display:flex;

    justify-content:space-between;

    align-items:center;

    margin-bottom:25px;

}



.page-header h3{

    margin:0;

    font-size:30px;

    font-weight:600;

    color:#111827;

}



.page-header p{

    margin:5px 0 0;

    color:#6b7280;

}





/* CARD */


.card-box{

    border:none;

    border-radius:18px;

    box-shadow:0 4px 18px rgba(0,0,0,.08);

}





/* COMPACT STAT CARDS */

.stat-card{

    padding:15px;

    display:flex;

    flex-direction:column;

    align-items:center;

    justify-content:center;

    text-align:center;

    min-height:110px;

    gap:8px;

}



.stat-icon{

    width:45px;

    height:45px;

    border-radius:12px;

    display:flex;

    align-items:center;

    justify-content:center;

    font-size:20px;

}



.stat-card h2{

    margin:0;

    font-size:24px;

    font-weight:700;

    line-height:1;

}



.stat-card p{

    margin:0;

    color:#6b7280;

    font-size:13px;

}



.blue{

    background:#e8f0ff;

    color:#2563eb;

}



.green{

    background:#e8f7ea;

    color:#16a34a;

}



.orange{

    background:#fff7e6;

    color:#f59e0b;

}



.purple{

    background:#f3e8ff;

    color:#9333ea;

}





.stat-card h2{

    margin:0;

    font-size:30px;

    font-weight:700;

}




.stat-card p{

    margin:3px 0;

    color:#6b7280;

    font-size:14px;

}





/* FILTER */


.filter-bar{

    display:flex;

    gap:15px;

    margin:25px 0;

}



.filter-bar input,
.filter-bar select{

    height:48px;

    border-radius:12px;

}






/* TABLE */


.table thead th{

    background:#2563eb;

    color:white;

    border:none;

}


.table td{

    vertical-align:middle;

}




.badge{

    padding:7px 12px;

    border-radius:20px;

}





@media(max-width:992px){


.content{

    margin-left:0;

    width:100%;

    padding:80px 20px;

}



.filter-bar{

    flex-direction:column;

}



}



</style>



</head>



<body>


<?php include 'admin_sidebar.php'; ?>


<div class="content">
    
    <!-- PAGE HEADER -->


<div class="page-header">


    <div>


        <h3>
            Test Administration
        </h3>


        <p>
            Create, manage, and monitor tests and examinations.
        </p>


    </div>



    <button class="btn btn-primary px-4 py-2">


        <i class="bi bi-plus-circle"></i>

        Create Test


    </button>



</div>







<!-- SUMMARY CARDS -->


<div class="row g-4">



    <!-- ACTIVE TESTS -->


    <div class="col-xl-3 col-md-6">


        <div class="card card-box stat-card">


            <div class="stat-icon blue">


                <i class="bi bi-file-earmark-text"></i>


            </div>



            <div>


                <h2>
                    12
                </h2>


                <p>
                    Active Tests
                </p>


            </div>



        </div>


    </div>








    <!-- SCHEDULED TESTS -->


    <div class="col-xl-3 col-md-6">


        <div class="card card-box stat-card">


            <div class="stat-icon orange">


                <i class="bi bi-calendar-event"></i>


            </div>



            <div>


                <h2>
                    5
                </h2>


                <p>
                    Scheduled Tests
                </p>


            </div>



        </div>


    </div>









    <!-- COMPLETED TESTS -->


    <div class="col-xl-3 col-md-6">


        <div class="card card-box stat-card">


            <div class="stat-icon green">


                <i class="bi bi-check-circle"></i>


            </div>



            <div>


                <h2>
                    20
                </h2>


                <p>
                    Completed Tests
                </p>


            </div>



        </div>


    </div>









    <!-- TOTAL ATTEMPTS -->


    <div class="col-xl-3 col-md-6">


        <div class="card card-box stat-card">


            <div class="stat-icon purple">


                <i class="bi bi-people"></i>


            </div>



            <div>


                <h2>
                    1,245
                </h2>


                <p>
                    Total Attempts
                </p>


            </div>



        </div>


    </div>



</div>










<!-- TEST PERFORMANCE TITLE -->


<div class="mt-4 mb-2">


    <h5 style="font-weight:600;color:#111827;">

        Test Performance

    </h5>



</div>








<!-- PERFORMANCE CARDS -->


<div class="row g-4">






<!-- AVERAGE SCORE -->


<div class="col-xl-3 col-md-6">


<div class="card card-box stat-card">


<div class="stat-icon blue">


<i class="bi bi-bar-chart"></i>


</div>



<div>


<h2>
86%
</h2>


<p>
Average Score
</p>


</div>


</div>


</div>








<!-- PASS RATE -->


<div class="col-xl-3 col-md-6">


<div class="card card-box stat-card">


<div class="stat-icon green">


<i class="bi bi-check2-circle"></i>


</div>



<div>


<h2>
88%
</h2>


<p>
Pass Rate
</p>


</div>


</div>


</div>








<!-- COMPLETION RATE -->


<div class="col-xl-3 col-md-6">


<div class="card card-box stat-card">


<div class="stat-icon purple">


<i class="bi bi-graph-up"></i>


</div>



<div>


<h2>
94%
</h2>


<p>
Completion Rate
</p>


</div>


</div>


</div>








<!-- HIGHEST SCORE -->


<div class="col-xl-3 col-md-6">


<div class="card card-box stat-card">


<div class="stat-icon orange">


<i class="bi bi-award"></i>


</div>



<div>


<h2>
98%
</h2>


<p>
Highest Score
</p>


</div>


</div>


</div>





</div>
    
    <!-- SEARCH AND FILTER -->


<div class="filter-bar">


    <input 
        type="text"
        class="form-control"
        placeholder="Search test..."
    >




    <select class="form-select">


        <option>
            All Categories
        </option>


        <option>
            Fundamentals of Nursing
        </option>


        <option>
            Medical-Surgical Nursing
        </option>


        <option>
            Maternal and Child Nursing
        </option>


        <option>
            Psychiatric Nursing
        </option>


        <option>
            Community Health Nursing
        </option>



    </select>






    <select class="form-select">


        <option>
            All Status
        </option>


        <option>
            Active
        </option>


        <option>
            Scheduled
        </option>


        <option>
            Completed
        </option>


    </select>






    <button class="btn btn-outline-primary px-4">


        <i class="bi bi-funnel"></i>


        Filter


    </button>



</div>










<!-- TEST TABLE -->


<div class="card card-box">


<div class="card-body">



<div class="table-responsive">



<table class="table table-hover align-middle">



<thead>


<tr>


<th>
Test Name
</th>


<th>
Category
</th>


<th>
Questions
</th>


<th>
Duration
</th>


<th>
Status
</th>


<th>
Attempts
</th>


<th>
Pass Rate
</th>


<th width="150">
Actions
</th>



</tr>



</thead>






<tbody>





<tr>



<td>


<strong>

Fundamentals Mock Exam

</strong>


<br>


<small class="text-muted">

Mock Board Examination

</small>


</td>





<td>

Fundamentals

</td>





<td>

100

</td>





<td>

120 mins

</td>





<td>


<span class="badge bg-success">

Active

</span>


</td>





<td>

245

</td>





<td>

88%

</td>






<td>


<button class="btn btn-sm btn-outline-primary">


<i class="bi bi-eye"></i>


</button>





<button class="btn btn-sm btn-outline-warning">


<i class="bi bi-pencil"></i>


</button>





<button class="btn btn-sm btn-outline-danger">


<i class="bi bi-trash"></i>


</button>



</td>




</tr>









<tr>



<td>


<strong>

Medical-Surgical Quiz

</strong>


<br>


<small class="text-muted">

Practice Quiz

</small>


</td>





<td>

Medical-Surgical

</td>





<td>

50

</td>





<td>

60 mins

</td>





<td>


<span class="badge bg-warning text-dark">

Scheduled

</span>


</td>





<td>

0

</td>





<td>

--

</td>






<td>


<button class="btn btn-sm btn-outline-primary">


<i class="bi bi-eye"></i>


</button>





<button class="btn btn-sm btn-outline-warning">


<i class="bi bi-pencil"></i>


</button>





<button class="btn btn-sm btn-outline-danger">


<i class="bi bi-trash"></i>


</button>



</td>




</tr>







</tbody>



</table>



</div>



</div>



</div>
    
    </div> <!-- END CONTENT -->



</body>


</html>