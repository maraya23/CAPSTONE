<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: /CAPSTONE/login.php");
    exit();
}

if ($_SESSION['usertype'] != "admin") {
    header("Location: ../user.php");
    exit();
}

include "../connection.php";


// ======================================
// SEARCH & FILTERS
// ======================================

$search = isset($_GET['search'])
    ? trim($_GET['search'])
    : "";

$category = isset($_GET['category'])
    ? trim($_GET['category'])
    : "";

$type = isset($_GET['type'])
    ? trim($_GET['type'])
    : "";

$status = isset($_GET['status'])
    ? trim($_GET['status'])
    : "";


// ======================================
// DASHBOARD COUNTS
// ======================================

// Published Exams
$published = mysqli_fetch_assoc(
    mysqli_query($conn,"
        SELECT COUNT(*) total
        FROM exams
        WHERE status='Published'
    ")
);

// Draft Exams
$draft = mysqli_fetch_assoc(
    mysqli_query($conn,"
        SELECT COUNT(*) total
        FROM exams
        WHERE status='Draft'
    ")
);

// Closed Exams
$closed = mysqli_fetch_assoc(
    mysqli_query($conn,"
        SELECT COUNT(*) total
        FROM exams
        WHERE status='Closed'
    ")
);

// Total Attempts
$attempts = mysqli_fetch_assoc(
    mysqli_query($conn,"
        SELECT COUNT(*) total
        FROM exam_attempts
    ")
);


// ======================================
// LOAD CATEGORIES
// ======================================

$categories = mysqli_query($conn,"
SELECT
category_id,
category_name
FROM categories
WHERE status='Active'
ORDER BY category_name ASC
");


// ======================================
// LOAD EXAMS
// ======================================

$sql = "

SELECT

e.exam_id,

e.title,

e.exam_type,

e.duration,

e.total_questions,

e.status,

e.created_at,

c.category_name,

(
SELECT COUNT(*)
FROM exam_attempts a
WHERE a.exam_id=e.exam_id
) attempts

FROM exams e

INNER JOIN categories c

ON e.category_id=c.category_id

WHERE 1=1

";

$params = [];
$types = "";

if($search!=""){

    $sql .= " AND e.title LIKE ? ";

    $params[]="%".$search."%";

    $types.="s";

}

if($category!=""){

    $sql .= " AND e.category_id=? ";

    $params[]=$category;

    $types.="i";

}

if($type!=""){

    $sql .= " AND e.exam_type=? ";

    $params[]=$type;

    $types.="s";

}

if($status!=""){

    $sql .= " AND e.status=? ";

    $params[]=$status;

    $types.="s";

}

$sql .= "

ORDER BY

e.created_at DESC

";

$stmt = mysqli_prepare($conn,$sql);

if(!$stmt){

    die(mysqli_error($conn));

}

if(!empty($params)){

    mysqli_stmt_bind_param(

        $stmt,

        $types,

        ...$params

    );

}

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>
Test Administration - e-Nurse
</title>


<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">


<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">


<style>


*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}


body{

    background:#edf2fb;

    font-family:'Poppins',sans-serif;

}


/* =========================
MAIN
========================= */


.main{

    margin-left:230px;

    width:calc(100% - 230px);

    min-height:100vh;

    padding:30px;

}



/* =========================
PAGE HEADER
========================= */


.page-header{

    display:flex;

    justify-content:space-between;

    align-items:center;

    margin-bottom:25px;

    flex-wrap:wrap;

    gap:15px;

}


.page-header h1{

    font-size:32px;

    color:#111827;

}


.page-header p{

    margin-top:5px;

    color:#6b7280;

    font-size:15px;

}



/* =========================
BUTTONS
========================= */


.btn{

    border:none;

    border-radius:10px;

    padding:12px 18px;

    cursor:pointer;

    font-family:'Poppins',sans-serif;

    font-weight:600;

    transition:.2s;

}


.btn:hover{

    transform:translateY(-2px);

}



.btn-blue{

    background:#2563eb;

    color:white;

}


.btn-blue:hover{

    background:#1d4ed8;

}



.btn-green{

    background:#16a34a;

    color:white;

}


.btn-green:hover{

    background:#15803d;

}



.btn-red{

    background:#dc2626;

    color:white;

}


.btn-outline{

    background:white;

    border:1px solid #d1d5db;

}



/* =========================
SUMMARY CARDS
========================= */


.stats{

    display:grid;

    grid-template-columns:repeat(4,1fr);

    gap:20px;

    margin-bottom:25px;

}



.stat-card{

    background:white;

    border-radius:18px;

    padding:22px;

    display:flex;

    align-items:center;

    gap:18px;

    box-shadow:0 4px 15px rgba(0,0,0,.08);

}



.stat-icon{

    width:55px;

    height:55px;

    border-radius:14px;

    display:flex;

    align-items:center;

    justify-content:center;

    font-size:24px;

}



.blue{

    background:#dbeafe;

    color:#2563eb;

}


.green{

    background:#dcfce7;

    color:#16a34a;

}


.orange{

    background:#fef3c7;

    color:#d97706;

}


.purple{

    background:#f3e8ff;

    color:#9333ea;

}



.stat-card h2{

    font-size:28px;

    margin:0;

}


.stat-card p{

    color:#6b7280;

    font-size:14px;

}



/* =========================
MAIN CARD
========================= */


.card{

    background:white;

    border-radius:18px;

    box-shadow:0 4px 15px rgba(0,0,0,.08);

    overflow:hidden;

}



/* =========================
CARD HEADER
========================= */


.card-header{

    padding:22px 25px;

    border-bottom:1px solid #e5e7eb;

    display:flex;

    justify-content:space-between;

    align-items:center;

    flex-wrap:wrap;

    gap:15px;

}


.card-header h2{

    font-size:24px;

}



/* =========================
FILTER
========================= */


.filter-box{

    padding:25px;

    display:flex;

    gap:15px;

    flex-wrap:wrap;

}



.filter-box input,
.filter-box select{

    height:45px;

    padding:0 15px;

    border-radius:10px;

    border:1px solid #d1d5db;

    font-family:'Poppins',sans-serif;

}



.filter-box input{

    flex:1;

    min-width:250px;

}


.filter-box select{

    min-width:180px;

}



/* =========================
TABLE
========================= */


.table-container{

    overflow-x:auto;

    padding:0 25px 25px;

}



table{

    width:100%;

    border-collapse:collapse;

}



th{

    background:#2563eb;

    color:white;

    padding:14px;

    text-align:left;

    font-size:14px;

}



td{

    padding:14px;

    border-bottom:1px solid #e5e7eb;

    font-size:14px;

    vertical-align:middle;

}



/* STATUS BADGE */


.badge{

    padding:6px 12px;

    border-radius:999px;

    font-size:12px;

    font-weight:600;

}



.published{

    background:#dcfce7;

    color:#166534;

}



.draft{

    background:#fef3c7;

    color:#92400e;

}



.closed{

    background:#fee2e2;

    color:#991b1b;

}



/* ACTION BUTTONS */


.action-btn{

    width:36px;

    height:36px;

    border-radius:10px;

    border:none;

    cursor:pointer;

    color:white;

}


.view{

    background:#2563eb;

}


.edit{

    background:#16a34a;

}


.delete{

    background:#dc2626;

}




/* =========================
RESPONSIVE
========================= */


@media(max-width:1200px){


.stats{

    grid-template-columns:repeat(2,1fr);

}


}



@media(max-width:992px){


.main{

    margin-left:0;

    width:100%;

    padding:85px 20px 20px;

}


.page-header{

    flex-direction:column;

    align-items:flex-start;

}


}



@media(max-width:768px){


.stats{

    grid-template-columns:1fr;

}



.filter-box{

    flex-direction:column;

}



.filter-box input,
.filter-box select,
.filter-box button{

    width:100%;

}



table{

    min-width:1100px;

}



}


</style>

</head>
    
    <body>


<?php include 'admin_sidebar.php'; ?>


<main class="main">


<!-- =========================
PAGE HEADER
========================= -->


<div class="page-header">


<div>

<h1>
Test Administration
</h1>

<p>
Create, manage, and monitor mock examinations and practice quizzes.
</p>

</div>



<a href="test_construction.php" style="text-decoration:none;">

<button class="btn btn-blue">

<i class="fa-solid fa-plus"></i>

Create Test

</button>

</a>



</div>





<!-- =========================
STATISTICS
========================= -->


<div class="stats">



<div class="stat-card">


<div class="stat-icon blue">

<i class="fa-solid fa-file-lines"></i>

</div>


<div>

<h2>

<?php echo $published['total']; ?>

</h2>


<p>
Published Tests
</p>


</div>


</div>







<div class="stat-card">


<div class="stat-icon orange">

<i class="fa-solid fa-clock"></i>

</div>


<div>

<h2>

<?php echo $draft['total']; ?>

</h2>


<p>
Draft Tests
</p>


</div>


</div>








<div class="stat-card">


<div class="stat-icon red">

<i class="fa-solid fa-circle-check"></i>

</div>


<div>

<h2>

<?php echo $closed['total']; ?>

</h2>


<p>
Closed Tests
</p>


</div>


</div>








<div class="stat-card">


<div class="stat-icon purple">

<i class="fa-solid fa-users"></i>

</div>


<div>

<h2>

<?php echo $attempts['total']; ?>

</h2>


<p>
Total Attempts
</p>


</div>


</div>



</div>







<!-- =========================
EXAM LIST CARD
========================= -->


<div class="card">



<div class="card-header">


<h2>
Manage Examinations
</h2>



</div>






<!-- FILTERS -->


<form method="GET">


<div class="filter-box">



<input

type="text"

name="search"

placeholder="Search exam title..."

value="<?php echo htmlspecialchars($search); ?>"

>






<select name="category">


<option value="">

All Categories

</option>



<?php

while($cat=mysqli_fetch_assoc($categories)){

?>


<option

value="<?php echo $cat['category_id']; ?>"

<?php

if($category==$cat['category_id']){

echo "selected";

}

?>

>


<?php echo htmlspecialchars($cat['category_name']); ?>


</option>


<?php

}

?>


</select>






<select name="type">


<option value="">

All Exam Types

</option>


<option value="Mock Exam"

<?php if($type=="Mock Exam") echo "selected"; ?>

>

Mock Exam

</option>


<option value="Practice Quiz"

<?php if($type=="Practice Quiz") echo "selected"; ?>

>

Practice Quiz

</option>


</select>







<select name="status">


<option value="">

All Status

</option>


<option value="Draft"

<?php if($status=="Draft") echo "selected"; ?>

>

Draft

</option>



<option value="Published"

<?php if($status=="Published") echo "selected"; ?>

>

Published

</option>



<option value="Closed"

<?php if($status=="Closed") echo "selected"; ?>

>

Closed

</option>



</select>





<button class="btn btn-blue" type="submit">


<i class="fa-solid fa-filter"></i>

Filter


</button>





<?php if($search!="" || $category!="" || $type!="" || $status!=""){ ?>


<a href="test_administration.php">


<button

type="button"

class="btn btn-outline"

>


Clear


</button>


</a>


<?php } ?>




</div>


</form>
    
    <!-- =========================
EXAMS TABLE
========================= -->


<div class="table-container">


<table>


<thead>


<tr>


<th>
Exam Title
</th>


<th>
Type
</th>


<th>
Category
</th>


<th>
Questions
</th>


<th>
Duration
</th>


<th>
Status
</th>


<th>
Attempts
</th>


<th width="150">
Actions
</th>


</tr>


</thead>



<tbody>



<?php


if(mysqli_num_rows($result) > 0){



while($row=mysqli_fetch_assoc($result)){



$statusClass = strtolower($row['status']);

?>


<tr>



<td>


<strong>

<?php echo htmlspecialchars($row['title']); ?>

</strong>


<br>


<small style="color:#6b7280;">

Created:

<?php echo date("M d, Y",strtotime($row['created_at'])); ?>

</small>


</td>







<td>


<?php echo htmlspecialchars($row['exam_type']); ?>


</td>







<td>


<?php echo htmlspecialchars($row['category_name']); ?>


</td>







<td>


<?php echo $row['total_questions']; ?>


</td>







<td>


<?php echo $row['duration']; ?>

mins


</td>







<td>



<span class="badge <?php echo $statusClass; ?>">


<?php echo $row['status']; ?>


</span>



</td>







<td>


<?php echo $row['attempts']; ?>


</td>







<td>



<div style="display:flex;gap:8px;">





<!-- VIEW -->

<a href="view_exam.php?id=<?php echo $row['exam_id']; ?>">


<button

class="action-btn view"

title="View Exam"

>


<i class="fa-solid fa-eye"></i>


</button>


</a>







<!-- EDIT -->


<a href="edit_exam.php?id=<?php echo $row['exam_id']; ?>">


<button

class="action-btn edit"

title="Edit Exam"

>


<i class="fa-solid fa-pen"></i>


</button>


</a>







<!-- DELETE -->


<a

href="delete_exam.php?id=<?php echo $row['exam_id']; ?>"

onclick="return confirm('Delete this examination?');"

>


<button

class="action-btn delete"

title="Delete Exam"

>


<i class="fa-solid fa-trash"></i>


</button>


</a>




</div>


</td>





</tr>



<?php


}


}else{


?>


<tr>


<td colspan="8" style="text-align:center;padding:30px;">


No examinations found.


</td>


</tr>



<?php


}


?>



</tbody>


</table>


</div>
    
    </div>


</main>





<script>


// =============================
// AUTO SUBMIT FILTER (OPTIONAL)
// =============================


document.querySelectorAll(".filter-box select")
.forEach(function(select){

    select.addEventListener("change",function(){

        this.form.submit();

    });

});



// =============================
// CONFIRM DELETE
// =============================


function confirmDelete(){

    return confirm(
        "Are you sure you want to delete this examination?"
    );

}


</script>



</body>

</html>