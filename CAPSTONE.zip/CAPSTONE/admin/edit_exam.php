<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

if ($_SESSION['usertype'] != "admin") {
    header("Location: ../user.php");
    exit();
}

include "../connection.php";

/* ===========================
   CHECK EXAM ID
=========================== */

if (!isset($_GET['id'])) {
    header("Location: test_administration.php");
    exit();
}

$exam_id = (int)$_GET['id'];

/* ===========================
   LOAD EXAM DETAILS
=========================== */

$sql = "
SELECT *
FROM exams
WHERE exam_id = ?
LIMIT 1
";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $exam_id);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) == 0) {
    header("Location: test_administration.php");
    exit();
}

$exam = mysqli_fetch_assoc($result);

/* ===========================
   LOAD ACTIVE CATEGORIES
=========================== */

$categories = mysqli_query($conn, "
SELECT
category_id,
category_name
FROM categories
WHERE status='Active'
ORDER BY category_name ASC
");

/* ===========================
   LOAD QUESTIONS
=========================== */

$questions = mysqli_query($conn, "
SELECT
q.question_id,
q.question,
q.difficulty,
c.category_name

FROM questions q

INNER JOIN categories c
ON q.category_id=c.category_id

WHERE q.status='Active'

ORDER BY
c.category_name ASC,
q.question_id DESC
");

/* ===========================
   CURRENT EXAM QUESTIONS
=========================== */

$selectedQuestions = [];

$current = mysqli_query($conn, "
SELECT question_id
FROM exam_items
WHERE exam_id='$exam_id'
");

while ($row = mysqli_fetch_assoc($current)) {

    $selectedQuestions[] = $row['question_id'];

}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Edit Examination</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    background:#edf2fb;
    font-family:'Poppins',sans-serif;
}

.main{
    margin-left:230px;
    width:calc(100% - 230px);
    min-height:100vh;
    padding:30px;
}

/* ===========================
TOP BAR
=========================== */

.topbar{
    background:#fff;
    border-radius:18px;
    padding:22px 28px;
    margin-bottom:25px;
    box-shadow:0 4px 15px rgba(0,0,0,.08);
}

.topbar h1{
    font-size:32px;
    color:#111827;
}

.topbar p{
    margin-top:5px;
    color:#6b7280;
}

/* ===========================
CARD
=========================== */

.card{
    background:#fff;
    border-radius:18px;
    overflow:hidden;
    box-shadow:0 4px 15px rgba(0,0,0,.08);
    margin-bottom:25px;
}

.card-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    flex-wrap:wrap;
    gap:12px;
    padding:22px 24px;
    border-bottom:1px solid #e5e7eb;
}

.card-header h2{
    font-size:26px;
    color:#111827;
}

/* ===========================
FORM
=========================== */

.form-grid{
    display:grid;
    grid-template-columns:repeat(2,1fr);
    gap:20px;
    padding:24px;
}

.form-group label{
    display:block;
    margin-bottom:8px;
    font-weight:600;
    color:#374151;
}

.form-group input,
.form-group select,
.form-group textarea{
    width:100%;
    border:1px solid #d1d5db;
    border-radius:10px;
    padding:12px 15px;
    font-family:'Poppins',sans-serif;
    font-size:14px;
}

.form-group input,
.form-group select{
    height:48px;
}

.form-group textarea{
    resize:vertical;
    min-height:110px;
}

.full-width{
    grid-column:1 / -1;
}

/* ===========================
QUESTION SECTION
=========================== */

.question-section{
    padding:24px;
}

.question-section h3{
    font-size:24px;
    margin-bottom:20px;
}

/* ===========================
FILTERS
=========================== */

.filters{
    display:flex;
    gap:15px;
    flex-wrap:wrap;
    margin-bottom:20px;
}

.filters input,
.filters select{
    height:48px;
    border:1px solid #d1d5db;
    border-radius:10px;
    padding:0 15px;
    font-family:'Poppins',sans-serif;
}

.filters input{
    flex:1;
    min-width:280px;
}

.filters select{
    width:220px;
}

/* ===========================
TABLE
=========================== */

.table-wrapper{
    overflow-x:auto;
}

.question-table{
    width:100%;
    border-collapse:collapse;
}

.question-table th{
    background:#2563eb;
    color:#fff;
    text-align:left;
    padding:14px;
}

.question-table td{
    padding:14px;
    border-top:1px solid #e5e7eb;
    vertical-align:top;
}

/* ===========================
BADGES
=========================== */

.badge{
    display:inline-block;
    padding:6px 12px;
    border-radius:999px;
    font-size:12px;
    font-weight:bold;
}

.easy{
    background:#dcfce7;
    color:#166534;
}

.medium{
    background:#fef3c7;
    color:#92400e;
}

.hard{
    background:#fee2e2;
    color:#991b1b;
}

/* ===========================
FOOTER
=========================== */

.footer{
    padding:24px;
    display:flex;
    justify-content:space-between;
    align-items:center;
    flex-wrap:wrap;
    gap:15px;
    border-top:1px solid #e5e7eb;
}

/* ===========================
BUTTONS
=========================== */

.btn{
    border:none;
    border-radius:10px;
    padding:12px 18px;
    cursor:pointer;
    font-size:14px;
    font-weight:600;
    font-family:'Poppins',sans-serif;
    transition:.25s;
    text-decoration:none;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:8px;
}

.btn:hover{
    transform:translateY(-2px);
}

.btn-green{
    background:#16a34a;
    color:#fff;
}

.btn-green:hover{
    background:#15803d;
}

.btn-blue{
    background:#2563eb;
    color:#fff;
}

.btn-blue:hover{
    background:#1d4ed8;
}

.btn-outline{
    background:#fff;
    border:1px solid #d1d5db;
    color:#111827;
}

.btn-outline:hover{
    background:#f9fafb;
}

/* ===========================
RESPONSIVE
=========================== */

@media(max-width:992px){

.main{
    margin-left:0;
    width:100%;
    padding:85px 20px 20px;
}

.form-grid{
    grid-template-columns:1fr;
}

}

@media(max-width:768px){

.card-header{
    flex-direction:column;
    align-items:stretch;
}

.filters{
    flex-direction:column;
}

.filters input,
.filters select{
    width:100%;
}

.footer{
    flex-direction:column;
}

.footer .btn{
    width:100%;
}

.question-table{
    min-width:900px;
}

}

</style>

</head>
    
    <body>

<?php include "admin_sidebar.php"; ?>

<main class="main">

<!-- =========================
TOP BAR
========================= -->

<div class="topbar">

    <h1>Edit Examination</h1>

    <p>
        Update the examination details and selected questions.
    </p>

</div>

<form
id="examForm"
action="update_exam.php"
method="POST">

<input
type="hidden"
name="exam_id"
value="<?php echo $exam_id; ?>">

<!-- =========================
EXAM INFORMATION
========================= -->

<div class="card">

<div class="card-header">

<h2>Exam Information</h2>

<div>

<button
type="submit"
class="btn btn-green">

<i class="fa-solid fa-floppy-disk"></i>

Update Examination

</button>

</div>

</div>

<div class="form-grid">

<!-- TITLE -->

<div class="form-group">

<label>Exam Title</label>

<input
type="text"
name="title"
required
value="<?php echo htmlspecialchars($exam['title']); ?>">

</div>

<!-- CATEGORY -->

<div class="form-group">

<label>Category</label>

<select
name="category_id"
required>

<option value="">
Select Category
</option>

<?php
mysqli_data_seek($categories,0);

while($cat=mysqli_fetch_assoc($categories)){
?>

<option
value="<?php echo $cat['category_id']; ?>"
<?php
if($cat['category_id']==$exam['category_id']){
    echo "selected";
}
?>>

<?php echo htmlspecialchars($cat['category_name']); ?>

</option>

<?php
}
?>

</select>

</div>

<!-- EXAM TYPE -->

<div class="form-group">

<label>Exam Type</label>

<select
name="exam_type"
required>

<option
value="Mock Exam"
<?php if($exam['exam_type']=="Mock Exam") echo "selected"; ?>>

Mock Exam

</option>

<option
value="Practice Quiz"
<?php if($exam['exam_type']=="Practice Quiz") echo "selected"; ?>>

Practice Quiz

</option>

</select>

</div>

<!-- DURATION -->

<div class="form-group">

<label>Duration (Minutes)</label>

<input
type="number"
name="duration"
required
min="1"
value="<?php echo $exam['duration']; ?>">

</div>

<!-- PASSING SCORE -->

<div class="form-group">

<label>Passing Score (%)</label>

<input
type="number"
name="passing_score"
required
min="1"
max="100"
value="<?php echo $exam['passing_score']; ?>">

</div>

<!-- STATUS -->

<div class="form-group">

<label>Status</label>

<select
name="status"
required>

<option
value="Draft"
<?php if($exam['status']=="Draft") echo "selected"; ?>>

Draft

</option>

<option
value="Published"
<?php if($exam['status']=="Published") echo "selected"; ?>>

Published

</option>

<option
value="Closed"
<?php if($exam['status']=="Closed") echo "selected"; ?>>

Closed

</option>

</select>

</div>

<!-- DESCRIPTION -->

<div class="form-group full-width">

<label>Description</label>

<textarea
name="description"
placeholder="Enter examination description..."><?php
echo htmlspecialchars($exam['description']);
?></textarea>

</div>

<!-- EXAM INSTRUCTIONS -->

<div class="form-group full-width">

<label>Examination Instructions</label>

<textarea
name="instructions"
placeholder="Example:

• Read every question carefully.
• Choose the best answer.
• Do not refresh the browser while taking the exam.
• Click Submit after answering all questions."><?php
echo htmlspecialchars($exam['instructions']);
?></textarea>

</div>

<!-- TOTAL -->

<div class="form-group">

<label>Total Selected Questions</label>

<input
type="text"
id="totalQuestions"
readonly
value="<?php echo count($selectedQuestions); ?>">

</div>

</div>

</div>
    
    <!-- =========================
QUESTION BANK
========================= -->

<div class="card">

<div class="card-header">

<h2>Question Bank</h2>

</div>

<div class="question-section">

<!-- FILTERS -->

<div class="filters">

<input
type="text"
id="searchQuestion"
placeholder="Search question...">

<select id="categoryFilter">

<option value="">
All Categories
</option>

<?php
mysqli_data_seek($categories,0);

while($cat=mysqli_fetch_assoc($categories)){
?>

<option value="<?php echo htmlspecialchars($cat['category_name']); ?>">

<?php echo htmlspecialchars($cat['category_name']); ?>

</option>

<?php
}
?>

</select>

<select id="difficultyFilter">

<option value="">
All Difficulty
</option>

<option value="Easy">Easy</option>
<option value="Medium">Medium</option>
<option value="Hard">Hard</option>

</select>

</div>

<?php

$totalAvailable = mysqli_num_rows($questions);

mysqli_data_seek($questions,0);

?>

<p style="margin-bottom:15px;color:#6b7280;">

Available Questions :

<strong>

<?php echo $totalAvailable; ?>

</strong>

</p>

<div class="table-wrapper">

<table class="question-table">

<thead>

<tr>

<th width="60">

<input
type="checkbox"
id="selectAll">

</th>

<th>Question</th>

<th width="220">Category</th>

<th width="120">Difficulty</th>

</tr>

</thead>

<tbody id="questionTable">

<?php

while($row=mysqli_fetch_assoc($questions)){

$difficulty = strtolower($row['difficulty']);

$checked = in_array($row['question_id'],$selectedQuestions)
? "checked"
: "";

?>

<tr>

<td>

<input
type="checkbox"
class="question-check"
name="questions[]"
value="<?php echo $row['question_id']; ?>"
<?php echo $checked; ?>>

</td>

<td>

<?php echo htmlspecialchars($row['question']); ?>

</td>

<td>

<?php echo htmlspecialchars($row['category_name']); ?>

</td>

<td>

<span class="badge <?php echo $difficulty; ?>">

<?php echo htmlspecialchars($row['difficulty']); ?>

</span>

</td>

</tr>

<?php
}
?>

</tbody>

</table>

</div>

</div>

<!-- FOOTER -->

<div class="footer">

<div>

<strong>Selected Questions :</strong>

<span id="selectedCount">

<?php echo count($selectedQuestions); ?>

</span>

</div>

<div style="display:flex;gap:10px;flex-wrap:wrap;">

<button
type="button"
class="btn btn-outline"
onclick="window.location='test_administration.php'">

Cancel

</button>

<button
type="submit"
class="btn btn-green">

<i class="fa-solid fa-floppy-disk"></i>

Update Examination

</button>

</div>

</div>

</div>

</form>

</main>
        
        <script>

// =====================================
// SEARCH + FILTER
// =====================================

function filterQuestions(){

    let keyword =
    document.getElementById("searchQuestion")
    .value
    .toLowerCase();

    let category =
    document.getElementById("categoryFilter")
    .value;

    let difficulty =
    document.getElementById("difficultyFilter")
    .value;

    let rows =
    document.querySelectorAll("#questionTable tr");

    rows.forEach(function(row){

        let question =
        row.cells[1].innerText.toLowerCase();

        let cat =
        row.cells[2].innerText.trim();

        let diff =
        row.cells[3].innerText.trim();

        let show =
            question.includes(keyword)
            &&
            (category=="" || cat==category)
            &&
            (difficulty=="" || diff==difficulty);

        row.style.display = show ? "" : "none";

    });

}

document
.getElementById("searchQuestion")
.addEventListener("keyup",filterQuestions);

document
.getElementById("categoryFilter")
.addEventListener("change",filterQuestions);

document
.getElementById("difficultyFilter")
.addEventListener("change",filterQuestions);


// =====================================
// COUNT SELECTED QUESTIONS
// =====================================

function updateSelectedCount(){

    let checked =
    document.querySelectorAll(".question-check:checked");

    let total = checked.length;

    document.getElementById("selectedCount").innerHTML = total;

    document.getElementById("totalQuestions").value = total;

    let all =
    document.querySelectorAll(".question-check").length;

    document.getElementById("selectAll").checked =
        (total == all && all > 0);

}


// =====================================
// CHECKBOX EVENTS
// =====================================

document
.querySelectorAll(".question-check")
.forEach(function(box){

    box.addEventListener(
        "change",
        updateSelectedCount
    );

});


// =====================================
// SELECT ALL
// =====================================

document
.getElementById("selectAll")
.addEventListener("change",function(){

    let status = this.checked;

    document
    .querySelectorAll(".question-check")
    .forEach(function(box){

        box.checked = status;

    });

    updateSelectedCount();

});


// =====================================
// INITIAL COUNT
// =====================================

updateSelectedCount();


// =====================================
// FORM VALIDATION
// =====================================

document
.getElementById("examForm")
.addEventListener("submit",function(e){

    let total =
    document.querySelectorAll(
        ".question-check:checked"
    ).length;

    if(total==0){

        alert(
            "Please select at least one question."
        );

        e.preventDefault();

        return;

    }

});

</script>

</body>
</html>