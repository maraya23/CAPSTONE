<?php

session_start();


if(!isset($_SESSION['admin_id'])){

    header("Location: ../login.php");
    exit();

}


if($_SESSION['usertype'] != "admin"){

    header("Location: ../user.php");
    exit();

}


include "../connection.php";



// ==============================
// CHECK EXAM ID
// ==============================


if(!isset($_GET['id'])){

    header("Location:test_administration.php");
    exit();

}


$exam_id = intval($_GET['id']);




// ==============================
// LOAD EXAM DETAILS
// ==============================


$sql = "

SELECT

*

FROM exams

WHERE exam_id=?

";


$stmt=mysqli_prepare($conn,$sql);


mysqli_stmt_bind_param(

$stmt,

"i",

$exam_id

);


mysqli_stmt_execute($stmt);


$result=mysqli_stmt_get_result($stmt);



if(mysqli_num_rows($result)==0){

    die("Exam not found.");

}



$exam=mysqli_fetch_assoc($result);






// ==============================
// LOAD CATEGORIES
// ==============================


$categories=mysqli_query($conn,"

SELECT

category_id,

category_name

FROM categories

WHERE status='Active'

ORDER BY category_name ASC

");






// ==============================
// LOAD QUESTIONS
// ==============================


$questions=mysqli_query($conn,"

SELECT

q.question_id,

q.question,

q.difficulty,

c.category_name


FROM questions q


INNER JOIN categories c

ON q.category_id=c.category_id


WHERE q.status='Active'


ORDER BY q.question_id DESC


");






// ==============================
// GET CURRENT SELECTED QUESTIONS
// ==============================


$selected=[];


$current=mysqli_query($conn,"

SELECT question_id

FROM exam_items

WHERE exam_id='$exam_id'

");



while($row=mysqli_fetch_assoc($current)){


    $selected[]=$row['question_id'];


}



?>

<!DOCTYPE html>

<html lang="en">

<head>


<meta charset="UTF-8">


<meta name="viewport" content="width=device-width, initial-scale=1.0">


<title>
Edit Exam
</title>



<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">


<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">



<style>


*{

    margin:0;
    padding:0;
    box-sizing:border-box;

}



body{

    background:#edf2fb;

    font-family:'Poppins',sans-serif;

}




.main{

    margin-left:230px;

    width:calc(100% - 230px);

    min-height:100vh;

    padding:30px;

}




.page-header{

    background:white;

    padding:25px;

    border-radius:18px;

    box-shadow:0 4px 15px rgba(0,0,0,.08);

    margin-bottom:25px;

}



.page-header h1{

    font-size:32px;

    color:#111827;

}



.page-header p{

    color:#6b7280;

    margin-top:5px;

}




.card{

    background:white;

    border-radius:18px;

    box-shadow:0 4px 15px rgba(0,0,0,.08);

    overflow:hidden;

    margin-bottom:25px;

}



.card-header{

    padding:20px 25px;

    border-bottom:1px solid #e5e7eb;

    display:flex;

    justify-content:space-between;

    align-items:center;

    flex-wrap:wrap;

    gap:15px;

}



.card-header h2{

    font-size:25px;

}





.form-grid{

    padding:25px;

    display:grid;

    grid-template-columns:repeat(2,1fr);

    gap:20px;

}



.form-group label{

    display:block;

    font-weight:600;

    margin-bottom:8px;

    color:#374151;

}



.form-group input,
.form-group select{

    width:100%;

    height:48px;

    border:1px solid #d1d5db;

    border-radius:10px;

    padding:0 14px;

    font-family:'Poppins',sans-serif;

}




.question-section{

    padding:25px;

}



.question-section h2{

    margin-bottom:20px;

}




.search-box{

    margin-bottom:20px;

}



.search-box input{

    width:100%;

    height:48px;

    border:1px solid #d1d5db;

    border-radius:10px;

    padding:0 15px;

    font-family:'Poppins',sans-serif;

}





.table-container{

    overflow-x:auto;

}



table{

    width:100%;

    border-collapse:collapse;

}



th{

    background:#2563eb;

    color:white;

    padding:14px;

    text-align:left;

}



td{

    padding:14px;

    border-bottom:1px solid #e5e7eb;

    vertical-align:top;

}





.badge{

    padding:6px 12px;

    border-radius:20px;

    font-size:12px;

    font-weight:bold;

}



.easy{

    background:#dcfce7;

    color:#166534;

}



.medium{

    background:#fef3c7;

    color:#92400e;

}



.hard{

    background:#fee2e2;

    color:#991b1b;

}




.footer{

    padding:25px;

    border-top:1px solid #e5e7eb;

    display:flex;

    justify-content:space-between;

    align-items:center;

    flex-wrap:wrap;

    gap:15px;

}





.btn{

    padding:12px 18px;

    border:none;

    border-radius:10px;

    cursor:pointer;

    font-family:'Poppins',sans-serif;

    font-weight:600;

}



.btn-blue{

    background:#2563eb;

    color:white;

}



.btn-green{

    background:#16a34a;

    color:white;

}



.btn-red{

    background:#dc2626;

    color:white;

}



.btn-outline{

    background:white;

    border:1px solid #d1d5db;

}






@media(max-width:992px){


.main{

    margin-left:0;

    width:100%;

    padding:85px 20px 20px;

}



.form-grid{

    grid-template-columns:1fr;

}


}





@media(max-width:768px){


.card-header{

    flex-direction:column;

    align-items:flex-start;

}



.footer{

    flex-direction:column;

}



.footer .btn{

    width:100%;

}



table{

    min-width:900px;

}



}




</style>


</head>
    
    <body>


<?php include "admin_sidebar.php"; ?>



<main class="main">



<div class="page-header">


<h1>

Edit Mock Examination

</h1>


<p>

Update exam details and manage selected questions from Test Bank.

</p>


</div>






<form action="update_exam.php" method="POST">



<input type="hidden" name="exam_id" value="<?php echo $exam_id; ?>">






<div class="card">



<div class="card-header">


<h2>

Exam Information

</h2>


</div>






<div class="form-grid">






<div class="form-group">


<label>
Exam Title
</label>


<input

type="text"

name="title"

value="<?php echo htmlspecialchars($exam['title']); ?>"

required

>


</div>









<div class="form-group">


<label>
Category
</label>



<select name="category_id" required>


<option value="">
Select Category
</option>



<?php while($cat=mysqli_fetch_assoc($categories)){ ?>


<option

value="<?php echo $cat['category_id']; ?>"

<?php

if($cat['category_id']==$exam['category_id']){

echo "selected";

}

?>

>


<?php echo htmlspecialchars($cat['category_name']); ?>


</option>



<?php } ?>


</select>


</div>









<div class="form-group">


<label>
Exam Type
</label>


<select name="exam_type">


<option value="Mock Exam"

<?php

if($exam['exam_type']=="Mock Exam"){

echo "selected";

}

?>

>

Mock Exam

</option>



<option value="Practice Quiz"

<?php

if($exam['exam_type']=="Practice Quiz"){

echo "selected";

}

?>

>

Practice Quiz

</option>



</select>


</div>









<div class="form-group">


<label>
Duration (Minutes)
</label>


<input

type="number"

name="duration"

value="<?php echo $exam['duration']; ?>"

required

>


</div>









<div class="form-group">


<label>
Passing Score (%)
</label>


<input

type="number"

name="passing_score"

value="<?php echo $exam['passing_score']; ?>"

min="1"

max="100"

required

>


</div>









<div class="form-group">


<label>
Status
</label>


<select name="status">


<option value="Draft"

<?php

if($exam['status']=="Draft"){

echo "selected";

}

?>

>

Draft

</option>



<option value="Published"

<?php

if($exam['status']=="Published"){

echo "selected";

}

?>

>

Published

</option>



<option value="Closed"

<?php

if($exam['status']=="Closed"){

echo "selected";

}

?>

>

Closed

</option>



</select>


</div>






</div>



</div>









<div class="card">



<div class="card-header">


<h2>

Select Questions From Test Bank

</h2>


</div>







<div class="question-section">





<div class="search-box">


<input

type="text"

id="searchQuestion"

placeholder="Search questions..."

>


</div>








<div class="table-container">



<table>



<thead>


<tr>


<th width="60">


Select

</th>


<th>

Question

</th>


<th width="220">

Category

</th>


<th width="120">

Difficulty

</th>


</tr>


</thead>






<tbody id="questionTable">



<?php while($row=mysqli_fetch_assoc($questions)){



$difficulty=strtolower($row['difficulty']);



$checked="";



if(in_array($row['question_id'],$selected)){


$checked="checked";


}



?>



<tr>


<td>



<input

type="checkbox"

name="questions[]"

value="<?php echo $row['question_id']; ?>"

<?php echo $checked; ?>

>




</td>





<td>


<?php echo htmlspecialchars($row['question']); ?>


</td>





<td>


<?php echo htmlspecialchars($row['category_name']); ?>


</td>






<td>


<span class="badge <?php echo $difficulty; ?>">


<?php echo $row['difficulty']; ?>


</span>


</td>





</tr>



<?php } ?>



</tbody>



</table>



</div>





</div>



</div>









<div class="footer">



<a href="test_administration.php">


<button

type="button"

class="btn btn-outline">

Cancel

</button>


</a>






<button

type="submit"

class="btn btn-green">


<i class="fa-solid fa-save"></i>


Update Exam


</button>



</div>





</form>




</main>
        
        <script>


// =================================
// SEARCH QUESTIONS
// =================================


document.getElementById("searchQuestion")
.addEventListener("keyup",function(){


    let search = this.value.toLowerCase();


    let rows = document.querySelectorAll("#questionTable tr");



    rows.forEach(function(row){


        let text = row.textContent.toLowerCase();



        if(text.includes(search)){


            row.style.display="";


        }else{


            row.style.display="none";


        }



    });



});



</script>



</body>

</html>