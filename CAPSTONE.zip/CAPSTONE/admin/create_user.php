<?php
session_start();

if (!isset($_SESSION['admin_id']) || strtolower($_SESSION['usertype']) != "admin") {
    header("Location: ../login.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Create User Account | e-Nurse</title>

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

    *{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    margin:0;
    font-family:'Poppins',sans-serif;
    background:#f3f5fb;
}

.main{
    margin-left:230px;
    width:calc(100% - 230px);
    min-height:100vh;
    padding:30px;
}

.topbar{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:30px;
    gap:20px;
    flex-wrap:wrap;
}

.topbar h1{
    margin:0;
    font-size:32px;
    color:#111827;
    font-weight:600;
}
    
/* ==========================
   TOP BAR
========================== */

.welcome{
    background:#fff;
    padding:12px 20px;
    border-radius:14px;
    box-shadow:0 3px 12px rgba(0,0,0,.08);
    font-size:15px;
    font-weight:500;
}

/* ==========================
   PAGE LAYOUT
========================== */

.wrapper{
    display:grid;
    grid-template-columns:2.2fr 1fr;
    gap:28px;
    align-items:start;
}

/* ==========================
   FORM CARD
========================== */

.form-card{
    background:#fff;
    padding:30px;
    border-radius:20px;
    box-shadow:0 5px 18px rgba(0,0,0,.08);
}

.form-card h2{
    font-size:25px;
    margin-bottom:25px;
    color:#111827;
}

.form-card h2 i{
    color:#2563eb;
    margin-right:10px;
}

/* ==========================
   TWO COLUMN FORM
========================== */

.form-grid{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:18px;
}

.form-group{
    display:flex;
    flex-direction:column;
}

.form-group.full{
    grid-column:1 / -1;
}

/* ==========================
   LABELS
========================== */

label{
    font-size:14px;
    font-weight:600;
    margin-bottom:6px;
    color:#374151;
}

/* ==========================
   INPUTS
========================== */

input,
select{
    width:100%;
    padding:12px 14px;
    border:1px solid #d1d5db;
    border-radius:10px;
    font-size:15px;
    transition:.25s;
}

input:focus,
select:focus{
    outline:none;
    border-color:#2563eb;
    box-shadow:0 0 0 3px rgba(37,99,235,.15);
}

/* ==========================
   PASSWORD
========================== */

.password-box{
    position:relative;
}

.password-box input{
    padding-right:45px;
}

.password-box i{
    position:absolute;
    right:15px;
    top:50%;
    transform:translateY(-50%);
    cursor:pointer;
    color:#2563eb;
}

.password-box i:hover{
    color:#1d4ed8;
}

/* ==========================
   USERNAME SUGGESTION
========================== */

.username-box{
    position:relative;
}

#usernameSuggestions{

    display:none;

    position:absolute;

    top:105%;

    left:0;

    width:100%;

    background:#fff;

    border:1px solid #ddd;

    border-radius:10px;

    overflow:hidden;

    z-index:999;

    box-shadow:0 5px 15px rgba(0,0,0,.15);

}

.suggestion{

    padding:12px;

    cursor:pointer;

}

.suggestion:hover{

    background:#edf4ff;

}

/* ==========================
   BUTTON
========================== */

button{

    width:100%;

    padding:15px;

    border:none;

    border-radius:12px;

    background:#2563eb;

    color:white;

    font-size:16px;

    font-weight:600;

    cursor:pointer;

    transition:.25s;

}

button:hover{

    background:#1d4ed8;

}

/* ==========================
   MESSAGE
========================== */

.error{

    color:#dc2626;

    font-weight:600;

    margin-bottom:20px;

}

/* ==========================
   RIGHT PANEL
========================== */

.info-card{

    background:linear-gradient(135deg,#2563eb,#1d4ed8);

    color:white;

    border-radius:20px;

    padding:30px;

    min-height:100%;

    box-shadow:0 5px 18px rgba(0,0,0,.10);

}

.info-card h3{

    margin-bottom:20px;

    font-size:24px;

}

.info-card p{

    opacity:.95;

    line-height:1.7;

    margin-bottom:20px;

}

.info-card ul{

    padding-left:18px;

    line-height:2;

}

.info-card li{

    margin-bottom:5px;

}

.info-icon{

    text-align:center;

    margin-top:40px;

}

.info-icon i{

    font-size:90px;

    opacity:.9;

}

/* ==========================
   MOBILE
========================== */

@media(max-width:900px){

.main{

    margin-left:0;

    width:100%;

    padding:80px 20px 20px;

}

.wrapper{

    grid-template-columns:1fr;

}

.form-grid{

    grid-template-columns:1fr;

}

.topbar{

    flex-direction:column;

    align-items:flex-start;

}

.topbar h1{

    font-size:28px;

}

}
    </style>

</head>
    
    <body>

<?php include 'admin_sidebar.php'; ?>

<main class="main">

<div class="topbar">

    <h1>Create User Account</h1>

    <div class="welcome">
        <i class="fa-solid fa-user-shield"></i>
        Administrator Panel
    </div>

</div>

<div class="wrapper">

    <!-- LEFT SIDE -->

    <div class="form-card">

        <h2>

            <i class="fa-solid fa-user-plus"></i>

            Create New User

        </h2>

        <?php

        if(isset($_GET['success'])){
            echo "<p style='color:#16a34a;font-weight:600;margin-bottom:20px;'>
                    User account created successfully.
                  </p>";
        }

        if(isset($_GET['error'])){

            switch($_GET['error']){

                case "password":
                    echo "<p class='error'>Password must be between 1 and 8 characters.</p>";
                break;
                    
                    case "confirm":
    				echo "<p class='error'>
            				Passwords do not match.
          					</p>";
				break;

                case "username":
                    echo "<p class='error'>Username already exists.</p>";
                break;

                case "email":
                    echo "<p class='error'>Email already exists.</p>";
                break;

                case "name":
                    echo "<p class='error'>A user with the same name already exists.</p>";
                break;

            }

        }

        ?>

        <form action="save_user.php" method="POST" id="createUserForm">

            <div class="form-grid">

                <div class="form-group">

                    <label>First Name</label>

                    <input
                    type="text"
                    id="firstname"
                    name="firstname"
                    maxlength="50"
                    required>

                </div>

                <div class="form-group">

                    <label>Middle Name</label>

                    <input
                    type="text"
                    name="middlename"
                    maxlength="50">

                </div>

                <div class="form-group">

                    <label>Surname</label>

                    <input
                    type="text"
                    name="surname"
                    maxlength="50"
                    required>

                </div>

                <div class="form-group">

                    <label>Email</label>

                    <input
                    type="email"
                    name="email"
                    maxlength="100">

                </div>

                <div class="form-group">

                    <label>Username</label>

                    <div class="username-box">

                        <input
						type="text"
						id="username"
						name="username"
						autocomplete="off"
						readonly
						required>

                    </div>

                </div>

                <div class="form-group">

                    <label>User Type</label>

                    <select name="usertype" required>

                        <option value="">Select User Type</option>

                        <option value="admin">Administrator</option>

                        <option value="user">User</option>

                    </select>

                </div>

                <div class="form-group">

                    <label>Password</label>

                    <div class="password-box">

<input
type="password"
id="password"
name="password"
required>

<i class="fa-solid fa-eye"
id="eyeIcon"
onclick="showPassword()"></i>

</div>
                </div>

                <div class="form-group">

                    <label>Confirm Password</label>

                    <div class="password-box">

<input
type="password"
id="confirm_password"
name="confirm_password"
required>

<i class="fa-solid fa-eye"
onclick="showConfirmPassword()"></i>

</div>

                </div>

                <div class="form-group full">

                    <button type="submit" name="create">

                        <i class="fa-solid fa-user-plus"></i>

                        Create User

                    </button>

                </div>

            </div>

        </form>

    </div>

    <!-- RIGHT SIDE -->

    <div class="info-card">

        <h3>

            <i class="fa-solid fa-circle-info"></i>

            Administrator Guide

        </h3>

        <p>

            Create new administrator and student accounts for the
            <strong>e-Nurse Online Review and Mock Board Examination System.</strong>

        </p>

        <ul>

            <li>Username must be unique.</li>

            <li>Email address should be provided by the user.</li>

            <li>Password must contain <strong>8 characters and above</strong>.</li>

            <li>Users can change their password later.</li>

            <li>Select the correct user role before saving.</li>

        </ul>

        <div class="info-icon">

            <i class="fa-solid fa-user-nurse"></i>

        </div>

    </div>

</div>

</main>
        
        <script>

const firstname = document.getElementById("firstname");
const username = document.getElementById("username");

let timer;

/* ==========================
   USERNAME SUGGESTIONS
========================== */

firstname.addEventListener("input", function () {

    clearTimeout(timer);

    timer = setTimeout(loadSuggestions, 400);

});

function loadSuggestions(){

    let name = firstname.value.trim();

    if(name === ""){

        username.value = "";
        return;

    }

    fetch("suggest_user.php",{

        method:"POST",

        headers:{
            "Content-Type":"application/x-www-form-urlencoded"
        },

        body:"firstname=" + encodeURIComponent(name)

    })

    .then(response => response.json())

    .then(data => {

        if(data.length > 0){

            username.value = data[0];

        }else{

            username.value = "";

        }

    });

};

/* ==========================
   SHOW PASSWORD
========================== */

function showPassword(){

    let password = document.getElementById("password");
    let eye = document.getElementById("eyeIcon");

    if(password.type==="password"){

        password.type="text";

        eye.classList.remove("fa-eye");
        eye.classList.add("fa-eye-slash");

    }else{

        password.type="password";

        eye.classList.remove("fa-eye-slash");
        eye.classList.add("fa-eye");

    }

}

/* ==========================
   SHOW CONFIRM PASSWORD
========================== */

function showConfirmPassword(){

    let confirm = document.getElementById("confirm_password");

    if(confirm.type==="password"){

        confirm.type="text";

    }else{

        confirm.type="password";

    }

}

/* ==========================
   PASSWORD VALIDATION
========================== */

document.getElementById("createUserForm").addEventListener("submit", function(e){

    let password = document.getElementById("password").value.trim();
    let confirm = document.getElementById("confirm_password").value.trim();

    if(password.length < 8){

        alert("Password must be at least 8 characters.");

        e.preventDefault();

        return;

    }

    if(password !== confirm){

        alert("Passwords do not match.");

        e.preventDefault();

        return;

    }

});
            
/* ==========================
   AUTO CAPITALIZE NAMES
========================== */

document.querySelectorAll("input[name='firstname'], input[name='middlename'], input[name='surname']")
.forEach(function(field){

    field.addEventListener("input", function(){

        this.value = this.value.replace(/\b\w/g, function(letter){

            return letter.toUpperCase();

        });

    });

});
            
            // Limit password to 8 characters while typing
document.getElementById("password").addEventListener("input", function () {
    if (this.value.length > 8) {
        this.value = this.value.substring(0, 8);
    }
});

document.getElementById("confirm_password").addEventListener("input", function () {
    if (this.value.length > 8) {
        this.value = this.value.substring(0, 8);
    }
});

</script>
        
        </body>

</html>
    