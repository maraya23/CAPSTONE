<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: /CAPSTONE/login.php');
    exit();
}

if ($_SESSION['usertype'] != 'admin') {
    header('Location: ../user.php');
    exit();
}

include '../connection.php';

// Get filters
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$category = isset($_GET['category']) ? trim($_GET['category']) : '';

// Build query
$sql = 'SELECT id, question, category, difficulty FROM questions WHERE 1=1';
$params = [];
$types = '';

if ($search !== '') {
    $sql .= ' AND question LIKE ?';
    $params[] = '%' . $search . '%';
    $types .= 's';
}

if ($category !== '') {
    $sql .= ' AND category = ?';
    $params[] = $category;
    $types .= 's';
}

$sql .= ' ORDER BY id DESC';

$stmt = mysqli_prepare($conn, $sql);

if (!$stmt) {
    die('SQL Error: ' . mysqli_error($conn));
}

if (!empty($params)) {
    mysqli_stmt_bind_param($stmt, $types, ...$params);
}

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

if (!$result) {
    die('Query Error: ' . mysqli_error($conn));
}

?>

<!DOCTYPE html>
<html lang='en'>
<head>
<meta charset='UTF-8'>
<meta name='viewport' content='width=device-width, initial-scale=1.0'>
<title>Admin - Test Bank</title>

<link rel='stylesheet'
href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css'>

<style>

*{
    box-sizing:border-box;
}

body{
    margin:0;
    font-family:'Poppins',sans-serif;
    background:#edf2fb;
}

/* Main */

.main{
    margin-left:230px;
    width:calc(100% - 230px);
    min-height:100vh;
    padding:30px;
    box-sizing:border-box;
    overflow-x:auto;
}

.page-title{
    font-size:30px;
    font-weight:600;
    color:#111827;
    margin-bottom:25px;
}

/* Card */

.card{
    background:#fff;
    border-radius:18px;
    padding:28px;
    box-shadow:0 4px 18px rgba(0,0,0,.08);
}

/* Header */

.card-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    margin-bottom:20px;
}

.card-header h2{
    margin:0;
    font-size:22px;
    font-weight:600;
}

/* Controls */

.controls{
    display:flex;
    align-items:center;
    gap:15px;
    flex-wrap:wrap;
    margin-bottom:25px;
}

.search-box{
    position:relative;
    flex:1;
    min-width:320px;
    max-width:520px;
}

.search-box i{
    position:absolute;
    left:15px;
    top:50%;
    transform:translateY(-50%);
    color:#9ca3af;
}

.search-box input{
    width:100%;
    height:48px;
    padding:0 45px;
    border:1px solid #d1d5db;
    border-radius:12px;
    font-size:14px;
    font-family:'Poppins',sans-serif;
    background:#fff;
    transition:.25s;
}

.search-box input:focus{
    outline:none;
    border-color:#2563eb;
    box-shadow:0 0 0 4px rgba(37,99,235,.15);
}

.controls select{
    width:240px;
    height:48px;
    padding:0 15px;
    border:1px solid #d1d5db;
    border-radius:12px;
    font-family:'Poppins',sans-serif;
}

.controls select:focus{
    outline:none;
    border-color:#2563eb;
    box-shadow:0 0 0 4px rgba(37,99,235,.15);
}

select,
input[type=text]{
    padding:11px 14px;
    border:1px solid #d1d5db;
    border-radius:10px;
    font-size:14px;
    font-family:'Poppins',sans-serif;
}

select{
    min-width:180px;
}

input[type=text]{
    min-width:300px;
}

/* Buttons */

.btn{
    border:none;
    border-radius:10px;
    padding:11px 18px;
    cursor:pointer;
    color:#fff;
    font-size:14px;
    font-weight:600;
    font-family:'Poppins',sans-serif;
    transition:.25s;
}

.btn:hover{
    transform:translateY(-2px);
}

.btn-blue{
    background:#2563eb;
}

.btn-blue:hover{
    background:#1d4ed8;
}

.btn-red{
    background:#dc2626;
}

.btn-red:hover{
    background:#b91c1c;
}

.icon-btn{
    width:38px;
    height:38px;
    border:none;
    border-radius:10px;
    cursor:pointer;
    color:#fff;
    transition:.2s;
}

.view-btn{
    background:#2563eb;
}

.edit-btn{
    background:#16a34a;
}

.delete-btn{
    background:#dc2626;
}

.view-btn:hover{
    background:#1d4ed8;
}

.edit-btn:hover{
    background:#15803d;
}

.delete-btn:hover{
    background:#b91c1c;
}

.icon-btn:hover{
    background:#e5e7eb;
    transform:scale(1.05);
}

.icon-btn:hover{
    background:#e5e7eb;
}

/* Table */

.table-container{
    overflow-x:auto;
}

table{
    width:100%;
    border-collapse:collapse;
}

th{
    text-align:left;
    padding:14px;
    background:#2563eb;
    color:#fff;
    font-size:14px;
}

td{
    padding:14px;
    border-top:1px solid #e5e7eb;
    vertical-align:top;
    font-size:14px;
}

.actions{
    display:flex;
    gap:8px;
}

/* Difficulty badges */

.badge{
    display:inline-block;
    padding:6px 12px;
    border-radius:999px;
    font-size:12px;
    font-weight:bold;
}

.easy{
    background:#dcfce7;
    color:#166534;
}

.medium{
    background:#fef3c7;
    color:#92400e;
}

.hard{
    background:#fee2e2;
    color:#991b1b;
}

    @media (max-width:768px){

.main{
    margin-left:0;
    width:100%;
    padding:85px 15px 20px;
}

.controls{
    flex-direction:column;
    align-items:stretch;
}

.search-box{
    flex:1;
    min-width:320px;
    max-width:520px;
}

.search-box input{
    width:100%;
    height:48px;
    padding:0 15px;
    border:1px solid #d1d5db;
    border-radius:12px;
    background:#fff;
    font-size:14px;
    font-family:'Poppins',sans-serif;
    box-sizing:border-box;
    transition:.25s;
}

.search-box input:focus{
    outline:none;
    border-color:#2563eb;
    box-shadow:0 0 0 4px rgba(37,99,235,.15);
}

.controls select{
    width:100%;
}

.btn{
    width:100%;
}

.table-container{
    overflow-x:auto;
}

table{
    min-width:950px;
}

.page-title{
    font-size:26px;
}

}
    
</style>
</head>

<body>

   <?php include 'admin_sidebar.php'; ?>

    <!-- Main -->
    <main class='main'>

        <div class="page-title">
    Test Banking
</div>

<p style="margin-top:-12px;margin-bottom:25px;color:#6b7280;font-size:15px;">
    Manage and organize all examination questions.
</p>
        <div class='card'>

           <div class='card-header'>
    <h2>Test Bank</h2>
</div>

            <form method="GET" class="controls">

<div class="search-box">

    <input
        type="text"
        name="search"
        placeholder="Search questions..."
        value="<?php echo htmlspecialchars($search); ?>">

</div>

<select name="category">

<option value="">All Categories</option>

<option value="Medical-Surgical Nursing"
<?php if($category=="Medical-Surgical Nursing") echo "selected"; ?>>
Medical-Surgical Nursing
</option>

<option value="Fundamentals of Nursing"
<?php if($category=="Fundamentals of Nursing") echo "selected"; ?>>
Fundamentals of Nursing
</option>

<option value="Maternal & Child Nursing"
<?php if($category=="Maternal & Child Nursing") echo "selected"; ?>>
Maternal & Child Nursing
</option>

</select>

<button class="btn btn-blue" type="submit">
<i class="fa-solid fa-search"></i>
Search
</button>

<?php if($search!="" || $category!=""){ ?>

<a href="test_bank.php">

<button type='button' class='btn btn-blue'>

<i class="fa-solid fa-xmark"></i>

Clear

</button>

</a>

<?php } ?>

</form>

            <div class='table-container'>

                <table>

                    <tr>
                        <th width='70'>ID</th>
                        <th>Question</th>
                        <th width='220'>Category</th>
                        <th width='120'>Difficulty</th>
                        <th width='120'>Action</th>
                    </tr>

                 <?php if(mysqli_num_rows($result) > 0){ ?>

    <?php while($row = mysqli_fetch_assoc($result)){ ?>

    <tr>

        <td><?php echo $row['id']; ?></td>

        <td><?php echo htmlspecialchars($row['question']); ?></td>

        <td><?php echo htmlspecialchars($row['category']); ?></td>

        <td>
            <?php
            $difficulty = $row['difficulty'];
            $class = strtolower($difficulty);
            ?>
            <span class='badge <?php echo $class; ?>'>
                <?php echo htmlspecialchars($difficulty); ?>
            </span>
        </td>

        <td>
            <div class='actions'>

                <a href='view_question.php?id=<?php echo $row['id']; ?>'>
                    <button type="button" class="icon-btn view-btn">
                        <i class='fa-regular fa-eye'></i>
                    </button>
                </a>

                <a href='edit_question.php?id=<?php echo $row['id']; ?>'>
                    <button type="button" class="icon-btn edit-btn">
                        <i class='fa-regular fa-pen-to-square'></i>
                    </button>
                </a>

                <a href='delete_question.php?id=<?php echo $row['id']; ?>'
                   onclick='return confirm("Delete this question?");'>
                    <button type="button" class="icon-btn delete-btn">
                        <i class='fa-regular fa-trash-can'></i>
                    </button>
                </a>

            </div>
        </td>

    </tr>

    <?php } ?>

<?php } else { ?>

<tr>
    <td colspan='5' style='text-align:center; padding:30px;'>
        No questions found.
    </td>
</tr>

<?php } ?>

                </table>

            </div>

        </div>

    </main>

</body>
</html>
