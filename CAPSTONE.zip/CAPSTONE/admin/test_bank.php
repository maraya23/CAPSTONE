<?php

session_start();

if (!isset($_SESSION['admin_id'])) {

    header('Location: /CAPSTONE/login.php');
    exit();

}


if ($_SESSION['usertype'] != 'admin') {

    header('Location: ../user.php');
    exit();

}


include '../connection.php';



// ==============================
// FILTERS
// ==============================

$search = isset($_GET['search']) 
? trim($_GET['search']) 
: '';

$category = isset($_GET['category']) 
? trim($_GET['category']) 
: '';




// ==============================
// GET QUESTIONS
// ==============================


$sql = "

SELECT

q.question_id,

q.question,

c.category_name,

q.difficulty


FROM questions q


INNER JOIN categories c

ON q.category_id = c.category_id


WHERE 1=1

";


$params = [];

$types = "";




if($search != ""){


    $sql .= " AND q.question LIKE ? ";


    $params[] = "%".$search."%";


    $types .= "s";


}





if($category != ""){


    $sql .= " AND c.category_name = ? ";


    $params[] = $category;


    $types .= "s";


}




$sql .= "

ORDER BY q.question_id DESC

";






$stmt = mysqli_prepare($conn,$sql);



if(!$stmt){

    die("SQL Error: ".mysqli_error($conn));

}





if(!empty($params)){


    mysqli_stmt_bind_param(

        $stmt,

        $types,

        ...$params

    );


}





mysqli_stmt_execute($stmt);



$result = mysqli_stmt_get_result($stmt);




if(!$result){

    die("Query Error: ".mysqli_error($conn));

}







// ==============================
// GET CATEGORIES
// ==============================


$categories = mysqli_query(

$conn,

"

SELECT category_name

FROM categories

WHERE status='Active'

ORDER BY category_name ASC

"

);


?>
<!DOCTYPE html>
<html lang='en'>
<head>
<meta charset='UTF-8'>
<meta name='viewport' content='width=device-width, initial-scale=1.0'>
<title>Admin - Test Bank</title>

<link rel='stylesheet'
href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css'>

<style>

*{
    box-sizing:border-box;
}

body{
    margin:0;
    font-family:'Poppins',sans-serif;
    background:#edf2fb;
}

/* Main */

.main{
    margin-left:230px;
    width:calc(100% - 230px);
    min-height:100vh;
    padding:30px;
    box-sizing:border-box;
    overflow-x:auto;
}

.page-title{
    font-size:30px;
    font-weight:600;
    color:#111827;
    margin-bottom:25px;
}

/* Card */

.card{
    background:#fff;
    border-radius:18px;
    padding:28px;
    box-shadow:0 4px 18px rgba(0,0,0,.08);
}

/* Header */

.card-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:15px;
    margin-bottom:25px;
    flex-wrap:wrap;
}

.card-header h2{
    margin:0;
    font-size:22px;
    font-weight:600;
}

/* Controls */

.controls{
    display:flex;
    align-items:center;
    gap:15px;
    flex-wrap:wrap;
    margin-bottom:25px;
}

.search-box{
    position:relative;
    flex:1;
    min-width:320px;
    max-width:520px;
}

.search-box i{
    position:absolute;
    left:15px;
    top:50%;
    transform:translateY(-50%);
    color:#9ca3af;
}

.search-box input{
    width:100%;
    height:48px;
    padding:0 45px;
    border:1px solid #d1d5db;
    border-radius:12px;
    font-size:14px;
    font-family:'Poppins',sans-serif;
    background:#fff;
    transition:.25s;
}

.search-box input:focus{
    outline:none;
    border-color:#2563eb;
    box-shadow:0 0 0 4px rgba(37,99,235,.15);
}

.controls select{
    width:240px;
    height:48px;
    padding:0 15px;
    border:1px solid #d1d5db;
    border-radius:12px;
    font-family:'Poppins',sans-serif;
}

.controls select:focus{
    outline:none;
    border-color:#2563eb;
    box-shadow:0 0 0 4px rgba(37,99,235,.15);
}

select,
input[type=text]{
    padding:11px 14px;
    border:1px solid #d1d5db;
    border-radius:10px;
    font-size:14px;
    font-family:'Poppins',sans-serif;
}

select{
    min-width:180px;
}

input[type=text]{
    min-width:300px;
}

/* Buttons */

.btn{
    border:none;
    border-radius:10px;
    padding:11px 18px;
    cursor:pointer;
    color:#fff;
    font-size:14px;
    font-weight:600;
    font-family:'Poppins',sans-serif;
    transition:.25s;
}

.btn:hover{
    transform:translateY(-2px);
}

.btn-blue{
    background:#2563eb;
}

.btn-blue:hover{
    background:#1d4ed8;
}

.btn-red{
    background:#dc2626;
}

.btn-red:hover{
    background:#b91c1c;
}

.icon-btn{

    width:38px;
    height:38px;

    display:flex;
    justify-content:center;
    align-items:center;

    border:none;
    border-radius:10px;

    text-decoration:none;

    cursor:pointer;

    color:#fff;

    transition:.25s;

}

.view-btn{
    background:#2563eb;
}

.edit-btn{
    background:#16a34a;
}

.delete-btn{
    background:#dc2626;
}

.view-btn:hover{
    background:#1d4ed8;
}

.edit-btn:hover{
    background:#15803d;
}

.delete-btn:hover{
    background:#b91c1c;
}

.icon-btn:hover{
    background:#e5e7eb;
    transform:scale(1.05);
}

.icon-btn:hover{
    background:#e5e7eb;
}

/* Table */

.table-container{
    overflow-x:auto;
}

table{
    width:100%;
    border-collapse:collapse;
}

th{
    text-align:left;
    padding:14px;
    background:#2563eb;
    color:#fff;
    font-size:14px;
}

td{
    padding:14px;
    border-top:1px solid #e5e7eb;
    vertical-align:top;
    font-size:14px;
}

.actions{
    display:flex;
    gap:8px;
}

/* Difficulty badges */

.badge{
    display:inline-block;
    padding:6px 12px;
    border-radius:999px;
    font-size:12px;
    font-weight:bold;
}

.easy{
    background:#dcfce7;
    color:#166534;
}

.medium{
    background:#fef3c7;
    color:#92400e;
}

.hard{
    background:#fee2e2;
    color:#991b1b;
}

    @media (max-width:768px){

.main{
    margin-left:0;
    width:100%;
    padding:85px 15px 20px;
}

.controls{
    flex-direction:column;
    align-items:stretch;
}

.search-box{
    flex:1;
    min-width:320px;
    max-width:520px;
}

.search-box input{
    width:100%;
    height:48px;
    padding:0 15px;
    border:1px solid #d1d5db;
    border-radius:12px;
    background:#fff;
    font-size:14px;
    font-family:'Poppins',sans-serif;
    box-sizing:border-box;
    transition:.25s;
}

.search-box input:focus{
    outline:none;
    border-color:#2563eb;
    box-shadow:0 0 0 4px rgba(37,99,235,.15);
}

.controls select{
    width:100%;
}

.btn{
    width:100%;
}

.table-container{
    overflow-x:auto;
}

table{
    min-width:950px;
}

.page-title{
    font-size:26px;
}
        
        .card-header{
    flex-direction:column;
    align-items:stretch;
}

.card-header .btn{
    width:100%;
}

}
    
</style>
</head>

<body>

   <?php include 'admin_sidebar.php'; ?>

    <!-- Main -->
    <main class='main'>

        <div class="page-title">
    Test Banking
</div>

<p style="margin-top:-12px;margin-bottom:25px;color:#6b7280;font-size:15px;">
    Manage and organize all examination questions.
</p>
        <div class='card'>

          <div class="card-header">

    <h2>Test Bank</h2>

    <a href="add_question.php" style="text-decoration:none;">

        <button type="button" class="btn btn-blue">

            <i class="fa-solid fa-plus"></i>

            Add Question

        </button>

    </a>

</div>

            <form method="GET" class="controls">

<div class="search-box">

    <input
        type="text"
        name="search"
        placeholder="Search questions..."
        value="<?php echo htmlspecialchars($search); ?>">

</div>

<select name="category">

<option value="">All Categories</option>

<?php

while($cat = mysqli_fetch_assoc($categories)){

?>

<option value="<?php echo $cat['category_name']; ?>"

<?php

if($category == $cat['category_name']){

echo "selected";

}

?>

>

<?php echo $cat['category_name']; ?>

</option>


<?php

}

?>
</select>

<button class="btn btn-blue" type="submit">
<i class="fa-solid fa-search"></i>
Search
</button>

<?php if($search!="" || $category!=""){ ?>

<a href="test_bank.php"
class="btn btn-blue"
style="text-decoration:none;display:flex;align-items:center;justify-content:center;gap:8px;">

<i class="fa-solid fa-xmark"></i>

Clear

</a>

<?php } ?>

</form>

            <div class='table-container'>

                <table>

                    <tr>
                        <th width='70'>ID</th>
                        <th>Question</th>
                        <th width='220'>Category</th>
                        <th width='120'>Difficulty</th>
                        <th width='120'>Action</th>
                    </tr>

                 <?php if(mysqli_num_rows($result) > 0){ ?>

    <?php while($row = mysqli_fetch_assoc($result)){ ?>

    <tr>

       <td>
<?php echo $row['question_id']; ?>
</td>

        <td><?php echo htmlspecialchars($row['question']); ?></td>

       <td>
<?php echo htmlspecialchars($row['category_name']); ?>
</td>

        <td>
            <?php
            $difficulty = $row['difficulty'];
            $class = strtolower($difficulty);
            ?>
            <span class='badge <?php echo $class; ?>'>
                <?php echo htmlspecialchars($difficulty); ?>
            </span>
        </td>

        <td>
           <div class="actions">

<a href="view_question.php?id=<?php echo $row['question_id']; ?>"
class="icon-btn view-btn">

<i class="fa-regular fa-eye"></i>

</a>

<a href="edit_question.php?id=<?php echo $row['question_id']; ?>"
class="icon-btn edit-btn">

<i class="fa-regular fa-pen-to-square"></i>

</a>

<a href="delete_question.php?id=<?php echo $row['question_id']; ?>"
class="icon-btn delete-btn"
onclick="return confirm('Delete this question?');">

<i class="fa-regular fa-trash-can"></i>

</a>

</div>
        </td>

    </tr>

    <?php } ?>

<?php } else { ?>

<tr>
    <td colspan='5' style='text-align:center; padding:30px;'>
        No questions found.
    </td>
</tr>

<?php } ?>

                </table>

            </div>

        </div>

    </main>

</body>
</html>
