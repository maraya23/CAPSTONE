<?php

session_start();

require_once "../connection.php";

// ===============================
// ADMIN LOGIN CHECK
// ===============================

if(!isset($_SESSION['admin_id'])){
    header("Location: ../login.php");
    exit();
}

if($_SESSION['usertype'] != "admin"){
    header("Location: ../user.php");
    exit();
}

// ===============================
// CHECK ANNOUNCEMENT ID
// ===============================

if(!isset($_GET['id'])){
    header("Location: announcement_management.php");
    exit();
}

$announcement_id = intval($_GET['id']);

// ===============================
// LOAD ANNOUNCEMENT
// ===============================

$stmt = mysqli_prepare(
    $conn,
    "SELECT * FROM announcements WHERE announcement_id=?"
);

mysqli_stmt_bind_param(
    $stmt,
    "i",
    $announcement_id
);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

if(mysqli_num_rows($result)==0){
    die("Announcement not found.");
}

$announcement = mysqli_fetch_assoc($result);

// ===============================
// UPDATE ANNOUNCEMENT
// ===============================

if(isset($_POST['update'])){

    $title = trim($_POST['title']);
    $content = trim($_POST['content']);
    $status = $_POST['status'];

    $update = mysqli_prepare(
        $conn,
        "UPDATE announcements
         SET title=?,
             content=?,
             status=?
         WHERE announcement_id=?"
    );

    mysqli_stmt_bind_param(
        $update,
        "sssi",
        $title,
        $content,
        $status,
        $announcement_id
    );

    if(mysqli_stmt_execute($update)){

        header("Location: announcement_management.php?success=updated");
        exit();

    }else{

        $error = "Failed to update announcement.";

    }

}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Edit Announcement</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    background:#f3f5fb;
}

/* =========================
MAIN
========================= */

.main{
    margin-left:230px;
    width:calc(100% - 230px);
    min-height:100vh;
    padding:30px;
}

/* =========================
PAGE HEADER
========================= */

.page-header{
    background:#fff;
    border-radius:18px;
    padding:25px;
    margin-bottom:25px;
    box-shadow:0 4px 15px rgba(0,0,0,.08);
    display:flex;
    justify-content:space-between;
    align-items:center;
    flex-wrap:wrap;
    gap:15px;
}

.page-header h1{
    font-size:30px;
    color:#111827;
}

.page-header p{
    color:#6b7280;
    margin-top:5px;
}

/* =========================
CARD
========================= */

.card{
    background:#fff;
    border-radius:18px;
    box-shadow:0 4px 15px rgba(0,0,0,.08);
    overflow:hidden;
}

.card-header{
    padding:22px 25px;
    border-bottom:1px solid #e5e7eb;
}

.card-header h2{
    font-size:24px;
    color:#111827;
}

/* =========================
FORM
========================= */

.form-body{
    padding:25px;
}

.form-group{
    margin-bottom:20px;
}

.form-group label{
    display:block;
    margin-bottom:8px;
    font-weight:600;
    color:#374151;
}

.form-group input,
.form-group textarea,
.form-group select{
    width:100%;
    border:1px solid #d1d5db;
    border-radius:10px;
    padding:12px 15px;
    font-size:14px;
}

.form-group input,
.form-group select{
    height:48px;
}

.form-group textarea{
    resize:vertical;
    min-height:180px;
}

/* =========================
BUTTONS
========================= */

.form-footer{
    border-top:1px solid #e5e7eb;
    padding:22px 25px;
    display:flex;
    justify-content:flex-end;
    gap:12px;
    flex-wrap:wrap;
}

.btn{
    border:none;
    border-radius:10px;
    padding:12px 18px;
    cursor:pointer;
    font-size:14px;
    font-weight:600;
    text-decoration:none;
    transition:.25s;
    display:inline-flex;
    align-items:center;
    gap:8px;
}

.btn:hover{
    transform:translateY(-2px);
}

.btn-blue{
    background:#2563eb;
    color:#fff;
}

.btn-blue:hover{
    background:#1d4ed8;
}

.btn-outline{
    background:#fff;
    color:#374151;
    border:1px solid #d1d5db;
}

/* =========================
ERROR
========================= */

.error{
    margin:20px 25px 0;
    background:#fee2e2;
    color:#991b1b;
    padding:15px;
    border-radius:10px;
}

/* =========================
RESPONSIVE
========================= */

@media(max-width:992px){

.main{
    margin-left:0;
    width:100%;
    padding:85px 20px 20px;
}

}

@media(max-width:768px){

.page-header{
    flex-direction:column;
    align-items:flex-start;
}

.form-footer{
    flex-direction:column;
}

.form-footer .btn{
    width:100%;
    justify-content:center;
}

}

</style>

</head>

<body>

<?php include "admin_sidebar.php"; ?>

<main class="main">
    
    <!-- =========================
PAGE HEADER
========================= -->

<div class="page-header">

    <div>
        <h1>Edit Announcement</h1>
        <p>Update an existing announcement.</p>
    </div>

    <a href="announcement_management.php" class="btn btn-outline">
        <i class="fa-solid fa-arrow-left"></i>
        Back
    </a>

</div>


<!-- =========================
EDIT FORM
========================= -->

<div class="card">

    <div class="card-header">
        <h2>
            <i class="fa-solid fa-pen-to-square"></i>
            Announcement Details
        </h2>
    </div>

    <?php if(isset($error)){ ?>

        <div class="error">

            <?php echo htmlspecialchars($error); ?>

        </div>

    <?php } ?>

    <form method="POST">

        <div class="form-body">

            <!-- Title -->

            <div class="form-group">

                <label>Announcement Title</label>

                <input
                    type="text"
                    name="title"
                    required
                    maxlength="255"
                    value="<?php echo htmlspecialchars($announcement['title']); ?>">

            </div>

            <!-- Content -->

            <div class="form-group">

                <label>Announcement Content</label>

                <textarea
                    name="content"
                    required><?php echo htmlspecialchars($announcement['content']); ?></textarea>

            </div>

            <!-- Status -->

            <div class="form-group">

                <label>Status</label>

                <select name="status" required>

                    <option value="Visible"
                        <?php if($announcement['status']=="Visible") echo "selected"; ?>>
                        Visible
                    </option>

                    <option value="Hidden"
                        <?php if($announcement['status']=="Hidden") echo "selected"; ?>>
                        Hidden
                    </option>

                </select>

            </div>

        </div>

        <div class="form-footer">

            <a href="announcement_management.php" class="btn btn-outline">
                <i class="fa-solid fa-xmark"></i>
                Cancel
            </a>

            <button
                type="submit"
                name="update"
                class="btn btn-blue">

                <i class="fa-solid fa-floppy-disk"></i>

                Save Changes

            </button>

        </div>

    </form>

</div>

</main>

</body>
</html>