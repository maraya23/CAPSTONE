<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

if ($_SESSION['usertype'] != "admin") {
    header("Location: ../user.php");
    exit();
}

include "../connection.php";

if (!isset($_GET['id'])) {
    header("Location: test_bank.php");
    exit();
}

$question_id = (int)$_GET['id'];



/*==============================
LOAD QUESTION
==============================*/

$stmt = mysqli_prepare(

$conn,

"SELECT * FROM questions WHERE question_id=?"

);

mysqli_stmt_bind_param($stmt,"i",$question_id);

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

if(mysqli_num_rows($result)==0){

    header("Location:test_bank.php");
    exit();

}

$row = mysqli_fetch_assoc($result);



/*==============================
UPDATE QUESTION
==============================*/

$success="";
$error="";

if($_SERVER["REQUEST_METHOD"]=="POST"){

    $category_id=(int)$_POST["category_id"];

    $question=trim($_POST["question"]);

    $option_a=trim($_POST["option_a"]);

    $option_b=trim($_POST["option_b"]);

    $option_c=trim($_POST["option_c"]);

    $option_d=trim($_POST["option_d"]);

    $correct_answer=$_POST["correct_answer"];

    $difficulty=$_POST["difficulty"];

    $status=$_POST["status"];

    $rationale=trim($_POST["rationale"]);


    $stmt=mysqli_prepare(

    $conn,

    "UPDATE questions

    SET

    category_id=?,

    question=?,

    option_a=?,

    option_b=?,

    option_c=?,

    option_d=?,

    correct_answer=?,

    rationale=?,

    difficulty=?,

    status=?

    WHERE question_id=?"

    );



    mysqli_stmt_bind_param(

    $stmt,

    "isssssssssi",

    $category_id,

    $question,

    $option_a,

    $option_b,

    $option_c,

    $option_d,

    $correct_answer,

    $rationale,

    $difficulty,

    $status,

    $question_id

    );



    if(mysqli_stmt_execute($stmt)){

        $success="Question updated successfully.";

        header("Refresh:1; url=test_bank.php");

    }

    else{

        $error="Unable to update question.";

    }

}
?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Edit Question | e-Nurse</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{
    font-family:'Poppins',sans-serif;
    background:#edf2fb;
}

.main{

    margin-left:230px;
    width:calc(100% - 230px);
    min-height:100vh;
    padding:30px;

}

.page-title{

    font-size:30px;
    font-weight:600;
    color:#111827;

}

.page-subtitle{

    margin-top:6px;
    margin-bottom:25px;
    color:#6b7280;
    font-size:15px;

}

.card{

    background:#fff;
    border-radius:18px;
    padding:30px;
    box-shadow:0 5px 18px rgba(0,0,0,.08);

}

.form-group{

    margin-bottom:22px;

}

.form-group label{

    display:block;
    margin-bottom:8px;
    font-weight:600;

}

.grid-2{

    display:grid;
    grid-template-columns:repeat(2,1fr);
    gap:20px;

}

input,
textarea,
select{

    width:100%;
    padding:14px;
    border:1px solid #d1d5db;
    border-radius:12px;
    font-family:Poppins;
    font-size:14px;

}

textarea{

    min-height:130px;
    resize:vertical;

}

input:focus,
textarea:focus,
select:focus{

    outline:none;
    border-color:#2563eb;
    box-shadow:0 0 0 4px rgba(37,99,235,.15);

}

.success{

    background:#dcfce7;
    color:#166534;
    padding:14px;
    border-radius:10px;
    margin-bottom:20px;

}

.error{

    background:#fee2e2;
    color:#991b1b;
    padding:14px;
    border-radius:10px;
    margin-bottom:20px;

}

.button-group{

    display:flex;
    gap:12px;
    margin-top:30px;

}

.btn{

    border:none;
    border-radius:10px;
    padding:13px 22px;
    cursor:pointer;
    font-weight:600;
    font-family:Poppins;
    transition:.25s;

}

.btn:hover{

    transform:translateY(-2px);

}

.btn-blue{

    background:#2563eb;
    color:#fff;

}

.btn-blue:hover{

    background:#1d4ed8;

}

.btn-gray{

    background:#e5e7eb;
    color:#111827;

}

.btn-gray:hover{

    background:#d1d5db;

}

@media(max-width:768px){

.main{

    margin-left:0;
    width:100%;
    padding:85px 15px 20px;

}

.grid-2{

    grid-template-columns:1fr;

}

.button-group{

    flex-direction:column;

}

.btn{

    width:100%;

}

.page-title{

    font-size:26px;

}

}

</style>

</head>

<body>

<?php include 'admin_sidebar.php'; ?>

<main class="main">

<h1 class="page-title">

Edit Question

</h1>

<p class="page-subtitle">

Update an existing examination question.

</p>

<div class="card">

<?php if($success!=""){ ?>

<div class="success">

<?php echo $success; ?>

</div>

<?php } ?>

<?php if($error!=""){ ?>

<div class="error">

<?php echo $error; ?>

</div>

<?php } ?>

<form method="POST">
    
    <!-- Category -->

<div class="form-group">

<label>Category</label>

<select name="category_id" required>

<?php

$categories = mysqli_query(
$conn,
"SELECT * FROM categories
WHERE status='Active'
ORDER BY category_name ASC"
);

while($cat = mysqli_fetch_assoc($categories)){

?>

<option
value="<?php echo $cat['category_id']; ?>"

<?php
if($row['category_id']==$cat['category_id']){
    echo "selected";
}
?>

>

<?php echo htmlspecialchars($cat['category_name']); ?>

</option>

<?php } ?>

</select>

</div>



<!-- Question -->

<div class="form-group">

<label>Question</label>

<textarea
name="question"
required><?php echo htmlspecialchars($row['question']); ?></textarea>

</div>



<!-- Choices -->

<div class="grid-2">

<div class="form-group">

<label>Option A</label>

<input
type="text"
name="option_a"
value="<?php echo htmlspecialchars($row['option_a']); ?>"
required>

</div>



<div class="form-group">

<label>Option B</label>

<input
type="text"
name="option_b"
value="<?php echo htmlspecialchars($row['option_b']); ?>"
required>

</div>



<div class="form-group">

<label>Option C</label>

<input
type="text"
name="option_c"
value="<?php echo htmlspecialchars($row['option_c']); ?>"
required>

</div>



<div class="form-group">

<label>Option D</label>

<input
type="text"
name="option_d"
value="<?php echo htmlspecialchars($row['option_d']); ?>"
required>

</div>

</div>



<!-- Correct Answer + Difficulty -->

<div class="grid-2">

<div class="form-group">

<label>Correct Answer</label>

<select name="correct_answer" required>

<option value="A" <?php if($row['correct_answer']=="A") echo "selected"; ?>>Option A</option>

<option value="B" <?php if($row['correct_answer']=="B") echo "selected"; ?>>Option B</option>

<option value="C" <?php if($row['correct_answer']=="C") echo "selected"; ?>>Option C</option>

<option value="D" <?php if($row['correct_answer']=="D") echo "selected"; ?>>Option D</option>

</select>

</div>



<div class="form-group">

<label>Difficulty</label>

<select name="difficulty">

<option value="Easy"
<?php if($row['difficulty']=="Easy") echo "selected"; ?>>
Easy
</option>

<option value="Medium"
<?php if($row['difficulty']=="Medium") echo "selected"; ?>>
Medium
</option>

<option value="Hard"
<?php if($row['difficulty']=="Hard") echo "selected"; ?>>
Hard
</option>

</select>

</div>

</div>



<!-- Status -->

<div class="form-group">

<label>Status</label>

<select name="status">

<option value="Active"
<?php if($row['status']=="Active") echo "selected"; ?>>
Active
</option>

<option value="Inactive"
<?php if($row['status']=="Inactive") echo "selected"; ?>>
Inactive
</option>

</select>

</div>



<!-- Rationale -->

<div class="form-group">

<label>Rationale</label>

<textarea
name="rationale"><?php echo htmlspecialchars($row['rationale']); ?></textarea>

</div>



<!-- Buttons -->

<div class="button-group">

<button
type="submit"
class="btn btn-blue">

<i class="fa-solid fa-floppy-disk"></i>

Update Question

</button>



<a href="test_bank.php">

<button
type="button"
class="btn btn-gray">

Cancel

</button>

</a>

</div>

</form>

</div>

</main>

</body>

</html>