<?php

session_start();

require_once "../connection.php";

if (!isset($_SESSION['admin_id']) || strtolower($_SESSION['usertype']) != "admin") {
    header("Location: ../login.php");
    exit();
}

if (!isset($_POST['create'])) {
    header("Location: create_user.php");
    exit();
}

$firstname = trim($_POST['firstname']);
$middlename = trim($_POST['middlename']);
$surname = trim($_POST['surname']);
$email = trim($_POST['email']);
$username = trim($_POST['username']);
$password = $_POST['password'];
$confirm_password = $_POST['confirm_password'];
$usertype = trim($_POST['usertype']);
if (isset($_POST['create'])) {

    $firstname = trim($_POST['firstname']);
    $middlename = trim($_POST['middlename']);
    $surname = trim($_POST['surname']);
    $email = trim($_POST['email']);
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    
    // Check if same firstname and surname already exists
$checkName = "SELECT ID FROM logintbl WHERE firstname = ? AND surname = ?";

$stmt = mysqli_prepare($conn, $checkName);

mysqli_stmt_bind_param(
    $stmt,
    "ss",
    $firstname,
    $surname
);

mysqli_stmt_execute($stmt);

mysqli_stmt_store_result($stmt);


if (mysqli_stmt_num_rows($stmt) > 0) {

    mysqli_stmt_close($stmt);

    header("Location: create_user.php?error=name");

    exit();

}


mysqli_stmt_close($stmt);
    
// Password must contain at least 8 characters
if (strlen($password) < 8) {
    header("Location: create_user.php?error=password");
    exit();
}

// Passwords must match
if ($password !== $confirm_password) {
    header("Location: create_user.php?error=confirm");
    exit();
}
    $usertype = $_POST['usertype'];

    // Check if username already exists
    $checkUsername = "SELECT ID FROM logintbl WHERE username = ?";
    $stmt = mysqli_prepare($conn, $checkUsername);
    mysqli_stmt_bind_param($stmt, "s", $username);
    mysqli_stmt_execute($stmt);
    mysqli_stmt_store_result($stmt);

    if (mysqli_stmt_num_rows($stmt) > 0) {
       header("Location: create_user.php?error=username");
exit();
    }

    mysqli_stmt_close($stmt);

    // Check if email already exists
    // Only check duplicate email if an email was entered
if (!empty($email)) {

    $checkEmail = "SELECT ID FROM logintbl WHERE email = ?";

    $stmt = mysqli_prepare($conn, $checkEmail);

    mysqli_stmt_bind_param($stmt, "s", $email);

    mysqli_stmt_execute($stmt);

    mysqli_stmt_store_result($stmt);

    if (mysqli_stmt_num_rows($stmt) > 0) {

       header("Location: create_user.php?error=email");
exit();

    }

    mysqli_stmt_close($stmt);

}

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Save the new user
    $sql = "INSERT INTO logintbl
            (firstname, middlename, surname, email, username, password, usertype)
            VALUES (?, ?, ?, ?, ?, ?, ?)";

    $stmt = mysqli_prepare($conn, $sql);

    mysqli_stmt_bind_param(
        $stmt,
        "sssssss",
        $firstname,
        $middlename,
        $surname,
        $email,
        $username,
        $hashedPassword,
        $usertype
    );

    if (mysqli_stmt_execute($stmt)) {

    mysqli_stmt_close($stmt);
    mysqli_close($conn);

    header("Location: create_user.php?success=1");
    exit();

} else {

    die(
        "<h2>Database Error</h2>" .
        "<strong>Error Number:</strong> " . mysqli_errno($conn) . "<br>" .
        "<strong>Error:</strong> " . mysqli_stmt_error($stmt)
    );

}

} else {

    header("Location: create_user.php");
    exit();

}

?>