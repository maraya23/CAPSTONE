<?php

session_start();
require_once "../connection.php";

// ======================================
// ADMIN LOGIN CHECK
// ======================================

if (!isset($_SESSION['admin_id'])) {
    header("Location: ../login.php");
    exit();
}

if ($_SESSION['usertype'] != "admin") {
    header("Location: ../user.php");
    exit();
}

$admin_id = $_SESSION['admin_id'];

// ======================================
// SUCCESS MESSAGE
// ======================================

$message = "";

if (isset($_GET['success'])) {

    switch ($_GET['success']) {

        case "added":
            $message = "Announcement published successfully.";
            break;

        case "updated":
            $message = "Announcement updated successfully.";
            break;

        case "deleted":
            $message = "Announcement deleted successfully.";
            break;

        case "status":
            $message = "Announcement status updated successfully.";
            break;
    }
}

// ======================================
// ADD ANNOUNCEMENT
// ======================================

if (isset($_POST['add_announcement'])) {

    $title = trim($_POST['title']);
    $content = trim($_POST['content']);

    $stmt = mysqli_prepare(
        $conn,
        "INSERT INTO announcements
        (
            title,
            content,
            posted_by
        )
        VALUES
        (?,?,?)"
    );

    mysqli_stmt_bind_param(
        $stmt,
        "ssi",
        $title,
        $content,
        $admin_id
    );

    mysqli_stmt_execute($stmt);

    header("Location: announcement_management.php?success=added");
    exit();
}

// ======================================
// TOGGLE STATUS
// ======================================

if (isset($_GET['toggle'])) {

    $id = (int) $_GET['toggle'];

    $stmt = mysqli_prepare(
        $conn,
        "UPDATE announcements
         SET status =
         IF(status='Visible','Hidden','Visible')
         WHERE announcement_id=?"
    );

    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);

    header("Location: announcement_management.php?success=status");
    exit();
}

// ======================================
// DELETE ANNOUNCEMENT
// ======================================

if (isset($_GET['delete'])) {

    $id = (int) $_GET['delete'];

    $stmt = mysqli_prepare(
        $conn,
        "DELETE FROM announcements
         WHERE announcement_id=?"
    );

    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);

    header("Location: announcement_management.php?success=deleted");
    exit();
}

// ======================================
// LOAD ANNOUNCEMENTS
// ======================================

$announcements = mysqli_query(
    $conn,
    "
    SELECT

        a.announcement_id,
        a.title,
        a.content,
        a.status,
        a.created_at,

        CONCAT(
            u.firstname,
            ' ',
            u.surname
        ) AS poster

    FROM announcements a

    INNER JOIN logintbl u
        ON a.posted_by = u.id

    ORDER BY a.created_at DESC
"
);

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Announcement Management</title>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    background:#edf2fb;
}

/* ===========================
MAIN
=========================== */

.main{
    margin-left:230px;
    width:calc(100% - 230px);
    min-height:100vh;
    padding:30px;
}

/* ===========================
PAGE HEADER
=========================== */

.page-header{
    display:flex;
    justify-content:space-between;
    align-items:center;
    flex-wrap:wrap;
    gap:15px;
    margin-bottom:25px;
}

.page-header h1{
    font-size:32px;
    color:#111827;
}

.page-header p{
    color:#6b7280;
    margin-top:5px;
}

/* ===========================
BUTTONS
=========================== */

.btn{
    border:none;
    border-radius:10px;
    padding:12px 18px;
    cursor:pointer;
    font-size:14px;
    font-weight:600;
    text-decoration:none;
    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:8px;
    transition:.25s;
}

.btn:hover{
    transform:translateY(-2px);
}

.btn-blue{
    background:#2563eb;
    color:#fff;
}

.btn-green{
    background:#16a34a;
    color:#fff;
}

.btn-orange{
    background:#f97316;
    color:#fff;
}

.btn-outline{
    background:#fff;
    color:#111827;
    border:1px solid #d1d5db;
}

/* ===========================
SUCCESS ALERT
=========================== */

.alert{
    background:#dcfce7;
    color:#166534;
    padding:14px 18px;
    border-radius:12px;
    margin-bottom:20px;
    font-size:14px;
    border-left:5px solid #16a34a;
}

/* ===========================
CARD
=========================== */

.card{
    background:#fff;
    border-radius:18px;
    overflow:hidden;
    box-shadow:0 4px 15px rgba(0,0,0,.08);
    margin-bottom:25px;
}

.card-header{
    padding:22px 24px;
    border-bottom:1px solid #e5e7eb;
}

.card-header h2{
    font-size:24px;
    color:#111827;
}

/* ===========================
FORM
=========================== */

.form-body{
    padding:24px;
}

.form-group{
    margin-bottom:20px;
}

.form-group label{
    display:block;
    margin-bottom:8px;
    font-weight:600;
    color:#374151;
}

.form-group input,
.form-group textarea{
    width:100%;
    border:1px solid #d1d5db;
    border-radius:10px;
    padding:12px 15px;
    font-size:14px;
}

.form-group textarea{
    resize:vertical;
    min-height:130px;
}

/* ===========================
TABLE
=========================== */

.table-wrapper{
    overflow-x:auto;
}

table{
    width:100%;
    border-collapse:collapse;
}

th{
    background:#2563eb;
    color:#fff;
    padding:14px;
    text-align:left;
    white-space:nowrap;
}

td{
    padding:14px;
    border-top:1px solid #e5e7eb;
    vertical-align:top;
}

/* ===========================
STATUS BADGES
=========================== */

.badge{
    display:inline-block;
    padding:6px 12px;
    border-radius:999px;
    font-size:12px;
    font-weight:600;
}

.visible{
    background:#dcfce7;
    color:#166534;
}

.hidden{
    background:#fee2e2;
    color:#991b1b;
}

/* ===========================
ACTION BUTTONS
=========================== */

.action-buttons{
    display:flex;
    gap:8px;
}

.action{
    width:38px;
    height:38px;
    border:none;
    border-radius:10px;
    color:#fff;
    cursor:pointer;
}

.edit{
    background:#2563eb;
}

.toggle{
    background:#f59e0b;
}

.delete{
    background:#dc2626;
}

/* ===========================
RESPONSIVE
=========================== */

@media(max-width:992px){

.main{
    margin-left:0;
    width:100%;
    padding:85px 20px 20px;
}

}

@media(max-width:768px){

.page-header{
    flex-direction:column;
    align-items:flex-start;
}

.page-header .btn{
    width:100%;
}

.action-buttons{
    flex-wrap:wrap;
}

table{
    min-width:950px;
}

}

</style>

</head>

<body>

<?php include "admin_sidebar.php"; ?>

<main class="main">
    
    <!-- =========================
PAGE HEADER
========================= -->

<div class="page-header">

    <div>
        <h1>
            <i class="fa-solid fa-bullhorn"></i>
            Announcement Management
        </h1>

        <p>
            Create, edit and manage announcements for all users.
        </p>
    </div>

    <a href="admin_dashboard.php" class="btn btn-orange">
        <i class="fa-solid fa-arrow-left"></i>
        Dashboard
    </a>

</div>

<?php if($message!=""){ ?>

<div class="alert">
    <i class="fa-solid fa-circle-check"></i>
    <?php echo $message; ?>
</div>

<?php } ?>



<!-- =========================
CREATE ANNOUNCEMENT
========================= -->

<div class="card">

    <div class="card-header">
        <h2>
            <i class="fa-solid fa-plus"></i>
            Create Announcement
        </h2>
    </div>

    <div class="form-body">

        <form method="POST">

            <div class="form-group">

                <label>
                    Announcement Title
                </label>

                <input
                    type="text"
                    name="title"
                    required
                    maxlength="255"
                    placeholder="Enter announcement title">

            </div>

            <div class="form-group">

                <label>
                    Announcement Content
                </label>

                <textarea
                    name="content"
                    required
                    placeholder="Write your announcement here..."></textarea>

            </div>

            <button
                type="submit"
                name="add_announcement"
                class="btn btn-blue">

                <i class="fa-solid fa-paper-plane"></i>

                Publish Announcement

            </button>

        </form>

    </div>

</div>



<!-- =========================
ANNOUNCEMENT LIST
========================= -->

<div class="card">

    <div class="card-header">

        <h2>

            <i class="fa-solid fa-list"></i>

            Announcement List

        </h2>

    </div>

    <div class="table-wrapper">

        <table>

            <thead>

                <tr>

                    <th width="220">
                        Title
                    </th>

                    <th>
                        Announcement
                    </th>

                    <th width="170">
                        Posted By
                    </th>

                    <th width="170">
                        Date
                    </th>

                    <th width="110">
                        Status
                    </th>

                    <th width="170">
                        Action
                    </th>

                </tr>

            </thead>

            <tbody>

<?php

if(mysqli_num_rows($announcements)>0){

while($row=mysqli_fetch_assoc($announcements)){

$statusClass = strtolower($row['status']);

?>

<tr>

<td>

<strong>

<?php echo htmlspecialchars($row['title']); ?>

</strong>

</td>

<td>

<?php

if(strlen($row['content'])>120){

echo htmlspecialchars(substr($row['content'],0,120))."...";

}else{

echo htmlspecialchars($row['content']);

}

?>

</td>

<td>

<?php echo htmlspecialchars($row['poster']); ?>

</td>

<td>

<?php

echo date(

"M d, Y h:i A",

strtotime($row['created_at'])

);

?>

</td>

<td>

<span class="badge <?php echo $statusClass; ?>">

<?php echo $row['status']; ?>

</span>

</td>

<td>

<div class="action-buttons">

<a href="edit_announcement.php?id=<?php echo $row['announcement_id']; ?>">

<button
type="button"
class="action edit"
title="Edit">

<i class="fa-solid fa-pen"></i>

</button>

</a>

<a href="announcement_management.php?toggle=<?php echo $row['announcement_id']; ?>">

<button
type="button"
class="action toggle"
title="Show / Hide">

<?php if($row['status']=="Visible"){ ?>

<i class="fa-solid fa-eye-slash"></i>

<?php }else{ ?>

<i class="fa-solid fa-eye"></i>

<?php } ?>

</button>

</a>

<a
href="announcement_management.php?delete=<?php echo $row['announcement_id']; ?>"
onclick="return confirm('Delete this announcement?');">

<button
type="button"
class="action delete"
title="Delete">

<i class="fa-solid fa-trash"></i>

</button>

</a>

</div>

</td>

</tr>

<?php

}

}else{

?>

<tr>

<td colspan="6" style="text-align:center;padding:35px;">

No announcements found.

</td>

</tr>

<?php

}

?>

</tbody>

</table>

</div>

</div>
    
    </main>

<script>

// ==========================
// Auto hide success message
// ==========================

const alertBox = document.querySelector(".alert");

if(alertBox){

    setTimeout(function(){

        alertBox.style.opacity = "0";
        alertBox.style.transform = "translateY(-10px)";

        setTimeout(function(){

            alertBox.style.display = "none";

        },300);

    },3000);

}

</script>

</body>
</html>