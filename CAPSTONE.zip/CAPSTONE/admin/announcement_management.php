<?php

session_start();

require_once "../connection.php";


// ===============================
// ADMIN LOGIN CHECK
// ===============================

if(!isset($_SESSION['admin_id'])){

    header("Location: ../login.php");

    exit();

}


if($_SESSION['usertype'] != "admin"){

    header("Location: ../user.php");

    exit();

}



$admin_id = $_SESSION['admin_id'];



// ===============================
// ADD ANNOUNCEMENT
// ===============================


if(isset($_POST['add_announcement'])){


    $title = $_POST['title'];

    $content = $_POST['content'];



    $stmt = mysqli_prepare($conn,

    "INSERT INTO announcements
    (
        title,
        content,
        posted_by
    )

    VALUES
    (?,?,?)"

    );


    mysqli_stmt_bind_param(

        $stmt,

        "ssi",

        $title,

        $content,

        $admin_id

    );


    mysqli_stmt_execute($stmt);



    header("Location: announcement_management.php");

    exit();


}




// ===============================
// UPDATE ANNOUNCEMENT STATUS
// ===============================


if(isset($_GET['toggle'])){


    $id = $_GET['toggle'];



    $query = mysqli_query($conn,

    "UPDATE announcements

    SET status =

    IF(status='Visible','Hidden','Visible')

    WHERE announcement_id='$id'"

    );



    header("Location: announcement_management.php");

    exit();


}





// ===============================
// DELETE ANNOUNCEMENT
// ===============================


if(isset($_GET['delete'])){


    $id = $_GET['delete'];



    mysqli_query($conn,

    "DELETE FROM announcements

    WHERE announcement_id='$id'"

    );



    header("Location: announcement_management.php");

    exit();


}





// ===============================
// LOAD ANNOUNCEMENTS
// ===============================


$announcements = mysqli_query($conn,

"

SELECT

a.announcement_id,

a.title,

a.content,

a.status,

a.created_at,

CONCAT(
u.firstname,
' ',
u.surname
) AS poster


FROM announcements a


INNER JOIN logintbl u

ON a.posted_by=u.id


ORDER BY a.created_at DESC


"

);



?>

<!DOCTYPE html>

<html lang="en">

<head>


<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">


<title>
Announcement Management - e-Nurse
</title>



<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">


<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">



<style>


*{

    margin:0;

    padding:0;

    box-sizing:border-box;

}



body{

    background:#f3f5fb;

    font-family:'Poppins',sans-serif;

}





/* =========================
MAIN
========================= */


.main{

    margin-left:230px;

    padding:30px;

    width:calc(100% - 230px);

}





/* =========================
HEADER
========================= */


.page-header{

    display:flex;

    justify-content:space-between;

    align-items:center;

    margin-bottom:25px;

    flex-wrap:wrap;

    gap:15px;

}



.page-header h1{

    font-size:32px;

    color:#111827;

    font-weight:600;

}



.page-header p{

    color:#6b7280;

    margin-top:5px;

}





/* =========================
BUTTONS
========================= */


.btn{

    border:none;

    border-radius:10px;

    padding:12px 18px;

    font-family:'Poppins',sans-serif;

    font-weight:600;

    cursor:pointer;

    text-decoration:none;

    display:inline-flex;

    align-items:center;

    gap:8px;

}



.btn-blue{

    background:#2563eb;

    color:white;

}



.btn-green{

    background:#16a34a;

    color:white;

}



.btn-red{

    background:#dc2626;

    color:white;

}



.btn-orange{

    background:#f97316;

    color:white;

}




/* =========================
CARDS
========================= */


.card{

    background:white;

    border-radius:18px;

    padding:25px;

    margin-bottom:25px;

    box-shadow:0 4px 18px rgba(0,0,0,.08);

}





.card h2{

    font-size:22px;

    margin-bottom:20px;

    color:#111827;

}





/* =========================
FORM
========================= */


.form-group{

    margin-bottom:18px;

}



.form-group label{

    display:block;

    margin-bottom:8px;

    font-weight:600;

    color:#374151;

}



.form-group input,
.form-group textarea{


    width:100%;

    border:1px solid #d1d5db;

    border-radius:10px;

    padding:12px 15px;

    font-family:'Poppins',sans-serif;

    font-size:14px;

}



.form-group textarea{

    height:120px;

    resize:none;

}







/* =========================
TABLE
========================= */


.table-container{

    overflow-x:auto;

}



table{

    width:100%;

    border-collapse:collapse;

}



th{

    background:#2563eb;

    color:white;

    padding:14px;

    text-align:left;

    font-size:14px;

}



td{

    padding:14px;

    border-bottom:1px solid #e5e7eb;

    font-size:14px;

    vertical-align:top;

}





/* =========================
STATUS BADGE
========================= */


.badge{

    padding:6px 12px;

    border-radius:999px;

    font-size:12px;

    font-weight:600;

}



.visible{

    background:#dcfce7;

    color:#166534;

}



.hidden{

    background:#fee2e2;

    color:#991b1b;

}





/* =========================
ACTION BUTTON
========================= */


.action{

    width:36px;

    height:36px;

    border:none;

    border-radius:10px;

    color:white;

    cursor:pointer;

}



.toggle{

    background:#f59e0b;

}



.delete{

    background:#dc2626;

}





/* =========================
RESPONSIVE
========================= */


@media(max-width:992px){


.main{

    margin-left:0;

    width:100%;

    padding:85px 20px 20px;

}



}



@media(max-width:600px){


.page-header{

    flex-direction:column;

    align-items:flex-start;

}



.btn{

    width:100%;

    justify-content:center;

}



.card{

    padding:18px;

}



table{

    min-width:900px;

}



}



</style>


</head>
    
    <body>


<?php include 'admin_sidebar.php'; ?>


<main class="main">



<!-- =========================
PAGE HEADER
========================= -->


<div class="page-header">


<div>

<h1>

<i class="fa-solid fa-bullhorn"></i>

Announcement Management

</h1>


<p>

Create announcements and manage updates for users.

</p>


</div>



<a href="admin_dashboard.php" class="btn btn-orange">

<i class="fa-solid fa-arrow-left"></i>

Dashboard

</a>



</div>









<!-- =========================
ADD ANNOUNCEMENT FORM
========================= -->


<div class="card">


<h2>

<i class="fa-solid fa-plus"></i>

Create Announcement

</h2>



<form method="POST">



<div class="form-group">


<label>

Announcement Title

</label>


<input

type="text"

name="title"

placeholder="Enter announcement title"

required

>


</div>






<div class="form-group">


<label>

Announcement Content

</label>


<textarea

name="content"

placeholder="Write announcement details..."

required

></textarea>


</div>






<button

type="submit"

name="add_announcement"

class="btn btn-blue"

>


<i class="fa-solid fa-paper-plane"></i>

Publish Announcement


</button>





</form>



</div>









<!-- =========================
ANNOUNCEMENT LIST
========================= -->


<div class="card">


<h2>

<i class="fa-solid fa-list"></i>

Announcement List

</h2>





<div class="table-container">


<table>



<thead>


<tr>


<th>
Title
</th>


<th>
Content
</th>


<th>
Posted By
</th>


<th>
Date
</th>


<th>
Status
</th>


<th width="120">
Action
</th>



</tr>


</thead>






<tbody>


<?php



if(mysqli_num_rows($announcements)>0){



while($row=mysqli_fetch_assoc($announcements)){



$statusClass = strtolower($row['status']);



?>



<tr>



<td>


<strong>

<?php echo htmlspecialchars($row['title']); ?>

</strong>


</td>







<td>


<?php echo htmlspecialchars($row['content']); ?>


</td>







<td>


<?php echo htmlspecialchars($row['poster']); ?>


</td>







<td>


<?php

echo date(

"M d, Y",

strtotime($row['created_at'])

);

?>


</td>







<td>


<span class="badge <?php echo $statusClass; ?>">


<?php echo $row['status']; ?>


</span>


</td>








<td>



<a

href="announcement_management.php?toggle=<?php echo $row['announcement_id']; ?>"

title="Hide/Show Announcement"

>


<button

class="action toggle"

>


<i class="fa-solid fa-eye-slash"></i>


</button>


</a>








<a

href="announcement_management.php?delete=<?php echo $row['announcement_id']; ?>"

onclick="return confirm('Delete this announcement?');"

title="Delete Announcement"

>


<button

class="action delete"

>


<i class="fa-solid fa-trash"></i>


</button>


</a>





</td>







</tr>



<?php


}


}else{


?>


<tr>


<td colspan="6" style="text-align:center;padding:30px;">


No announcements found.


</td>


</tr>


<?php


}


?>



</tbody>


</table>



</div>



</div>






</main>


</body>


</html>