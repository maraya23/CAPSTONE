<?php

session_start();

require_once "../connection.php";

/*========================================
ADMIN AUTHENTICATION
========================================*/

if(!isset($_SESSION['admin_id'])){

    header("Location: ../login.php");
    exit();

}

if(strtolower($_SESSION['usertype'])!="admin"){

    header("Location: ../user.php");
    exit();

}


/*========================================
UPLOAD DIRECTORY
========================================*/

$uploadDir = __DIR__."/../uploads/review_materials/";

if(!is_dir($uploadDir)){

    mkdir($uploadDir,0777,true);

}


/*========================================
ADD CATEGORY
========================================*/

if(isset($_POST['add_category'])){

    $category = trim($_POST['new_category']);

    if($category!=""){

        $check=mysqli_prepare(
            $conn,
            "SELECT category_id
             FROM categories
             WHERE category_name=?"
        );

        mysqli_stmt_bind_param(
            $check,
            "s",
            $category
        );

        mysqli_stmt_execute($check);

        mysqli_stmt_store_result($check);

        if(mysqli_stmt_num_rows($check)==0){

            $status="Active";

            $insert=mysqli_prepare(
                $conn,
                "INSERT INTO categories
                (
                    category_name,
                    status
                )
                VALUES
                (?,?)"
            );

            mysqli_stmt_bind_param(
                $insert,
                "ss",
                $category,
                $status
            );

            mysqli_stmt_execute($insert);

            header("Location: review_management.php?success=category");

            exit();

        }else{

            header("Location: review_management.php?error=categoryexists");

            exit();

        }

    }

}


/*========================================
UPLOAD REVIEW MATERIAL
========================================*/

if(isset($_POST['upload_material'])){

    $title = trim($_POST['title']);

    $description = trim($_POST['description']);

    $category_id = intval($_POST['category_id']);

    $uploaded_by = $_SESSION['admin_id'];

    $fileName="";

    if(isset($_FILES['file']) && $_FILES['file']['error']==0){

        $allowed=[
            "pdf",
            "doc",
            "docx",
            "ppt",
            "pptx"
        ];

        $extension=strtolower(

            pathinfo(
                $_FILES['file']['name'],
                PATHINFO_EXTENSION
            )

        );

        if(!in_array($extension,$allowed)){

            header("Location: review_management.php?error=filetype");

            exit();

        }

        if($_FILES['file']['size']>10*1024*1024){

            header("Location: review_management.php?error=filesize");

            exit();

        }

        $fileName=
        time()."_".
        preg_replace(
            "/[^A-Za-z0-9._-]/",
            "_",
            basename($_FILES['file']['name'])
        );

        move_uploaded_file(
            $_FILES['file']['tmp_name'],
            $uploadDir.$fileName
        );

    }

    $stmt=mysqli_prepare(

        $conn,

        "INSERT INTO review_materials
        (
            category_id,
            title,
            description,
            file_name,
            uploaded_by
        )
        VALUES
        (?,?,?,?,?)"

    );

    mysqli_stmt_bind_param(

        $stmt,

        "isssi",

        $category_id,

        $title,

        $description,

        $fileName,

        $uploaded_by

    );

    mysqli_stmt_execute($stmt);

    mysqli_stmt_close($stmt);

    header("Location: review_management.php?success=upload");

    exit();

}


/*========================================
DELETE MATERIAL
========================================*/

if(isset($_GET['delete'])){

    $id=intval($_GET['delete']);

    $stmt=mysqli_prepare(

        $conn,

        "SELECT file_name
         FROM review_materials
         WHERE material_id=?"

    );

    mysqli_stmt_bind_param(
        $stmt,
        "i",
        $id
    );

    mysqli_stmt_execute($stmt);

    $result=mysqli_stmt_get_result($stmt);

    if($row=mysqli_fetch_assoc($result)){

        if(!empty($row['file_name'])){

            $path=$uploadDir.$row['file_name'];

            if(file_exists($path)){

                unlink($path);

            }

        }

    }

    mysqli_stmt_close($stmt);

    $stmt=mysqli_prepare(

        $conn,

        "DELETE FROM review_materials
         WHERE material_id=?"

    );

    mysqli_stmt_bind_param(
        $stmt,
        "i",
        $id
    );

    mysqli_stmt_execute($stmt);

    mysqli_stmt_close($stmt);

    header("Location: review_management.php?success=deleted");

    exit();

}


/*========================================
LOAD CATEGORIES
========================================*/

$categories=mysqli_query(

    $conn,

    "SELECT
        category_id,
        category_name
     FROM categories
     WHERE status='Active'
     ORDER BY category_name"

);


/*========================================
SEARCH
========================================*/

$search="";

$categoryFilter="";

if(isset($_GET['search'])){

    $search=trim($_GET['search']);

}

if(isset($_GET['category'])){

    $categoryFilter=$_GET['category'];

}


/*========================================
LOAD MATERIALS
========================================*/

$sql="

SELECT

rm.*,

c.category_name,

CONCAT(
l.firstname,
' ',
l.surname
) AS uploader

FROM review_materials rm

INNER JOIN categories c

ON rm.category_id=c.category_id

INNER JOIN logintbl l

ON rm.uploaded_by=l.id

WHERE 1=1

";

if($search!=""){

    $safe=mysqli_real_escape_string($conn,$search);

    $sql.="

    AND rm.title LIKE '%$safe%'

    ";

}

if($categoryFilter!=""){

    $safe=mysqli_real_escape_string($conn,$categoryFilter);

    $sql.="

    AND rm.category_id='$safe'

    ";

}

$sql.="

ORDER BY rm.material_id DESC

";

$materials=mysqli_query($conn,$sql);

?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Review Management | e-Nurse</title>

<link rel="preconnect" href="https://fonts.googleapis.com">

<link rel="preconnect"
href="https://fonts.gstatic.com"
crossorigin>

<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap"
rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

*{

    margin:0;
    padding:0;
    box-sizing:border-box;

}

body{

    background:#f3f5fb;
    font-family:'Poppins',sans-serif;

}

/*==================================
MAIN
==================================*/

.main{

    margin-left:230px;
    width:calc(100% - 230px);
    min-height:100vh;
    padding:30px;

}

/*==================================
CARD
==================================*/

.card{

    background:#fff;
    border-radius:18px;
    padding:28px;
    margin-bottom:25px;
    box-shadow:0 5px 18px rgba(0,0,0,.08);

}

/*==================================
HEADER
==================================*/

.top{

    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:20px;
    flex-wrap:wrap;

}

.top h1{

    font-size:30px;
    color:#111827;

}

.top p{

    margin-top:6px;
    color:#6b7280;

}

/*==================================
BUTTON
==================================*/

.btn{

    display:inline-flex;
    align-items:center;
    justify-content:center;
    gap:8px;

    padding:12px 22px;

    border:none;
    border-radius:12px;

    background:#2563eb;
    color:#fff;

    font-weight:600;
    text-decoration:none;

    cursor:pointer;

    transition:.25s;

}

.btn:hover{

    background:#1d4ed8;

}

/*==================================
SUCCESS / ERROR
==================================*/

.success,
.error{

    padding:15px 18px;
    border-radius:12px;
    margin-bottom:20px;
    font-weight:600;

}

.success{

    background:#ecfdf5;
    color:#166534;
    border-left:5px solid #22c55e;

}

.error{

    background:#fef2f2;
    color:#991b1b;
    border-left:5px solid #ef4444;

}
    
    /*==================================
FILTERS
==================================*/

.filters{

    display:flex;
    gap:15px;
    margin-top:25px;
    flex-wrap:wrap;

}

/*==================================
SEARCH BOX
==================================*/

.search-box{

    position:relative;
    flex:1;
    min-width:300px;

}

.search-box input{

    width:100%;
    height:48px;

    padding-left:45px;
    padding-right:45px;

    border:1px solid #d1d5db;
    border-radius:12px;

    font-size:14px;
    font-family:'Poppins',sans-serif;

}

.search-box input:focus{

    outline:none;
    border-color:#2563eb;
    box-shadow:0 0 0 4px rgba(37,99,235,.15);

}

.search-icon{

    position:absolute;

    left:16px;
    top:50%;

    transform:translateY(-50%);

    color:#9ca3af;

    pointer-events:none;

}

.clear-btn{

    position:absolute;

    right:12px;
    top:50%;

    transform:translateY(-50%);

    width:28px;
    height:28px;

    border:none;
    border-radius:50%;

    background:#e5e7eb;

    color:#6b7280;

    cursor:pointer;

    display:flex;
    align-items:center;
    justify-content:center;

}

.clear-btn:hover{

    background:#d1d5db;
    color:#111827;

}

/*==================================
SELECT
==================================*/

select{

    height:48px;
    min-width:250px;

    border:1px solid #d1d5db;
    border-radius:12px;

    padding:0 15px;

    font-family:'Poppins',sans-serif;

}

select:focus{

    outline:none;
    border-color:#2563eb;
    box-shadow:0 0 0 4px rgba(37,99,235,.15);

}
    
    /*==================================
UPLOAD BOX
==================================*/

.upload-box{

    display:none;

    margin-top:30px;

    padding-top:25px;

    border-top:1px solid #e5e7eb;

}

.upload-box h3{

    font-size:22px;

    color:#111827;

    margin-bottom:20px;

}

.form-group{

    display:flex;

    flex-direction:column;

    margin-bottom:18px;

    gap:8px;

}

.form-group label{

    font-weight:600;

    color:#374151;

}

.form-control{

    width:100%;

    padding:12px 15px;

    border:1px solid #d1d5db;

    border-radius:12px;

    font-family:'Poppins',sans-serif;

    font-size:14px;

}

.form-control:focus{

    outline:none;

    border-color:#2563eb;

    box-shadow:0 0 0 4px rgba(37,99,235,.15);

}

textarea.form-control{

    resize:vertical;

    min-height:120px;

}

.file-input{

    width:100%;

    padding:14px;

    border:2px dashed #cbd5e1;

    border-radius:12px;

    background:#f8fafc;

    font-family:'Poppins',sans-serif;

    cursor:pointer;

}

.file-input:hover{

    border-color:#2563eb;

    background:#eff6ff;

}

.form-group small{

    color:#6b7280;

    font-size:13px;

    line-height:1.5;

}

/*==================================
ADD CATEGORY BUTTON
==================================*/

.category-row{

    display:flex;

    gap:10px;

    align-items:center;

}

.category-row select{

    flex:1;

}

.add-category-btn{

    width:48px;

    height:48px;

    border:none;

    border-radius:12px;

    background:#16a34a;

    color:#fff;

    cursor:pointer;

    font-size:18px;

    transition:.25s;

}

.add-category-btn:hover{

    background:#15803d;

}
    
    /*==================================
TABLE
==================================*/

.table-responsive{

    overflow-x:auto;

}

table{

    width:100%;
    min-width:1050px;
    border-collapse:collapse;

}

thead th{

    background:#2563eb;
    color:#fff;
    padding:14px;
    text-align:left;
    font-size:14px;

}

tbody td{

    padding:14px;
    border-bottom:1px solid #e5e7eb;
    vertical-align:top;
    font-size:14px;

}

tbody tr:hover{

    background:#f8fafc;

}

/*==================================
BADGES
==================================*/

.badge{

    display:inline-block;
    padding:6px 12px;
    border-radius:20px;
    background:#eff6ff;
    color:#2563eb;
    font-size:12px;
    font-weight:600;

}

.status-active{

    background:#dcfce7;
    color:#166534;

}

.status-hidden{

    background:#fee2e2;
    color:#991b1b;

}

/*==================================
ACTION BUTTONS
==================================*/

.action-btn{

    display:inline-flex;
    align-items:center;
    gap:6px;

    padding:8px 14px;

    border-radius:8px;

    color:#fff;
    text-decoration:none;

    font-size:13px;
    font-weight:500;

}

.view-btn{

    background:#2563eb;

}

.view-btn:hover{

    background:#1d4ed8;

}

.delete-btn{

    background:#dc2626;

}

.delete-btn:hover{

    background:#b91c1c;

}

/*==================================
RESPONSIVE
==================================*/

@media(max-width:768px){

.main{

    margin-left:0;
    width:100%;
    padding:85px 18px 20px;

}

.top{

    flex-direction:column;
    align-items:flex-start;

}

.filters{

    flex-direction:column;

}

.search-box{

    min-width:100%;

}

select{

    width:100%;

}

.card{

    padding:20px;

}

table{

    min-width:900px;

}

.btn{

    width:100%;

}

}

</style>

</head>

<body>

<?php include 'admin_sidebar.php'; ?>

<main class="main">
    
    <!-- ==========================================
SUCCESS / ERROR ALERTS
========================================== -->

<?php

if(isset($_GET['success'])){

    if($_GET['success']=="upload"){

        echo '

        <div class="success">

        <i class="fa-solid fa-circle-check"></i>

        Review material uploaded successfully.

        </div>

        ';

    }

    if($_GET['success']=="deleted"){

        echo '

        <div class="success">

        <i class="fa-solid fa-trash"></i>

        Review material deleted successfully.

        </div>

        ';

    }

    if($_GET['success']=="category"){

        echo '

        <div class="success">

        <i class="fa-solid fa-circle-check"></i>

        Category added successfully.

        </div>

        ';

    }

}

if(isset($_GET['error'])){

    if($_GET['error']=="filetype"){

        echo '

        <div class="error">

        Only PDF, DOC, DOCX, PPT and PPTX files are allowed.

        </div>

        ';

    }

    if($_GET['error']=="filesize"){

        echo '

        <div class="error">

        Maximum upload size is 10MB.

        </div>

        ';

    }

    if($_GET['error']=="categoryexists"){

        echo '

        <div class="error">

        Category already exists.

        </div>

        ';

    }

}

?>

<!-- ==========================================
HEADER
========================================== -->

<div class="card">

<div class="top">

<div>

<h1>

Review Management

</h1>

<p>

Upload, organize and manage nursing review materials.

</p>

</div>

<button

type="button"

class="btn"

onclick="showUpload()">

<i class="fa-solid fa-cloud-arrow-up"></i>

Upload Review Material

</button>

</div>

<!-- ==========================================
SEARCH & FILTER
========================================== -->

<form

method="GET"

class="filters">

<div class="search-box">

<i class="fa-solid fa-magnifying-glass search-icon"></i>

<input

type="text"

name="search"

placeholder="Search review materials..."

value="<?php echo htmlspecialchars($search); ?>">

<button

type="button"

class="clear-btn"

onclick="window.location='review_management.php'">

<i class="fa-solid fa-xmark"></i>

</button>

</div>

<select

name="category">

<option value="">

All Categories

</option>

<?php

mysqli_data_seek($categories,0);

while($cat=mysqli_fetch_assoc($categories)){

?>

<option

value="<?php echo $cat['category_id']; ?>"

<?php

if($categoryFilter==$cat['category_id']){

echo "selected";

}

?>

>

<?php echo htmlspecialchars($cat['category_name']); ?>

</option>

<?php

}

?>

</select>

<button

type="submit"

class="btn">

<i class="fa-solid fa-filter"></i>

Filter

</button>

</form>
    
    <!-- ==========================================
UPLOAD REVIEW MATERIAL
========================================== -->

<div
id="uploadBox"
class="upload-box">

<h3>

<i class="fa-solid fa-file-circle-plus"></i>

Upload Review Material

</h3>

<form

method="POST"

enctype="multipart/form-data">

<input
type="hidden"
name="upload_material"
value="1">

<!-- TITLE -->

<div class="form-group">

<label>

Title

</label>

<input

type="text"

name="title"

class="form-control"

placeholder="Example: Fundamentals of Nursing Module 1"

required>

</div>

<!-- CATEGORY -->

<div class="form-group">

<label>

Category

</label>

<div class="category-row">

<select

name="category_id"

class="form-control"

required>

<option value="">

Select Category

</option>

<?php

mysqli_data_seek($categories,0);

while($cat=mysqli_fetch_assoc($categories)){

?>

<option
value="<?php echo $cat['category_id']; ?>">

<?php echo htmlspecialchars($cat['category_name']); ?>

</option>

<?php

}

?>

</select>

<button

type="button"

class="add-category-btn"

title="Add New Category"

onclick="openCategory()">

<i class="fa-solid fa-plus"></i>

</button>

</div>

</div>

<!-- DESCRIPTION -->

<div class="form-group">

<label>

Description

</label>

<textarea

name="description"

class="form-control"

rows="4"

placeholder="Enter a short description of this review material...">

</textarea>

</div>

<!-- FILE -->

<div class="form-group">

<label>

Upload File

</label>

<input

type="file"

name="file"

class="file-input"

accept=".pdf,.doc,.docx,.ppt,.pptx"

required>

<small>

Allowed file types:

<strong>

PDF, DOC, DOCX, PPT, PPTX

</strong>

<br>

Maximum upload size:

<strong>

10 MB

</strong>

</small>

</div>

<button

type="submit"

class="btn">

<i class="fa-solid fa-floppy-disk"></i>

Save Review Material

</button>

</form>

</div>

</div>
    
    <!-- ==========================================
ADD CATEGORY MODAL
========================================== -->

<div

id="categoryModal"

style="

display:none;

position:fixed;

top:0;

left:0;

width:100%;

height:100%;

background:rgba(0,0,0,.45);

z-index:9999;

justify-content:center;

align-items:center;

">

<div

style="

background:#fff;

width:420px;

max-width:90%;

padding:28px;

border-radius:18px;

box-shadow:0 10px 35px rgba(0,0,0,.15);

">

<h2

style="

margin-bottom:20px;

color:#111827;

">

<i class="fa-solid fa-folder-plus"></i>

Add New Category

</h2>

<form method="POST">

<input

type="hidden"

name="add_category"

value="1">

<div class="form-group">

<label>

Category Name

</label>

<input

type="text"

name="new_category"

class="form-control"

placeholder="Example: Medical-Surgical Nursing"

required>

</div>

<div

style="

display:flex;

justify-content:flex-end;

gap:12px;

margin-top:25px;

">

<button

type="button"

class="btn"

style="background:#9ca3af;"

onclick="closeCategory()">

Cancel

</button>

<button

type="submit"

class="btn">

<i class="fa-solid fa-floppy-disk"></i>

Save Category

</button>

</div>

</form>

</div>

</div>
    
    <!-- ==========================================
UPLOADED REVIEW MATERIALS
========================================== -->

<div class="card">

<h2 style="margin-bottom:20px;">

<i class="fa-solid fa-folder-open"></i>

Uploaded Review Materials

</h2>

<div class="table-responsive">

<table>

<thead>

<tr>

<th>Title</th>

<th>Category</th>

<th>Uploaded By</th>

<th>File</th>

<th>Date Uploaded</th>

<th>Status</th>

<th width="120">Action</th>

</tr>

</thead>

<tbody>

<?php

if(mysqli_num_rows($materials)>0){

while($row=mysqli_fetch_assoc($materials)){

?>

<tr>

<td>

<strong>

<?php echo htmlspecialchars($row['title']); ?>

</strong>

<br>

<small style="color:#6b7280;">

<?php echo htmlspecialchars($row['description']); ?>

</small>

</td>

<td>

<span class="badge">

<?php echo htmlspecialchars($row['category_name']); ?>

</span>

</td>

<td>

<?php echo htmlspecialchars($row['uploader']); ?>

</td>

<td>

<?php

if(!empty($row['file_name'])){

?>

<a

href="../uploads/review_materials/<?php echo urlencode($row['file_name']); ?>"

target="_blank"

class="action-btn view-btn">

<i class="fa-solid fa-file"></i>

View

</a>

<?php

}else{

echo "<span style='color:#9ca3af;'>No File</span>";

}

?>

</td>

<td>

<a
href="../uploads/review_materials/<?php echo urlencode($row['file_name']); ?>"
target="_blank"
class="action-btn view-btn">

<i class="fa-solid fa-eye"></i>

View

</a>

<a
href="edit_review_material.php?id=<?php echo $row['material_id']; ?>"
class="action-btn"
style="background:#2563eb;">

<i class="fa-solid fa-pen"></i>

Edit

</a>

<?php if($row['status']=="Active"){ ?>

<a
href="review_management.php?hide=<?php echo $row['material_id']; ?>"
class="action-btn"
style="background:#f59e0b;"
onclick="return confirm('Hide this review material?');">

<i class="fa-solid fa-eye-slash"></i>

Hide

</a>

<?php } else { ?>

<a
href="review_management.php?show=<?php echo $row['material_id']; ?>"
class="action-btn"
style="background:#16a34a;"
onclick="return confirm('Show this review material?');">

<i class="fa-solid fa-eye"></i>

Show

</a>

<?php } ?>

<a
href="review_management.php?delete=<?php echo $row['material_id']; ?>"
class="action-btn delete-btn"
onclick="return confirm('Delete this review material permanently?');">

<i class="fa-solid fa-trash"></i>

Delete

</a>

</td>

</tr>

<?php

}

}else{

?>

<tr>

<td colspan="7" style="text-align:center;padding:40px;">

<i

class="fa-solid fa-folder-open"

style="font-size:42px;color:#9ca3af;display:block;margin-bottom:15px;">

</i>

No review materials found.

</td>

</tr>

<?php

}

?>

</tbody>

</table>

</div>

</div>
    
    </main>

<script>

/*========================================
SHOW / HIDE UPLOAD FORM
========================================*/

function showUpload(){

    let box = document.getElementById("uploadBox");

    if(box.style.display=="block"){

        box.style.display="none";

    }else{

        box.style.display="block";

        box.scrollIntoView({

            behavior:"smooth",

            block:"start"

        });

    }

}

/*========================================
CATEGORY MODAL
========================================*/

function openCategory(){

    document.getElementById("categoryModal").style.display="flex";

}

function closeCategory(){

    document.getElementById("categoryModal").style.display="none";

}

/*========================================
CLICK OUTSIDE MODAL
========================================*/

window.onclick=function(event){

    let modal=document.getElementById("categoryModal");

    if(event.target==modal){

        modal.style.display="none";

    }

}

/*========================================
AUTO HIDE ALERTS
========================================*/

setTimeout(function(){

    let success=document.querySelector(".success");

    let error=document.querySelector(".error");

    if(success){

        success.style.transition=".4s";
        success.style.opacity="0";

        setTimeout(function(){

            success.remove();

        },400);

    }

    if(error){

        error.style.transition=".4s";
        error.style.opacity="0";

        setTimeout(function(){

            error.remove();

        },400);

    }

},4000);

/*========================================
ENTER KEY SEARCH
========================================*/

const searchInput=document.querySelector("input[name='search']");

if(searchInput){

    searchInput.addEventListener("keypress",function(e){

        if(e.key==="Enter"){

            this.form.submit();

        }

    });

}

</script>

</body>

</html>