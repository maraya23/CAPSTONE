<?php

error_reporting(E_ALL);
ini_set('display_errors',1);

session_start();

require_once "../connection.php";


// ==================================
// CHECK ADMIN LOGIN
// ==================================

if(!isset($_SESSION["admin_id"])){

    header("Location: ../login.php");
    exit();

}



// ==================================
// GENERATE PERMIT
// ==================================

if(isset($_POST["generate_permit"])){


    $user_id = $_POST["user_id"];

    $exam_id = $_POST["exam_id"];

    $exam_schedule = $_POST["exam_schedule"];



    // AUTO GENERATE PERMIT NUMBER

    $permit_number = "ENURSE-".date("Ymd")."-".rand(1000,9999);



    $sql = "

    INSERT INTO e_permits

    (
        user_id,
        exam_id,
        permit_number,
        exam_schedule
    )

    VALUES (?,?,?,?)

    ";



    $stmt=mysqli_prepare($conn,$sql);



    mysqli_stmt_bind_param(

        $stmt,

        "iiss",

        $user_id,

        $exam_id,

        $permit_number,

        $exam_schedule

    );



    mysqli_stmt_execute($stmt);



    header("Location: admin_epermit.php");

    exit();


}





// ==================================
// DELETE PERMIT
// ==================================

if(isset($_GET["delete"])){


    $permit_id=$_GET["delete"];



    $sql="

    DELETE FROM e_permits

    WHERE permit_id=?

    ";



    $stmt=mysqli_prepare($conn,$sql);



    mysqli_stmt_bind_param(

        $stmt,

        "i",

        $permit_id

    );



    mysqli_stmt_execute($stmt);



    header("Location: admin_epermit.php");

    exit();


}







// ==================================
// GET STUDENTS
// ==================================


$students = mysqli_query(

$conn,

"

SELECT 

id,

firstname,

surname

FROM logintbl

WHERE usertype='User'

ORDER BY firstname

"

);







// ==================================
// GET EXAMS
// ==================================


$exams=mysqli_query(

$conn,

"

SELECT

exam_id,

title,

exam_type

FROM exams

WHERE status='Published'

ORDER BY created_at DESC

"

);









// ==================================
// GET ALL PERMITS
// ==================================


$permits=mysqli_query(

$conn,

"

SELECT


ep.permit_id,

ep.permit_number,

ep.exam_schedule,

ep.issued_date,


CONCAT(

u.firstname,

' ',

u.surname

) AS student_name,


e.title,

e.exam_type



FROM e_permits ep



INNER JOIN logintbl u

ON ep.user_id=u.id



INNER JOIN exams e

ON ep.exam_id=e.exam_id



ORDER BY ep.issued_date DESC



"

);



?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Admin E-Permit Management</title>


<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">


<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css">


<style>


*{

    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;

}



body{

    background:#f4f7fc;

}



/* =========================
   MAIN CONTENT
========================= */


.main-content{

    margin-left:230px;

    padding:30px;

    min-height:100vh;

}





/* =========================
   HEADER
========================= */


.page-header{

    margin-bottom:30px;

}



.page-header h1{

    color:#0A2F73;

    font-size:32px;

    font-weight:700;

}



.page-header p{

    color:#6b7280;

    margin-top:5px;

    font-size:15px;

}



/* =========================
   CARD
========================= */


.card{

    background:white;

    padding:25px;

    border-radius:18px;

    box-shadow:0 8px 25px rgba(0,0,0,.08);

    margin-bottom:25px;

}



.card-title{

    display:flex;

    align-items:center;

    gap:10px;

    margin-bottom:20px;

}



.card-title h2{

    color:#0A2F73;

    font-size:22px;

}



.card-title i{

    color:#2563eb;

}



/* =========================
 FORM
========================= */


.form-grid{

    display:grid;

    grid-template-columns:repeat(3,1fr);

    gap:20px;

}



.form-group{

    display:flex;

    flex-direction:column;

}



.form-group label{

    font-size:14px;

    font-weight:600;

    margin-bottom:8px;

    color:#374151;

}



.form-group select,

.form-group input{


    padding:12px;

    border-radius:12px;

    border:1px solid #d1d5db;

    outline:none;

}



.form-group select:focus,

.form-group input:focus{

    border-color:#2563eb;

}





.generate-btn{


    margin-top:25px;

    background:#2563eb;

    color:white;

    border:none;

    padding:13px 25px;

    border-radius:12px;

    cursor:pointer;

    font-weight:600;

    font-size:14px;

}



.generate-btn:hover{

    background:#1d4ed8;

}





/* =========================
 TABLE
========================= */


.table-responsive{

    overflow-x:auto;

}



table{

    width:100%;

    border-collapse:collapse;

    min-width:900px;

}



thead{

    background:#0A2F73;

}



thead th{

    color:white;

    padding:15px;

    text-align:left;

    font-size:14px;

}



tbody td{

    padding:15px;

    border-bottom:1px solid #eef2f7;

    font-size:14px;

    color:#374151;

}



tbody tr:hover{

    background:#f8fbff;

}





/* =========================
 BADGES
========================= */


.badge{


    padding:6px 14px;

    border-radius:20px;

    font-size:12px;

    font-weight:600;


}



.mock{

    background:#dbeafe;

    color:#1d4ed8;

}



.practice{

    background:#dcfce7;

    color:#15803d;

}





/* =========================
 DELETE BUTTON
========================= */


.delete-btn{

    background:#dc2626;

    color:white;

    padding:8px 14px;

    border-radius:10px;

    text-decoration:none;

    font-size:13px;

}



.delete-btn:hover{

    background:#b91c1c;

}



/* =========================
 MOBILE
========================= */


@media(max-width:768px){


.main-content{

    margin-left:0;

    padding:85px 15px 20px;

}



.form-grid{

    grid-template-columns:1fr;

}


.card{

    padding:18px;

}



}


</style>


</head>
    
    <body>


<?php include "admin_sidebar.php"; ?>



<div class="main-content">



<!-- ==========================
        PAGE HEADER
=========================== -->


<div class="page-header">


<h1>

<i class="fa-solid fa-id-card"></i>

E-Permit Management

</h1>


<p>

Generate and manage student examination permits.

</p>


</div>





<!-- ==========================
        GENERATE PERMIT FORM
=========================== -->


<div class="card">


<div class="card-title">


<i class="fa-solid fa-file-circle-plus"></i>


<h2>

Generate New Permit

</h2>


</div>





<form method="POST">



<div class="form-grid">



<!-- STUDENT -->


<div class="form-group">


<label>

Select Student

</label>



<select name="user_id" required>


<option value="">

-- Select Student --

</option>



<?php while($student=mysqli_fetch_assoc($students)){ ?>


<option value="<?= $student['id']; ?>">


<?= htmlspecialchars(
$student['firstname']." ".$student['surname']
); ?>


</option>



<?php } ?>



</select>



</div>









<!-- EXAM -->


<div class="form-group">


<label>

Select Examination

</label>



<select name="exam_id" required>


<option value="">

-- Select Exam --

</option>



<?php while($exam=mysqli_fetch_assoc($exams)){ ?>



<option value="<?= $exam['exam_id']; ?>">


<?= htmlspecialchars($exam['title']); ?>


(<?= $exam['exam_type']; ?>)


</option>



<?php } ?>



</select>



</div>









<!-- DATE -->


<div class="form-group">


<label>

Exam Schedule

</label>



<input

type="date"

name="exam_schedule"

required

>



</div>





</div>





<button

type="submit"

name="generate_permit"

class="generate-btn">


<i class="fa-solid fa-qrcode"></i>


Generate Permit


</button>





</form>


</div>
    
    <!-- ==========================
        EXISTING PERMITS
=========================== -->


<div class="card">


<div class="card-title">


<i class="fa-solid fa-list"></i>


<h2>

Generated Permits

</h2>


</div>





<div class="table-responsive">



<table>


<thead>


<tr>


<th>

Permit No.

</th>


<th>

Student

</th>


<th>

Exam

</th>


<th>

Type

</th>


<th>

Schedule

</th>


<th>

Issued Date

</th>


<th>

Action

</th>


</tr>


</thead>





<tbody>



<?php



if(mysqli_num_rows($permits)>0){



while($row=mysqli_fetch_assoc($permits)){



?>



<tr>


<td>


<strong>

<?= htmlspecialchars($row["permit_number"]); ?>

</strong>


</td>





<td>


<i class="fa-solid fa-user"></i>


<?= htmlspecialchars($row["student_name"]); ?>


</td>






<td>


<?= htmlspecialchars($row["title"]); ?>


</td>







<td>



<?php


if($row["exam_type"]=="Mock Exam"){



echo '

<span class="badge mock">

Mock Examination

</span>

';



}else{



echo '

<span class="badge practice">

Practice Quiz

</span>

';



}



?>



</td>








<td>



<?= date(

"M d, Y",

strtotime($row["exam_schedule"])

); ?>



</td>









<td>



<?= date(

"M d, Y",

strtotime($row["issued_date"])

); ?>



</td>









<td>



<a


href="admin_epermit.php?delete=<?= $row['permit_id']; ?>"


class="delete-btn"


onclick="return confirm('Delete this permit?');"



>


<i class="fa-solid fa-trash"></i>


Delete


</a>



</td>





</tr>



<?php



}



}else{



?>



<tr>


<td colspan="7">



<div class="empty-state">



<i class="fa-solid fa-folder-open"></i>



<h3>

No Permit Generated

</h3>



<p>

Generate an examination permit for students.

</p>



</div>



</td>

</tr>



<?php



}



?>





</tbody>


</table>


</div>


</div>





</div>


</body>


</html>