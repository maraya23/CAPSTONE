<?php

error_reporting(E_ALL);
ini_set('display_errors',1);

session_start();

require_once "../connection.php";



// ===============================
// CHECK LOGIN
// ===============================

if(!isset($_SESSION['user_id'])){

    header("Location: ../login.php");
    exit();

}


$user_id = $_SESSION['user_id'];




// ===============================
// GET LATEST EXAM RESULT
// ===============================


$sql = "

SELECT


ea.attempt_id,

ea.score,

ea.total_questions,

ea.percentage,

ea.remarks,

ea.end_time,

e.title,

e.description


FROM exam_attempts ea


INNER JOIN exams e

ON ea.exam_id = e.exam_id


WHERE ea.user_id = ?


ORDER BY ea.attempt_id DESC


LIMIT 1


";



$stmt=$conn->prepare($sql);



$stmt->bind_param(

"i",

$user_id

);



$stmt->execute();



$result=$stmt->get_result();




if($result->num_rows==0){


    die("No exam result found.");

}



$exam=$result->fetch_assoc();





?>



<!DOCTYPE html>

<html lang="en">

<head>


<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">


<title>Exam Result</title>



<link rel="stylesheet"

href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">


<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">


<style>


*{

margin:0;

padding:0;

box-sizing:border-box;

font-family:'Poppins',sans-serif;

}



body{

background:#f4f7fc;

}





.main-content{


margin-left:250px;

padding:30px;


}





.result-card{


background:white;

max-width:650px;

margin:auto;

padding:35px;

border-radius:20px;

box-shadow:0 8px 20px rgba(0,0,0,.08);


}





.title{


text-align:center;

color:#1d3557;

margin-bottom:25px;

}





.icon{


width:80px;

height:80px;

background:#1d4ed8;

color:white;

border-radius:50%;

display:flex;

align-items:center;

justify-content:center;

font-size:35px;

margin:0 auto 20px;


}





.exam-name{


text-align:center;

font-size:22px;

font-weight:600;

color:#333;

margin-bottom:25px;


}





.info-box{


background:#f8fafc;

padding:20px;

border-radius:15px;

}





.info-box p{


margin-bottom:12px;

color:#555;


}





.info-box strong{


color:#1d3557;


}





.status{


margin-top:25px;

padding:15px;

border-radius:12px;

text-align:center;

font-size:20px;

font-weight:700;


}



.passed{


background:#dcfce7;

color:#15803d;

}



.failed{


background:#fee2e2;

color:#dc2626;

}






.btn{


display:block;

text-align:center;

background:#1d3557;

color:white;

text-decoration:none;

padding:13px;

border-radius:12px;

margin-top:25px;

}



.btn:hover{

background:#457b9d;

}





@media(max-width:768px){


.main-content{

margin-left:0;

padding:80px 15px 20px;

}



}



</style>


</head>



<body>


<?php include "user_sidebar.php"; ?>



<div class="main-content">


<div class="result-card">



<div class="icon">

<i class="fa-solid fa-award"></i>

</div>




<h1 class="title">

Exam Completed

</h1>






<div class="exam-name">


<?= htmlspecialchars($exam['title']); ?>


</div>






<div class="info-box">



<p>


<strong>Score:</strong>


<?= $exam['score']; ?>

/

<?= $exam['total_questions']; ?>


</p>




<p>


<strong>Percentage:</strong>


<?= number_format($exam['percentage'],2); ?>%


</p>





<p>


<strong>Date Taken:</strong>


<?= date(
"F d, Y",
strtotime($exam['end_time'])
); ?>


</p>




</div>







<div class="status

<?php

echo ($exam['remarks']=="Passed")

?

" passed"

:

" failed";


?>">


<?= strtoupper($exam['remarks']); ?>


</div>







<a href="user_dashboard.php"

class="btn">


Back to Dashboard


</a>





</div>


</div>



</body>


</html>