<?php

error_reporting(E_ALL);
ini_set('display_errors',1);

session_start();


// CHECK LOGIN

if(!isset($_SESSION['user_id'])){

    header("Location: ../login.php");
    exit();

}


include "../connection.php";



// GET USER DATA

$user_id = $_SESSION['user_id'];


$user_query = "

SELECT firstname, surname

FROM logintbl

WHERE id = ?

";


$stmt = $conn->prepare($user_query);


if(!$stmt){

    die("User Query Error: ".$conn->error);

}


$stmt->bind_param("i",$user_id);

$stmt->execute();


$user_result = $stmt->get_result();



if($user_result->num_rows > 0){


    $user = $user_result->fetch_assoc();


    $fullname = 
    $user['firstname']." ".$user['surname'];


}else{


    $fullname = "Student";


}





// GET CATEGORIES


$quiz_query = "

SELECT

c.category_id,

c.category_name,

COUNT(q.question_id) AS total_questions


FROM categories c


LEFT JOIN questions q

ON c.category_id = q.category_id

AND q.status='Active'


WHERE c.status='Active'


GROUP BY c.category_id,c.category_name


ORDER BY c.category_name ASC


";



$quiz_result = $conn->query($quiz_query);



if(!$quiz_result){

    die("Quiz Query Error: ".$conn->error);

}


?>



<!DOCTYPE html>

<html>

<head>


<title>Practice Quizzes</title>


<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">


<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">



<style>


*{

margin:0;
padding:0;
box-sizing:border-box;
font-family:'Poppins',sans-serif;

}



body{

background:#f4f7fc;

}



/* CONTENT */


.main-content{

margin-left:250px;

padding:30px;

}




.header-card{

background:white;

padding:30px;

border-radius:20px;

box-shadow:0 8px 20px rgba(0,0,0,.08);

margin-bottom:30px;

}



.header-card h1{

color:#1d3557;

font-size:32px;

}



.header-card p{

margin-top:8px;

color:#666;

}



.section-title{

color:#1d3557;

margin-bottom:20px;

}





.quiz-container{


display:grid;

grid-template-columns:

repeat(auto-fit,minmax(260px,1fr));


gap:25px;


}





.quiz-card{


background:white;

padding:25px;

border-radius:20px;

box-shadow:0 5px 15px rgba(0,0,0,.08);

transition:.3s;


}



.quiz-card:hover{

transform:translateY(-5px);

}




.quiz-icon{


width:60px;

height:60px;

background:#457b9d;

color:white;

border-radius:50%;

display:flex;

align-items:center;

justify-content:center;

font-size:25px;

margin-bottom:20px;


}




.quiz-card h3{

color:#1d3557;

margin-bottom:10px;

}




.quiz-card span{

color:#777;

font-size:14px;

}




.start-btn{


display:block;

margin-top:20px;

padding:12px;

background:#1d3557;

color:white;

text-align:center;

border-radius:12px;

text-decoration:none;


}



.start-btn:hover{

background:#457b9d;

}





.empty-box{

background:white;

padding:30px;

border-radius:20px;

text-align:center;

}



@media(max-width:768px){


.main-content{

margin-left:0;

padding:80px 15px 20px;

}


.quiz-container{

grid-template-columns:1fr;

}


}


</style>



</head>


<body>


<?php include "user_sidebar.php"; ?>



<div class="main-content">



<div class="header-card">


<h1>

<i class="fa-solid fa-clipboard-question"></i>

Practice Quizzes

</h1>


<p>

Welcome,

<b>

<?php echo htmlspecialchars($fullname); ?>

</b>

</p>


<p>

Choose a category and test your knowledge.

</p>


</div>





<h2 class="section-title">

Available Quiz Categories

</h2>




<div class="quiz-container">





<?php


if($quiz_result->num_rows > 0){



while($row=$quiz_result->fetch_assoc()){



?>



<div class="quiz-card">



<div class="quiz-icon">

<i class="fa-solid fa-brain"></i>

</div>




<h3>

<?php echo htmlspecialchars($row['category_name']); ?>

</h3>




<span>

<?php echo $row['total_questions']; ?>

Questions Available

</span>




<?php if($row['total_questions'] > 0){ ?>


<a class="start-btn"

href="take_quiz.php?category_id=<?php echo $row['category_id']; ?>">


START QUIZ


</a>


<?php }else{ ?>


<span>

No questions yet

</span>


<?php } ?>




</div>



<?php


}



}else{


?>



<div class="empty-box">


<h3>

No Practice Quiz Available

</h3>


<p>

Admin has not uploaded questions yet.

</p>


</div>



<?php


}



?>





</div>


</div>



</body>


</html>