<?php

error_reporting(E_ALL);
ini_set('display_errors',1);

session_start();

require_once "../connection.php";



// ===============================
// CHECK LOGIN
// ===============================

if(!isset($_SESSION['user_id'])){

    header("Location: ../login.php");
    exit();

}




// ===============================
// CHECK EXAM SESSION
// ===============================

if(
    !isset($_SESSION['attempt_id']) ||
    !isset($_SESSION['exam_id']) ||
    !isset($_SESSION['exam_questions'])
){

    header("Location: user_mockexamination.php");
    exit();

}



$user_id = $_SESSION['user_id'];

$attempt_id = $_SESSION['attempt_id'];

$exam_id = $_SESSION['exam_id'];

$questions = $_SESSION['exam_questions'];

$answers = $_SESSION['answers'] ?? [];






// ===============================
// CHECK ANSWERS
// ===============================


$score = 0;

$total_questions = count($questions);






// Prepare insert query

$answer_sql = "

INSERT INTO exam_answers

(

attempt_id,

question_id,

selected_answer,

correct_answer,

is_correct

)

VALUES

(

?,?,?,?,?

)

";



$stmt = $conn->prepare($answer_sql);






foreach($questions as $index=>$question){



    $question_number = $index + 1;



    $selected_answer = 
    $answers[$question_number] ?? null;



    $correct_answer =
    $question['correct_answer'];



    $is_correct = 0;



    if(
        $selected_answer != null &&
        $selected_answer == $correct_answer
    ){


        $is_correct = 1;

        $score++;


    }





    $stmt->bind_param(

        "iissi",

        $attempt_id,

        $question['question_id'],

        $selected_answer,

        $correct_answer,

        $is_correct

    );



    $stmt->execute();



}







// ===============================
// CALCULATE RESULT
// ===============================


$percentage = 0;



if($total_questions > 0){


    $percentage =

    ($score / $total_questions) * 100;


}





// ===============================
// GET PASSING SCORE
// ===============================


$passing_sql = "

SELECT passing_score

FROM exams

WHERE exam_id=?

";



$stmt = $conn->prepare($passing_sql);



$stmt->bind_param(

"i",

$exam_id

);



$stmt->execute();



$result = $stmt->get_result();



$exam = $result->fetch_assoc();




$passing_score = $exam['passing_score'];






if($percentage >= $passing_score){


    $remarks = "Passed";


}else{


    $remarks = "Failed";


}






// ===============================
// UPDATE EXAM ATTEMPT
// ===============================



$update_sql = "

UPDATE exam_attempts

SET

end_time = NOW(),

score = ?,

total_questions = ?,

percentage = ?,

remarks = ?

WHERE attempt_id = ?

";




$stmt=$conn->prepare($update_sql);



$stmt->bind_param(

"iidsi",

$score,

$total_questions,

$percentage,

$remarks,

$attempt_id

);



$stmt->execute();






// ===============================
// STORE RESULT SESSION
// ===============================


$_SESSION['exam_score']=$score;

$_SESSION['exam_percentage']=$percentage;

$_SESSION['exam_remarks']=$remarks;






// ===============================
// CLEAR EXAM SESSION
// KEEP RESULT DATA
// ===============================



unset($_SESSION['exam_questions']);

unset($_SESSION['answers']);

unset($_SESSION['exam_id']);

unset($_SESSION['attempt_id']);






header(
"Location: mockexam_result.php"
);

exit();


?>