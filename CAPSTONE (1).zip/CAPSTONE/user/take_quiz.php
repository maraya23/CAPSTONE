<?php

error_reporting(E_ALL);
ini_set('display_errors',1);

session_start();


if(!isset($_SESSION['user_id'])){

    header("Location: ../login.php");
    exit();

}


include "../connection.php";




// CHECK CATEGORY ID


if(!isset($_GET['category_id'])){

    header("Location: user_practicequizzes.php");
    exit();

}



$category_id = $_GET['category_id'];




// GET CATEGORY NAME


$category_query = "

SELECT category_name

FROM categories

WHERE category_id = ?

";



$stmt = $conn->prepare($category_query);

$stmt->bind_param("i",$category_id);

$stmt->execute();


$category_result = $stmt->get_result();



if($category_result->num_rows == 0){

    die("Invalid Category");

}



$category = $category_result->fetch_assoc();






// START QUIZ SESSION


if(!isset($_SESSION['quiz_questions'])){


    $question_limit = 10;



    $question_query = "

   SELECT *

FROM questions

WHERE category_id = ?

AND status='Active'

ORDER BY RAND()

LIMIT ?";



    $stmt=$conn->prepare($question_query);


    $stmt->bind_param(
"ii",
$category_id,
$question_limit
);


    $stmt->execute();


    $result=$stmt->get_result();



    $questions=[];



    while($row=$result->fetch_assoc()){


        $questions[]=$row;


    }





    if(count($questions)==0){

        die("No questions available.");

    }




    $_SESSION['quiz_questions']=$questions;


    $_SESSION['quiz_answers']=[];

    $_SESSION['quiz_current']=0;


}




// CURRENT QUESTION INDEX


$current = $_SESSION['quiz_current'];



$questions=$_SESSION['quiz_questions'];



$total=count($questions);





// SAVE ANSWER WHEN NEXT CLICKED


if(isset($_POST['answer'])){


    $_SESSION['quiz_answers'][$current]=$_POST['answer'];

}



if(isset($_POST['next'])){


    if($current < $total-1){

        $_SESSION['quiz_current']++;

    }


}



if(isset($_POST['previous'])){


    if($current > 0){

        $_SESSION['quiz_current']--;

    }


}




// UPDATE CURRENT


$current=$_SESSION['quiz_current'];



$question=$questions[$current];




?>



<!DOCTYPE html>

<html>

<head>


<title>Take Quiz</title>



<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">



<style>


*{

margin:0;
padding:0;
box-sizing:border-box;
font-family:'Poppins',sans-serif;

}



body{

background:#f4f7fc;

}



.container{

width:90%;
max-width:900px;

margin:40px auto;


}



.quiz-box{

background:white;

padding:35px;

border-radius:20px;

box-shadow:0 8px 20px rgba(0,0,0,.08);

}




.header{

display:flex;

justify-content:space-between;

margin-bottom:25px;

}



.header h2{

color:#1d3557;

}



.counter{

background:#457b9d;

color:white;

padding:8px 15px;

border-radius:20px;

}



.question{


font-size:20px;

font-weight:600;

margin-bottom:25px;

color:#333;

}





.option{


display:block;

background:#f1f5f9;

padding:15px;

border-radius:12px;

margin-bottom:12px;

cursor:pointer;

}



.option:hover{

background:#dbeafe;

}



input[type=radio]{

margin-right:10px;

}




.buttons{

display:flex;

justify-content:space-between;

margin-top:30px;

}



button{

padding:12px 25px;

border:none;

border-radius:10px;

background:#1d3557;

color:white;

cursor:pointer;

font-size:15px;

}



button:hover{

background:#457b9d;

}



.submit-btn{

background:#16a34a;

}




</style>



</head>


<body>




<div class="container">



<div class="quiz-box">



<div class="header">


<h2>

<?php echo htmlspecialchars($category['category_name']); ?>

</h2>



<div class="counter">


<?php echo ($current+1)." / ".$total; ?>


</div>



</div>





<form method="POST">





<div class="question">


<?php echo htmlspecialchars($question['question']); ?>


</div>






<label class="option">


<input type="radio"

name="answer"

value="A"

<?php

if(isset($_SESSION['quiz_answers'][$current])

&&

$_SESSION['quiz_answers'][$current]=="A")

echo "checked";

?>


>


A.

<?php echo htmlspecialchars($question['option_a']); ?>


</label>






<label class="option">


<input type="radio"

name="answer"

value="B"

<?php

if(isset($_SESSION['quiz_answers'][$current])

&&

$_SESSION['quiz_answers'][$current]=="B")

echo "checked";

?>


>


B.

<?php echo htmlspecialchars($question['option_b']); ?>


</label>







<label class="option">


<input type="radio"

name="answer"

value="C"


<?php

if(isset($_SESSION['quiz_answers'][$current])

&&

$_SESSION['quiz_answers'][$current]=="C")

echo "checked";

?>


>


C.

<?php echo htmlspecialchars($question['option_c']); ?>


</label>






<label class="option">


<input type="radio"

name="answer"

value="D"


<?php

if(isset($_SESSION['quiz_answers'][$current])

&&

$_SESSION['quiz_answers'][$current]=="D")

echo "checked";

?>


>


D.

<?php echo htmlspecialchars($question['option_d']); ?>


</label>







<div class="buttons">


<?php if($current > 0){ ?>


<button name="previous">

Previous

</button>


<?php } ?>





<?php if($current < $total-1){ ?>


<button name="next">

Next

</button>


<?php }else{ ?>


<button 

class="submit-btn"

name="submit"

formaction="quiz_result.php">


Submit Quiz


</button>


<?php } ?>




</div>




</form>




</div>


</div>



</body>

</html>