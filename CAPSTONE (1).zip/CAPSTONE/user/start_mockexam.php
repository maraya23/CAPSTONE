<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

require_once "../connection.php";


// ===============================
// CHECK LOGIN
// ===============================

if (!isset($_SESSION['user_id'])) {

    header("Location: ../login.php");
    exit();

}


$user_id = $_SESSION['user_id'];



// ===============================
// CHECK EXAM ID
// ===============================

if (!isset($_GET['exam_id'])) {

    header("Location: user_mockexamination.php");
    exit();

}


$exam_id = intval($_GET['exam_id']);




// ===============================
// GET EXAM INFORMATION
// ===============================


$exam_sql = "

SELECT

e.exam_id,

e.title,

e.description,

e.duration,

e.total_questions,

e.passing_score,

e.instructions,

c.category_name


FROM exams e


INNER JOIN categories c

ON e.category_id = c.category_id


WHERE e.exam_id = ?

AND e.exam_type = 'Mock Exam'

AND e.status = 'Published'

";



$stmt = $conn->prepare($exam_sql);



if(!$stmt){

    die("Exam Query Error: ".$conn->error);

}



$stmt->bind_param(
    "i",
    $exam_id
);



$stmt->execute();



$result = $stmt->get_result();



if($result->num_rows == 0){

    die("Exam not available.");

}



$exam = $result->fetch_assoc();




// ===============================
// E-PERMIT VERIFICATION
// WILL CONNECT LATER
// ===============================


/*

LATER:

SELECT FROM e_permits

WHERE user_id = ?

AND exam_id = ?


*/


// ===============================
// CREATE EXAM ATTEMPT
// ===============================


$attempt_sql = "

INSERT INTO exam_attempts

(

user_id,

exam_id,

start_time,

total_questions

)


VALUES

(

?,

?,

NOW(),

?

)

";



$stmt = $conn->prepare($attempt_sql);



if(!$stmt){

    die("Attempt Query Error: ".$conn->error);

}



$stmt->bind_param(

"iii",

$user_id,

$exam_id,

$exam['total_questions']

);



$stmt->execute();



$attempt_id = $conn->insert_id;




// ===============================
// STORE SESSION
// ===============================


$_SESSION['attempt_id'] = $attempt_id;

$_SESSION['exam_id'] = $exam_id;

$_SESSION['exam_start_time'] = time();




// ===============================
// PAGE DISPLAY
// ===============================

?>


<!DOCTYPE html>

<html lang="en">

<head>


<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">


<title>Start Mock Examination</title>


<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">


<style>


*{

margin:0;
padding:0;
box-sizing:border-box;
font-family:'Poppins',sans-serif;

}



body{

background:#f4f7fc;

}



.container{

width:90%;

max-width:750px;

margin:50px auto;

}



.card{

background:white;

padding:35px;

border-radius:20px;

box-shadow:0 8px 20px rgba(0,0,0,.08);

}



.card h1{

color:#1d3557;

margin-bottom:15px;

}



.card p{

color:#555;

line-height:1.6;

}




.info-box{

background:#f8fafc;

padding:20px;

border-radius:15px;

margin:25px 0;

}



.info-box p{

margin-bottom:10px;

}



.info-box strong{

color:#1d3557;

}




.instruction-box{

margin-top:20px;

}



.start-btn{


display:block;

text-align:center;

background:#1d3557;

color:white;

padding:14px;

border-radius:12px;

text-decoration:none;

margin-top:30px;

font-weight:600;

transition:.3s;


}



.start-btn:hover{

background:#457b9d;

}



</style>


</head>



<body>


<div class="container">


<div class="card">



<h1>

📝 <?= htmlspecialchars($exam['title']); ?>

</h1>



<p>

<?= htmlspecialchars($exam['description']); ?>

</p>





<div class="info-box">


<p>

<strong>Category:</strong>

<?= htmlspecialchars($exam['category_name']); ?>

</p>



<p>

<strong>Total Questions:</strong>

<?= $exam['total_questions']; ?>

</p>



<p>

<strong>Time Limit:</strong>

<?= $exam['duration']; ?> minutes

</p>



<p>

<strong>Passing Score:</strong>

<?= $exam['passing_score']; ?>%

</p>



</div>





<div class="instruction-box">


<h3>

Instructions

</h3>


<p>

<?= nl2br(htmlspecialchars($exam['instructions'])); ?>

</p>


</div>





<a href="take_mockexam.php"

class="start-btn">


START EXAM


</a>



</div>


</div>



</body>


</html>