<?php

session_start();
require_once "../connection.php";

// =====================================
// USER LOGIN
// =====================================

if(!isset($_SESSION["user_id"])){

    header("Location: ../login.php");
    exit();

}

$user_id = $_SESSION["user_id"];

// =====================================
// SEARCH
// =====================================

$search = "";

if(isset($_GET["search"])){

    $search = trim($_GET["search"]);

}

// =====================================
// CATEGORY FILTER
// =====================================

$category_filter = "";

if(isset($_GET["category"])){

    $category_filter = intval($_GET["category"]);

}

// =====================================
// LOAD CATEGORIES
// =====================================

$categories = mysqli_query($conn,"

SELECT

category_id,
category_name

FROM categories

WHERE status='Active'

ORDER BY category_name ASC

");

// =====================================
// LOAD REVIEW MATERIALS
// =====================================

$sql = "

SELECT

rm.material_id,
rm.title,
rm.description,
rm.file_name,
rm.uploaded_at,

c.category_id,
c.category_name,

rp.status AS progress_status

FROM review_materials rm

INNER JOIN categories c

ON rm.category_id=c.category_id

LEFT JOIN review_progress rp

ON rp.material_id=rm.material_id
AND rp.user_id=?

WHERE rm.status='Active'

";

if($category_filter!=""){

    $sql.=" AND rm.category_id=? ";

}

if($search!=""){

    $sql.="

    AND
    (
        rm.title LIKE ?
        OR rm.description LIKE ?
        OR c.category_name LIKE ?
    )

    ";

}

$sql.="

ORDER BY

c.category_name ASC,

rm.uploaded_at DESC

";

$stmt=mysqli_prepare($conn,$sql);

// =====================================
// BIND PARAMETERS
// =====================================

if($category_filter!="" && $search!=""){

    $like="%".$search."%";

    mysqli_stmt_bind_param(

        $stmt,

        "iisss",

        $user_id,

        $category_filter,

        $like,

        $like,

        $like

    );

}

elseif($category_filter!=""){

    mysqli_stmt_bind_param(

        $stmt,

        "ii",

        $user_id,

        $category_filter

    );

}

elseif($search!=""){

    $like="%".$search."%";

    mysqli_stmt_bind_param(

        $stmt,

        "isss",

        $user_id,

        $like,

        $like,

        $like

    );

}

else{

    mysqli_stmt_bind_param(

        $stmt,

        "i",

        $user_id

    );

}

mysqli_stmt_execute($stmt);

$materials=mysqli_stmt_get_result($stmt);

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport"
content="width=device-width, initial-scale=1.0">

<title>Review Materials</title>

<link
href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap"
rel="stylesheet">

<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>

*{
    margin:0;
    padding:0;
    box-sizing:border-box;
}

body{

    background:#edf2fb;
    font-family:'Poppins',sans-serif;

}

/* ==========================
MAIN
========================== */

.main{

    margin-left:230px;
    width:calc(100% - 230px);
    min-height:100vh;
    padding:30px;

}

/* ==========================
PAGE HEADER
========================== */

.page-header{

    background:#fff;
    border-radius:18px;
    padding:25px 30px;
    margin-bottom:25px;
    box-shadow:0 4px 15px rgba(0,0,0,.08);

}

.page-header h1{

    font-size:32px;
    color:#111827;

}

.page-header p{

    margin-top:5px;
    color:#6b7280;

}

/* ==========================
FILTER CARD
========================== */

.filter-card{

    background:#fff;
    border-radius:18px;
    padding:20px;
    margin-bottom:25px;
    box-shadow:0 4px 15px rgba(0,0,0,.08);

}

.filter-form{

    display:grid;
    grid-template-columns:2fr 1fr auto;
    gap:15px;

}

.filter-form input,
.filter-form select{

    height:48px;
    border:1px solid #d1d5db;
    border-radius:10px;
    padding:0 15px;
    font-family:'Poppins',sans-serif;
    font-size:14px;

}

.btn{

    border:none;
    border-radius:10px;
    padding:12px 18px;
    cursor:pointer;
    font-family:'Poppins',sans-serif;
    font-weight:600;
    transition:.25s;

}

.btn-search{

    background:#2563eb;
    color:white;

}

.btn-search:hover{

    background:#1d4ed8;

}

/* ==========================
GRID
========================== */

.material-grid{

    display:grid;
    grid-template-columns:repeat(auto-fill,minmax(340px,1fr));
    gap:22px;

}

/* ==========================
CARD
========================== */

.card{

    background:white;
    border-radius:18px;
    overflow:hidden;
    box-shadow:0 4px 15px rgba(0,0,0,.08);
    display:flex;
    flex-direction:column;

}

.card-top{

    padding:25px;

}

.file-icon{

    width:65px;
    height:65px;
    border-radius:16px;
    background:#eff6ff;
    display:flex;
    align-items:center;
    justify-content:center;
    color:#2563eb;
    font-size:30px;
    margin-bottom:20px;

}

.card h3{

    color:#111827;
    font-size:21px;
    margin-bottom:10px;

}

.card p{

    color:#6b7280;
    font-size:14px;
    line-height:1.6;
    margin-bottom:18px;

}

.meta{

    color:#64748b;
    font-size:13px;
    margin-bottom:6px;

}

/* ==========================
BADGES
========================== */

.badge{

    display:inline-block;
    padding:6px 14px;
    border-radius:999px;
    font-size:12px;
    font-weight:600;

}

.not{

    background:#dbeafe;
    color:#1d4ed8;

}

.progress{

    background:#fef3c7;
    color:#92400e;

}

.completed{

    background:#dcfce7;
    color:#166534;

}

/* ==========================
CARD FOOTER
========================== */

.card-footer{

    margin-top:auto;
    border-top:1px solid #e5e7eb;
    padding:20px;

}

.btn-view{

    display:block;
    width:100%;
    text-align:center;
    text-decoration:none;
    background:#2563eb;
    color:white;
    padding:12px;
    border-radius:10px;
    font-weight:600;
    transition:.25s;

}

.btn-view:hover{

    background:#1d4ed8;

}

/* ==========================
EMPTY
========================== */

.empty{

    background:white;
    border-radius:18px;
    padding:70px;
    text-align:center;
    box-shadow:0 4px 15px rgba(0,0,0,.08);

}

.empty i{

    font-size:60px;
    color:#2563eb;
    margin-bottom:20px;

}

.empty h2{

    color:#111827;
    margin-bottom:10px;

}

.empty p{

    color:#6b7280;

}

/* ==========================
RESPONSIVE
========================== */

@media(max-width:992px){

.main{

    margin-left:0;
    width:100%;
    padding:85px 20px 20px;

}

.filter-form{

    grid-template-columns:1fr;

}

}

</style>

</head>

<body>

<?php include "user_sidebar.php"; ?>

<div class="main">

<div class="page-header">

<h1>Review Materials</h1>

<p>

Browse all available review materials uploaded by the administrator.

</p>

</div>
    
    <!-- ==========================
FILTERS
========================== -->

<div class="filter-card">

<form
method="GET"
class="filter-form">

<input

type="text"

name="search"

placeholder="Search review materials..."

value="<?php echo htmlspecialchars($search); ?>">

<select name="category">

<option value="">

All Categories

</option>

<?php

mysqli_data_seek($categories,0);

while($cat=mysqli_fetch_assoc($categories)){

?>

<option

value="<?php echo $cat['category_id']; ?>"

<?php

if($category_filter==$cat['category_id']){

echo "selected";

}

?>

>

<?php echo htmlspecialchars($cat['category_name']); ?>

</option>

<?php

}

?>

</select>

<button

type="submit"

class="btn btn-search">

<i class="fa-solid fa-magnifying-glass"></i>

Search

</button>

</form>

</div>

<!-- ==========================
REVIEW MATERIALS
========================== -->

<div class="material-grid">

<?php

if(mysqli_num_rows($materials)>0){

while($row=mysqli_fetch_assoc($materials)){

// ==========================
// FILE ICON
// ==========================

$ext = strtolower(pathinfo($row["file_name"],PATHINFO_EXTENSION));

$icon="fa-file";

switch($ext){

case "pdf":
$icon="fa-file-pdf";
break;

case "doc":
case "docx":
$icon="fa-file-word";
break;

case "ppt":
case "pptx":
$icon="fa-file-powerpoint";
break;

case "xls":
case "xlsx":
$icon="fa-file-excel";
break;

}

// ==========================
// PROGRESS BADGE
// ==========================

$status=$row["progress_status"];

if(empty($status)){

$status="Not Started";
$badge="not";

}

elseif($status=="In Progress"){

$badge="progress";

}

else{

$badge="completed";

}

?>

<div class="card">

<div class="card-top">

<div class="file-icon">

<i class="fa-solid <?php echo $icon; ?>"></i>

</div>

<h3>

<?php echo htmlspecialchars($row["title"]); ?>

</h3>

<p>

<?php echo nl2br(htmlspecialchars($row["description"])); ?>

</p>

<div class="meta">

<strong>Category:</strong>

<?php echo htmlspecialchars($row["category_name"]); ?>

</div>

<div class="meta">

<strong>Uploaded:</strong>

<?php echo date("F d, Y",strtotime($row["uploaded_at"])); ?>

</div>

<br>

<span class="badge <?php echo $badge; ?>">

<?php echo $status; ?>

</span>

</div>

<div class="card-footer">

<a

class="btn-view"

href="view_material.php?id=<?php echo $row['material_id']; ?>">

<i class="fa-solid fa-book-open"></i>

View Material

</a>

</div>

</div>

<?php

}

}else{

?>

<div class="empty">

<i class="fa-solid fa-book-open"></i>

<h2>

No Review Materials Available

</h2>

<p>

There are currently no review materials uploaded by the administrator.

</p>

</div>

<?php

}

?>

</div>
    
    </div>

</body>

</html>