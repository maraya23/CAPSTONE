<?php

error_reporting(E_ALL);
ini_set('display_errors',1);

session_start();

require_once "../connection.php";


// ==================================
// CHECK USER LOGIN
// ==================================

if(!isset($_SESSION["user_id"])){

    header("Location: ../login.php");
    exit();

}


$user_id = $_SESSION["user_id"];




// ==================================
// GET USER INFORMATION
// ==================================

$sql = "

SELECT

firstname,
surname

FROM logintbl

WHERE id=?

";


$stmt=mysqli_prepare($conn,$sql);


mysqli_stmt_bind_param(

$stmt,

"i",

$user_id

);


mysqli_stmt_execute($stmt);


$result=mysqli_stmt_get_result($stmt);



$user=mysqli_fetch_assoc($result);



if($user){


    $fullname =
    $user["firstname"]." ".$user["surname"];


}else{


    $fullname="Student";


}






// ==================================
// GET USER E-PERMIT
// ==================================

$sql="

SELECT


ep.permit_id,

ep.permit_number,

ep.exam_schedule,

ep.issued_date,


e.title,

e.exam_type,

e.duration,

e.total_questions,


e.passing_score


FROM e_permits ep



INNER JOIN exams e

ON ep.exam_id=e.exam_id



WHERE ep.user_id=?



ORDER BY ep.issued_date DESC



";



$stmt=mysqli_prepare($conn,$sql);



mysqli_stmt_bind_param(

$stmt,

"i",

$user_id

);



mysqli_stmt_execute($stmt);



$permits=mysqli_stmt_get_result($stmt);



?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">


<title>E-Permit - e-Nurse</title>



<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">


<link rel="stylesheet"

href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css">



<style>


*{

    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;

}



body{

    background:#f4f7fc;

}





/* =========================
MAIN CONTENT
========================= */


.main-content{

    margin-left:230px;

    padding:30px;

    min-height:100vh;

}






/* =========================
HEADER
========================= */


.page-header{

    margin-bottom:30px;

}



.page-header h1{


    font-size:32px;

    color:#0A2F73;

}



.page-header p{


    margin-top:5px;

    color:#6b7280;

}







/* =========================
PERMIT CARD
========================= */


.permit-container{


    display:flex;

    justify-content:center;

}





.permit-card{


    width:850px;

    background:white;

    border-radius:20px;

    padding:35px;

    box-shadow:

    0 10px 30px rgba(0,0,0,.08);

    position:relative;

}





.permit-header{


    text-align:center;

    border-bottom:2px solid #e5e7eb;

    padding-bottom:20px;

    margin-bottom:25px;

}




.logo-text{


    font-size:32px;

    font-weight:700;

    color:#0A2F73;

}



.logo-text span{


    color:#2563eb;

}





.permit-header h2{


    margin-top:10px;

    color:#111827;

}





.permit-header p{


    color:#6b7280;

    font-size:14px;

}








/* =========================
DETAILS
========================= */


.details-grid{


    display:grid;

    grid-template-columns:repeat(2,1fr);

    gap:20px;

    margin-top:25px;

}




.detail-box{


    background:#f8fafc;

    padding:18px;

    border-radius:14px;


}




.detail-box label{


    display:block;

    color:#6b7280;

    font-size:13px;

    margin-bottom:5px;

}



.detail-box strong{


    color:#111827;

    font-size:16px;

}






/* =========================
PERMIT NUMBER
========================= */


.permit-number{


    margin:25px 0;

    background:#eff6ff;

    border:2px dashed #2563eb;

    padding:18px;

    border-radius:15px;

    text-align:center;

}



.permit-number span{


    display:block;

    color:#6b7280;

    font-size:13px;

}



.permit-number strong{


    font-size:25px;

    color:#2563eb;

}






/* =========================
BUTTON
========================= */


.print-btn{


    margin-top:30px;

    background:#2563eb;

    color:white;

    padding:13px 25px;

    border:none;

    border-radius:12px;

    cursor:pointer;

    font-weight:600;

}



.print-btn:hover{


    background:#1d4ed8;

}






/* EMPTY */

.empty-state{


    background:white;

    padding:50px;

    border-radius:20px;

    text-align:center;

}



.empty-state i{


    font-size:60px;

    color:#2563eb;

    margin-bottom:15px;

}



.empty-state h3{


    color:#0A2F73;

}



.empty-state p{


    color:#6b7280;

}





/* MOBILE */


@media(max-width:768px){


.main-content{


    margin-left:0;

    padding:85px 15px 20px;

}




.permit-card{


    width:100%;

    padding:20px;

}



.details-grid{


    grid-template-columns:1fr;

}



.logo-text{


    font-size:26px;

}



}

/* ==========================
   PRINT DESIGN
========================== */

@media print{


    body{

        background:white;

    }



    .sidebar{

        display:none !important;

    }



    .main-content{


        margin-left:0;

        padding:0;

    }



    .page-header{

        display:none;

    }



    .print-btn{

        display:none;

    }



    .permit-container{


        display:block;

    }



    .permit-card{


        width:100%;

        box-shadow:none;

        border:2px solid #0A2F73;

        border-radius:0;

        margin:0 auto;

    }



    .detail-box{


        background:#f8fafc;

    }



}


</style>


</head>
    
    <body>


<?php include "user_sidebar.php"; ?>



<div class="main-content">





<!-- =========================
        PAGE HEADER
========================= -->


<div class="page-header">


<h1>

<i class="fa-solid fa-id-card"></i>

My E-Permit

</h1>



<p>

Your examination permit for e-Nurse mock examinations.

</p>



</div>








<?php



if(mysqli_num_rows($permits)>0){



while($permit=mysqli_fetch_assoc($permits)){



?>





<div class="permit-container">



<div class="permit-card" id="permit">







<!-- HEADER -->


<div class="permit-header">


<div class="logo-text">

e-<span>Nurse</span>

</div>



<h2>

Examination Permit

</h2>



<p>

Online Nursing Review and Mock Examination System

</p>



</div>









<!-- PERMIT NUMBER -->


<div class="permit-number">


<span>

Permit Number

</span>



<strong>

<?= htmlspecialchars($permit["permit_number"]); ?>

</strong>



</div>









<!-- DETAILS -->


<div class="details-grid">





<div class="detail-box">


<label>

Student Name

</label>


<strong>

<?= htmlspecialchars($fullname); ?>

</strong>


</div>








<div class="detail-box">


<label>

Examination

</label>


<strong>

<?= htmlspecialchars($permit["title"]); ?>

</strong>


</div>








<div class="detail-box">


<label>

Exam Type

</label>


<strong>


<?= htmlspecialchars($permit["exam_type"]); ?>


</strong>


</div>








<div class="detail-box">


<label>

Exam Schedule

</label>


<strong>


<?= date(

"F d, Y",

strtotime($permit["exam_schedule"])

); ?>


</strong>


</div>








<div class="detail-box">


<label>

Duration

</label>


<strong>


<?= $permit["duration"]; ?>

Minutes


</strong>


</div>








<div class="detail-box">


<label>

Total Questions

</label>


<strong>


<?= $permit["total_questions"]; ?>


</strong>


</div>








<div class="detail-box">


<label>

Passing Score

</label>


<strong>


<?= $permit["passing_score"]; ?>%


</strong>


</div>








<div class="detail-box">


<label>

Issued Date

</label>


<strong>


<?= date(

"F d, Y",

strtotime($permit["issued_date"])

); ?>


</strong>


</div>





</div>









<!-- PRINT BUTTON -->


<div style="display:flex; gap:15px;">


<button

class="print-btn"

onclick="window.print()">

<i class="fa-solid fa-print"></i>

Print Permit

</button>




<a

href="user_dashboard.php"

class="print-btn"

style="text-decoration:none; background:#0A2F73;">

<i class="fa-solid fa-arrow-left"></i>

Back

</a>



</div>








</div>



</div>






<?php



}



}else{



?>






<div class="empty-state">



<i class="fa-solid fa-file-circle-xmark"></i>



<h3>

No E-Permit Available

</h3>



<p>

You don't have any examination permit yet.

Please wait for the administrator to issue your permit.

</p>



</div>






<?php



}



?>






</div>



</body>

</html>