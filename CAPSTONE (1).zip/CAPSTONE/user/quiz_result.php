<?php

error_reporting(E_ALL);
ini_set('display_errors',1);

session_start();



if(!isset($_SESSION['user_id'])){

    header("Location: ../login.php");
    exit();

}



include "../connection.php";
$user_id=$_SESSION['user_id'];





// CHECK QUIZ DATA


if(!isset($_SESSION['quiz_questions'])

||

!isset($_SESSION['quiz_answers'])){


    header("Location: user_practicequizzes.php");

    exit();

}





$questions = $_SESSION['quiz_questions'];

$answers = $_SESSION['quiz_answers'];





$total_questions = count($questions);


$score = 0;





// CHECK ANSWERS


foreach($questions as $index=>$question)
$selected = null;


if(isset($answers[$index])){

    $selected=$answers[$index];

}


$is_correct=0;


if($selected==$question['correct_answer']){

    $is_correct=1;

}



$answer_sql="

INSERT INTO exam_answers

(
attempt_id,
question_id,
selected_answer,
correct_answer,
is_correct
)

VALUES

(
?,
?,
?,
?,
?
)

";



$stmt=$conn->prepare($answer_sql);



$stmt->bind_param(

"iissi",

$attempt_id,
$question['question_id'],
$selected,
$question['correct_answer'],
$is_correct

);



$stmt->execute();{



    if(isset($answers[$index])){


        if($answers[$index] == $question['correct_answer']){


            $score++;


        }


    }


}






$percentage = ($score / $total_questions) * 100;





if($percentage >= 75){

    $status="PASSED";
// SAVE QUIZ ATTEMPT


$exam_id = 0;


// FIND PRACTICE EXAM

$find_exam = "

SELECT exam_id

FROM exams

WHERE category_id=?

AND exam_type='Practice Quiz'

AND status='Published'

LIMIT 1

";



$stmt=$conn->prepare($find_exam);

$stmt->bind_param(
"i",
$category_id
);

$stmt->execute();


$exam_result=$stmt->get_result();



if($exam_result->num_rows>0){

    $exam=$exam_result->fetch_assoc();

    $exam_id=$exam['exam_id'];

}






// INSERT ATTEMPT


$attempt_sql="

INSERT INTO exam_attempts

(
user_id,
exam_id,
start_time,
end_time,
score,
total_questions,
percentage,
remarks
)

VALUES

(
?,
?,
NOW(),
NOW(),
?,
?,
?,
?
)

";



$stmt=$conn->prepare($attempt_sql);


$remarks = ucfirst(strtolower($status));



$stmt->bind_param(

"iiiiids",

$user_id,
$exam_id,
$score,
$total_questions,
$percentage,
$remarks

);



$stmt->execute();



$attempt_id=$conn->insert_id;
    
}else{

    $status="FAILED";

}






// GET CATEGORY NAME


$category_name="Practice Quiz";



if(isset($questions[0]['category_id'])){


    $category_id=$questions[0]['category_id'];



    $cat_query="

    SELECT category_name

    FROM categories

    WHERE category_id=?

    ";



    $stmt=$conn->prepare($cat_query);


    $stmt->bind_param("i",$category_id);


    $stmt->execute();



    $cat_result=$stmt->get_result();



    if($cat_result->num_rows>0){


        $cat=$cat_result->fetch_assoc();


        $category_name=$cat['category_name'];


    }


}




?>



<!DOCTYPE html>

<html>

<head>


<title>Quiz Result</title>



<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">



<style>


*{

margin:0;
padding:0;
box-sizing:border-box;
font-family:'Poppins',sans-serif;

}



body{

background:#f4f7fc;

}



.container{


width:90%;

max-width:600px;

margin:60px auto;


}



.result-box{


background:white;

padding:40px;

border-radius:20px;

box-shadow:0 8px 20px rgba(0,0,0,.1);

text-align:center;


}




.icon{


font-size:60px;

margin-bottom:20px;

}




h1{

color:#1d3557;

margin-bottom:15px;

}




.quiz-name{

color:#666;

margin-bottom:30px;

}




.score{


font-size:45px;

font-weight:700;

color:#457b9d;

margin-bottom:10px;

}





.status{


display:inline-block;

padding:10px 25px;

border-radius:30px;

font-weight:600;

margin-top:20px;

}




.pass{


background:#dcfce7;

color:#15803d;

}



.fail{


background:#fee2e2;

color:#b91c1c;

}




.details{


margin-top:30px;

text-align:left;

background:#f8fafc;

padding:20px;

border-radius:15px;

}



.details p{

margin-bottom:10px;

}




.btn{


display:block;

margin-top:30px;

padding:13px;

background:#1d3557;

color:white;

text-decoration:none;

border-radius:12px;

}




.btn:hover{

background:#457b9d;

}



</style>



</head>


<body>



<div class="container">


<div class="result-box">





<div class="icon">


<?php

if($status=="PASSED"){

echo "🎉";

}else{

echo "📚";

}

?>


</div>





<h1>

Quiz Completed!

</h1>





<div class="quiz-name">


<?php echo htmlspecialchars($category_name); ?>


</div>





<div class="score">


<?php echo $score; ?>

/

<?php echo $total_questions; ?>


</div>





<p>

Percentage:

<b>

<?php echo number_format($percentage,2); ?>%

</b>

</p>






<div class="status 

<?php echo ($status=="PASSED")?'pass':'fail'; ?>">



<?php echo $status; ?>


</div>






<div class="details">


<p>

<strong>Total Questions:</strong>

<?php echo $total_questions; ?>

</p>


<p>

<strong>Correct Answers:</strong>

<?php echo $score; ?>

</p>


<p>

<strong>Passing Score:</strong>

75%

</p>



</div>







<a class="btn"

href="user_practicequizzes.php">


Back to Practice Quiz


</a>





</div>



</div>





<?php


// CLEAR QUIZ SESSION


unset($_SESSION['quiz_questions']);

unset($_SESSION['quiz_answers']);

unset($_SESSION['quiz_current']);



?>



</body>

</html>