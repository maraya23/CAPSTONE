<?php

error_reporting(E_ALL);
ini_set('display_errors',1);

session_start();

require_once "../connection.php";


// ===============================
// CHECK LOGIN
// ===============================

if(!isset($_SESSION['user_id'])){

    header("Location: ../login.php");
    exit();

}


$user_id = $_SESSION['user_id'];



// ===============================
// CHECK EXAM SESSION
// ===============================

if(!isset($_SESSION['exam_id']) || !isset($_SESSION['attempt_id'])){


    header("Location: user_mockexamination.php");

    exit();

}



$exam_id = $_SESSION['exam_id'];

$attempt_id = $_SESSION['attempt_id'];




// ===============================
// LOAD QUESTIONS
// ===============================


if(!isset($_SESSION['exam_questions'])){


$sql = "

SELECT


q.question_id,

q.question,

q.option_a,

q.option_b,

q.option_c,

q.option_d,

q.correct_answer,

c.category_name


FROM exam_items ei


INNER JOIN questions q

ON ei.question_id = q.question_id


INNER JOIN categories c

ON q.category_id = c.category_id


WHERE ei.exam_id = ?


ORDER BY ei.exam_item_id ASC


";



$stmt=$conn->prepare($sql);



$stmt->bind_param(
"i",
$exam_id
);



$stmt->execute();



$result=$stmt->get_result();



$questions=[];


while($row=$result->fetch_assoc()){


    $questions[]=$row;


}



$_SESSION['exam_questions']=$questions;



}



$questions=$_SESSION['exam_questions'];





$total_questions=count($questions);



// ===============================
// CHECK QUESTIONS
// ===============================


if($total_questions==0){


    die("No questions found for this examination.");


}






// ===============================
// STORE ANSWERS
// ===============================


if(!isset($_SESSION['answers'])){

    $_SESSION['answers']=[];

}






// ===============================
// CURRENT QUESTION
// ===============================


$current = isset($_GET['q'])

? intval($_GET['q'])

:1;



if($current<1){

    $current=1;

}


if($current>$total_questions){

    $current=$total_questions;

}






// ===============================
// SAVE ANSWER
// ===============================


if($_SERVER["REQUEST_METHOD"]=="POST"){



    if(isset($_POST['answer'])){


        $_SESSION['answers'][$current]=$_POST['answer'];


    }





    if(isset($_POST['next'])){


        header(
        "Location: take_mockexam.php?q=".($current+1)
        );


        exit();


    }



    if(isset($_POST['previous'])){


        header(
        "Location: take_mockexam.php?q=".($current-1)
        );


        exit();


    }



}




$question=$questions[$current-1];


?>

<!DOCTYPE html>

<html lang="en">

<head>


<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">


<title>Mock Examination</title>



<link rel="stylesheet"

href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">


<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">



<style>


*{

margin:0;

padding:0;

box-sizing:border-box;

font-family:'Poppins',sans-serif;

}



body{

background:#f3f6fb;

}



/* MAIN CONTENT */

.main-content{

margin-left:250px;

padding:30px;

min-height:100vh;

}





/* TOP BAR */

.top-bar{

display:flex;

justify-content:space-between;

align-items:center;

background:white;

padding:18px 25px;

border-radius:15px;

box-shadow:0 5px 18px rgba(0,0,0,.08);

margin-bottom:25px;

}





.timer-box{


background:#eaf2ff;

color:#1d4ed8;

padding:10px 18px;

border-radius:10px;

font-weight:600;

}



.timer-box i{

margin-right:8px;

}





.question-count{


font-size:18px;

font-weight:600;

color:#333;

}





.submit-btn{


background:#22c55e;

color:white;

border:none;

padding:12px 22px;

border-radius:10px;

font-weight:600;

cursor:pointer;

}




.submit-btn:hover{

background:#16a34a;

}





/* EXAM AREA */


.exam-container{


display:grid;

grid-template-columns:280px 1fr;

gap:25px;

}





/* NAVIGATOR */


.navigator{


background:white;

padding:20px;

border-radius:15px;

box-shadow:0 5px 18px rgba(0,0,0,.08);

}



.navigator h3{


color:#1d3557;

margin-bottom:20px;

}





.number-grid{


display:grid;

grid-template-columns:repeat(5,1fr);

gap:10px;


}



.number-grid a{


height:40px;

width:40px;

display:flex;

justify-content:center;

align-items:center;

text-decoration:none;

border-radius:10px;

background:#eef2f7;

color:#555;

font-weight:600;

}



.number-grid a.current{


background:#2563eb;

color:white;

}



.number-grid a.answered{


background:#16a34a;

color:white;

}





/* QUESTION CARD */


.question-card{


background:white;

padding:30px;

border-radius:15px;

box-shadow:0 5px 18px rgba(0,0,0,.08);

}





.category{


color:#2563eb;

font-weight:600;

margin-bottom:15px;

}





.question-card h2{


font-size:22px;

line-height:1.5;

margin-bottom:25px;

color:#222;


}





/* OPTIONS */


.choice{


display:flex;

gap:12px;

background:#f8fafc;

padding:16px;

border-radius:10px;

margin-bottom:15px;

border:2px solid transparent;

cursor:pointer;

transition:.3s;


}



.choice:hover{


border-color:#2563eb;

background:#eef4ff;


}



.choice input{


margin-top:5px;

transform:scale(1.2);

}





/* BUTTONS */


.button-group{


display:flex;

justify-content:space-between;

margin-top:30px;


}



.prev-btn,


.next-btn{


border:none;

padding:12px 25px;

border-radius:10px;

color:white;

cursor:pointer;

font-weight:600;

}



.prev-btn{


background:#64748b;


}



.next-btn{


background:#2563eb;


}



.prev-btn:hover{

background:#475569;

}



.next-btn:hover{

background:#1d4ed8;

}





/* MOBILE */


@media(max-width:768px){


.main-content{


margin-left:0;

padding:80px 15px 20px;


}



.top-bar{


flex-direction:column;

gap:15px;


}



.exam-container{


grid-template-columns:1fr;


}



.navigator{


order:2;

}



.question-card{


order:1;

}


}



</style>


</head>
    
    <body>


<?php include "user_sidebar.php"; ?>



<div class="main-content">



<!-- ==========================
        TOP BAR
=========================== -->


<div class="top-bar">



<div class="timer-box">

<i class="fa-solid fa-clock"></i>

<span id="timer">

00:00:00

</span>

</div>





<div class="question-count">


Question

<strong>

<?= $current; ?>

</strong>


of


<strong>

<?= $total_questions; ?>

</strong>


</div>






<form action="submit_mockexam.php"

method="POST"

id="submitExamForm">



<button

type="submit"

class="submit-btn">


<i class="fa-solid fa-paper-plane"></i>

Submit Exam


</button>


</form>




</div>






<div class="exam-container">





<!-- ==========================
        QUESTION NAVIGATOR
=========================== -->


<div class="navigator">


<h3>

Question Navigator

</h3>




<div class="number-grid">


<?php


for($i=1;$i<=$total_questions;$i++){


$class="";



if($i==$current){

$class="current";

}

elseif(isset($_SESSION['answers'][$i])){


$class="answered";


}



?>


<a href="take_mockexam.php?q=<?= $i; ?>"

class="<?= $class; ?>">


<?= $i; ?>


</a>



<?php


}


?>



</div>



</div>







<!-- ==========================
        QUESTION AREA
=========================== -->



<div class="question-card">





<div class="category">


<i class="fa-solid fa-book"></i>


Category:


<strong>


<?= htmlspecialchars($question['category_name']); ?>


</strong>


</div>







<h2>


<?= htmlspecialchars($question['question']); ?>


</h2>







<form method="POST">





<label class="choice">


<input

type="radio"

name="answer"

value="A"

<?=

(($_SESSION['answers'][$current] ?? '')=="A")

?

"checked"

:

"";

?>


>


A.

<?= htmlspecialchars($question['option_a']); ?>


</label>







<label class="choice">


<input

type="radio"

name="answer"

value="B"


<?=

(($_SESSION['answers'][$current] ?? '')=="B")

?

"checked"

:

"";

?>


>


B.

<?= htmlspecialchars($question['option_b']); ?>


</label>








<label class="choice">


<input

type="radio"

name="answer"

value="C"



<?=

(($_SESSION['answers'][$current] ?? '')=="C")

?

"checked"

:

"";

?>


>


C.

<?= htmlspecialchars($question['option_c']); ?>


</label>








<label class="choice">


<input

type="radio"

name="answer"

value="D"



<?=

(($_SESSION['answers'][$current] ?? '')=="D")

?

"checked"

:

"";

?>


>


D.

<?= htmlspecialchars($question['option_d']); ?>


</label>









<div class="button-group">





<?php if($current > 1){ ?>


<button

type="submit"

name="previous"

class="prev-btn">


<i class="fa-solid fa-arrow-left"></i>


Previous


</button>



<?php }else{ ?>


<div></div>


<?php } ?>







<?php if($current < $total_questions){ ?>


<button

type="submit"

name="next"

class="next-btn">


Next


<i class="fa-solid fa-arrow-right"></i>


</button>



<?php } ?>





</div>







</form>






</div>





</div>





</div>
        
        <script>


// ======================================
// EXAM TIMER
// ======================================


// Get exam duration from database (minutes)

let durationMinutes = <?= $exam['duration'] ?? 120; ?>;



let totalSeconds = durationMinutes * 60;



const timer = document.getElementById("timer");





function updateTimer(){



let hours = Math.floor(totalSeconds / 3600);



let minutes = Math.floor(
    (totalSeconds % 3600) / 60
);



let seconds = totalSeconds % 60;




hours = String(hours).padStart(2,'0');

minutes = String(minutes).padStart(2,'0');

seconds = String(seconds).padStart(2,'0');




timer.innerHTML =

hours + ":" + minutes + ":" + seconds;





if(totalSeconds <= 0){



clearInterval(countdown);



alert(
"Time is up! Your examination will be submitted."
);



document.getElementById("submitExamForm").submit();



}





totalSeconds--;



}





updateTimer();



const countdown = setInterval(updateTimer,1000);








// ======================================
// SUBMIT CONFIRMATION
// ======================================


document
.getElementById("submitExamForm")
.addEventListener("submit",function(e){



let confirmSubmit = confirm(

"Are you sure you want to submit your examination?\n\nYou cannot change your answers after submission."

);




if(!confirmSubmit){


e.preventDefault();



}



});








// ======================================
// HIGHLIGHT SELECTED ANSWER
// ======================================



const choices = document.querySelectorAll(".choice");



const radios = document.querySelectorAll(
"input[type='radio']"
);





radios.forEach(function(radio){



radio.addEventListener(
"change",
function(){



choices.forEach(function(choice){


choice.style.background="#f8fafc";


choice.style.borderColor="transparent";



});





this.parentElement.style.background="#eaf2ff";


this.parentElement.style.borderColor="#2563eb";




});



});








// Restore selected answer color after page reload



window.onload=function(){



let selected = document.querySelector(
"input[type='radio']:checked"
);



if(selected){



selected.parentElement.style.background="#eaf2ff";


selected.parentElement.style.borderColor="#2563eb";



}



}



</script>


</body>

</html>