<?php

error_reporting(E_ALL);
ini_set('display_errors',1);

session_start();

require_once "../connection.php";


// ==============================
// CHECK LOGIN
// ==============================

if(!isset($_SESSION["user_id"])){

    header("Location: ../login.php");
    exit();

}


$user_id = $_SESSION["user_id"];



// ==============================
// GET USER INFORMATION
// ==============================


$user_sql = "

SELECT firstname, surname

FROM logintbl

WHERE id=?

";


$stmt = mysqli_prepare($conn,$user_sql);


mysqli_stmt_bind_param(
    $stmt,
    "i",
    $user_id
);


mysqli_stmt_execute($stmt);


$user_result = mysqli_stmt_get_result($stmt);



if(mysqli_num_rows($user_result)>0){

    $user = mysqli_fetch_assoc($user_result);


    $fullname = 
    $user["firstname"]." ".$user["surname"];


}else{


    $fullname = "Student";


}







// ==============================
// SUMMARY:
// TOTAL EXAMS TAKEN
// ==============================


$sql = "

SELECT COUNT(*) AS total

FROM exam_attempts

WHERE user_id=?

";


$stmt=mysqli_prepare($conn,$sql);


mysqli_stmt_bind_param(
    $stmt,
    "i",
    $user_id
);


mysqli_stmt_execute($stmt);


$result=mysqli_stmt_get_result($stmt);


$row=mysqli_fetch_assoc($result);



$totalTests = $row["total"] ?? 0;







// ==============================
// AVERAGE SCORE
// ==============================


$sql="

SELECT AVG(percentage) AS average

FROM exam_attempts

WHERE user_id=?

";


$stmt=mysqli_prepare($conn,$sql);


mysqli_stmt_bind_param(
    $stmt,
    "i",
    $user_id
);


mysqli_stmt_execute($stmt);


$result=mysqli_stmt_get_result($stmt);


$row=mysqli_fetch_assoc($result);



$averageScore = $row["average"] ?? 0;


$averageScore = round($averageScore,2);







// ==============================
// HIGHEST SCORE
// ==============================


$sql="

SELECT MAX(percentage) AS highest

FROM exam_attempts

WHERE user_id=?

";


$stmt=mysqli_prepare($conn,$sql);


mysqli_stmt_bind_param(
    $stmt,
    "i",
    $user_id
);


mysqli_stmt_execute($stmt);


$result=mysqli_stmt_get_result($stmt);


$row=mysqli_fetch_assoc($result);



$highestScore = $row["highest"] ?? 0;


$highestScore = round($highestScore,2);







// ==============================
// LAST ACTIVITY
// ==============================


$sql="

SELECT end_time

FROM exam_attempts

WHERE user_id=?

ORDER BY end_time DESC

LIMIT 1

";


$stmt=mysqli_prepare($conn,$sql);


mysqli_stmt_bind_param(
    $stmt,
    "i",
    $user_id
);


mysqli_stmt_execute($stmt);


$result=mysqli_stmt_get_result($stmt);



$row=mysqli_fetch_assoc($result);



if($row && $row["end_time"]!=NULL){


    $lastActivity =
    date(
        "M d, Y",
        strtotime($row["end_time"])
    );


}else{


    $lastActivity="No Activity";


}







// ==============================
// RESULTS HISTORY
// ==============================


$sql="

SELECT

ea.attempt_id,

e.title,

e.exam_type,

ea.score,

ea.total_questions,

ea.percentage,

ea.remarks,

ea.end_time


FROM exam_attempts ea


INNER JOIN exams e

ON ea.exam_id = e.exam_id


WHERE ea.user_id=?


ORDER BY ea.end_time DESC


";



$stmt=mysqli_prepare($conn,$sql);


mysqli_stmt_bind_param(
    $stmt,
    "i",
    $user_id
);


mysqli_stmt_execute($stmt);


$history=mysqli_stmt_get_result($stmt);







// ==============================
// RECENT RESULT
// ==============================


$sql="

SELECT

e.title,

ea.percentage,

ea.remarks


FROM exam_attempts ea


INNER JOIN exams e

ON ea.exam_id=e.exam_id


WHERE ea.user_id=?


ORDER BY ea.end_time DESC


LIMIT 1

";



$stmt=mysqli_prepare($conn,$sql);


mysqli_stmt_bind_param(
    $stmt,
    "i",
    $user_id
);


mysqli_stmt_execute($stmt);


$result=mysqli_stmt_get_result($stmt);



$latest=mysqli_fetch_assoc($result);






// Progress Circle

$circleDegrees =
($averageScore / 100) * 360;



?>

<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">


<title>My Results</title>


<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">


<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.1/css/all.min.css">


<style>
    
    *{
    margin:0;
    padding:0;
    box-sizing:border-box;
    font-family:'Poppins',sans-serif;
}

body{
    background:#f4f7fc;
}


/* ==========================
MAIN CONTENT
========================== */

.main-content{

    margin-left:230px;

    padding:30px;

    min-height:100vh;

}



/* ==========================
PAGE HEADER
========================== */


.page-header{

    background:white;

    padding:30px;

    border-radius:20px;

    margin-bottom:30px;

    box-shadow:0 8px 25px rgba(0,0,0,.08);

}



.page-header h1{

    font-size:32px;

    color:#0A2F73;

    margin-bottom:10px;

}



.page-header h1 i{

    color:#2563eb;

    margin-right:10px;

}



.page-header p{

    color:#6b7280;

    font-size:15px;

}




/* ==========================
SUMMARY GRID
========================== */


.summary-grid{

    display:grid;

    grid-template-columns:repeat(4,1fr);

    gap:20px;

    margin-bottom:30px;

}




.summary-card{


    background:white;

    padding:22px;

    border-radius:18px;

    display:flex;

    align-items:center;

    gap:18px;

    box-shadow:0 8px 25px rgba(0,0,0,.08);

    transition:.3s;


}



.summary-card:hover{

    transform:translateY(-5px);

}




.summary-card h2{

    font-size:28px;

    color:#111827;

}



.summary-card p{

    color:#6b7280;

    font-size:14px;

}




.summary-icon{


    width:65px;

    height:65px;

    border-radius:16px;

    display:flex;

    align-items:center;

    justify-content:center;

    color:white;

    font-size:28px;


}




.blue{

background:#2563eb;

}



.green{

background:#10b981;

}



.orange{

background:#f59e0b;

}



.purple{

background:#7c3aed;

}
    
    /* ==========================
CONTENT GRID
========================== */


.content-grid{

    display:grid;

    grid-template-columns:2fr 1fr;

    gap:25px;

}



/* ==========================
CARD
========================== */


.card{

    background:white;

    border-radius:18px;

    padding:25px;

    box-shadow:0 8px 25px rgba(0,0,0,.08);

}



.card-title{

    margin-bottom:25px;

}



.card-title h2{

    color:#0A2F73;

    font-size:22px;

}



.card-title i{

    color:#2563eb;

    margin-right:8px;

}




/* ==========================
TABLE
========================== */


.table-responsive{

    width:100%;

    overflow-x:auto;

}



table{

    width:100%;

    border-collapse:collapse;

    min-width:850px;

}



thead{

    background:#0A2F73;

}



thead th{

    color:white;

    padding:16px;

    text-align:left;

    font-size:14px;

}



tbody td{

    padding:16px;

    border-bottom:1px solid #eef2f7;

    color:#374151;

    font-size:14px;

}



tbody tr:hover{

    background:#f8fbff;

}



/* ==========================
EXAM TYPE BADGES
========================== */


.exam-badge{


    display:inline-block;

    padding:6px 12px;

    border-radius:20px;

    font-size:13px;

    font-weight:600;


}



.exam-badge.mock{


    background:#dbeafe;

    color:#2563eb;


}



.exam-badge.practice{


    background:#dcfce7;

    color:#16a34a;


}




/* ==========================
SCORE COLORS
========================== */


.excellent{

    color:#2563eb;

    font-weight:700;

}



.passed{

    color:#16a34a;

    font-weight:700;

}



.failed{

    color:#dc2626;

    font-weight:700;

}





/* ==========================
STATUS BADGE
========================== */


.badge{


    display:inline-block;

    padding:7px 15px;

    border-radius:30px;

    font-size:13px;

    font-weight:600;


}



.badge.passed{


    background:#dcfce7;

    color:#15803d;


}



.badge.failed{


    background:#fee2e2;

    color:#dc2626;


}




/* ==========================
VIEW BUTTON
========================== */


.view-btn{


    display:inline-flex;

    align-items:center;

    gap:6px;

    background:#2563eb;

    color:white;

    padding:9px 16px;

    border-radius:10px;

    text-decoration:none;

    font-size:13px;

    font-weight:600;

    transition:.3s;


}



.view-btn:hover{


    background:#1d4ed8;


}




/* ==========================
EMPTY STATE
========================== */


.empty-state{


    text-align:center;

    padding:40px;


}



.empty-state i{


    font-size:55px;

    color:#2563eb;

    margin-bottom:15px;


}



.empty-state h3{


    color:#0A2F73;

    margin-bottom:10px;


}



.empty-state p{


    color:#6b7280;


}
    
    /* ==========================
RIGHT SIDE PANEL
========================== */


.right-section{

    display:flex;

    flex-direction:column;

    gap:25px;

}



/* ==========================
SCORE CIRCLE
========================== */


.card h2{

    color:#0A2F73;

    font-size:20px;

    margin-bottom:20px;

}



.progress-circle{


    width:190px;

    height:190px;

    margin:25px auto;

    border-radius:50%;

    display:flex;

    justify-content:center;

    align-items:center;


}




.circle-inner{


    width:145px;

    height:145px;

    border-radius:50%;


    background:white;


    display:flex;

    justify-content:center;

    align-items:center;


    font-size:30px;

    font-weight:700;


    color:#0A2F73;


    box-shadow:0 5px 15px rgba(0,0,0,.08);


}






/* ==========================
LEGEND
========================== */


.legend{


    margin-top:20px;


}



.legend p{


    display:flex;

    align-items:center;

    gap:10px;

    margin-bottom:12px;

    font-size:14px;

    color:#4b5563;


}



.legend span{


    width:15px;

    height:15px;

    border-radius:50%;

    display:inline-block;


}



.blue-dot{

    background:#2563eb;

}



.green-dot{

    background:#10b981;

}



.red-dot{

    background:#dc2626;

}






/* ==========================
ACHIEVEMENT CARD
========================== */


.achievement-card{


    text-align:center;


}



.trophy{


    font-size:60px;

    color:#f59e0b;

    margin-bottom:15px;


}




.achievement-card h3{


    color:#0A2F73;

    font-size:20px;

    margin-bottom:15px;


}



.achievement-card h1{


    font-size:42px;

    color:#2563eb;

    margin-bottom:10px;


}



.achievement-card p{


    font-weight:600;

    color:#111827;

    margin-bottom:10px;


}



.achievement-card span{


    color:#6b7280;

    font-size:15px;


}
    
    /* ==========================
TABLET RESPONSIVE
========================== */


@media(max-width:992px){


    .summary-grid{


        grid-template-columns:repeat(2,1fr);


    }



    .content-grid{


        grid-template-columns:1fr;


    }



    .right-section{


        display:grid;

        grid-template-columns:repeat(2,1fr);

        gap:20px;


    }


}






/* ==========================
MOBILE RESPONSIVE
========================== */


@media(max-width:768px){



    .main-content{


        margin-left:0;

        padding:80px 15px 20px;


    }




    .page-header{


        padding:22px;

    }



    .page-header h1{


        font-size:26px;


    }




    .summary-grid{


        grid-template-columns:1fr;

        gap:15px;


    }



    .summary-card{


        padding:18px;


    }



    .summary-card h2{


        font-size:24px;


    }




    .summary-icon{


        width:55px;

        height:55px;

        font-size:22px;


    }





    .content-grid{


        display:flex;

        flex-direction:column;


    }





    .card{


        padding:18px;

        border-radius:16px;


    }





    .right-section{


        display:flex;

        flex-direction:column;


    }





    .progress-circle{


        width:160px;

        height:160px;


    }





    .circle-inner{


        width:120px;

        height:120px;


        font-size:24px;


    }





    table{


        min-width:750px;


    }



}







/* ==========================
SMALL PHONE
========================== */


@media(max-width:480px){



    .main-content{


        padding:75px 12px 15px;


    }



    .page-header h1{


        font-size:22px;


    }



    .summary-card{


        padding:15px;


    }



    .summary-card h2{


        font-size:21px;


    }



    .card{


        padding:15px;


    }




    .progress-circle{


        width:140px;

        height:140px;


    }





    .circle-inner{


        width:105px;

        height:105px;


        font-size:21px;


    }




    .achievement-card h1{


        font-size:34px;


    }


}






/* ==========================
SMOOTH EFFECTS
========================== */


.summary-card{


    transition:.3s ease;


}



.card{


    transition:.3s ease;


}



.view-btn{


    transition:.25s;


}


    
    </style>

</head>


<body>


<?php include "user_sidebar.php"; ?>



<div class="main-content">



<!-- =========================
        PAGE HEADER
========================= -->


<div class="page-header">


<h1>

<i class="fa-solid fa-chart-line"></i>

My Results

</h1>


<p>

Welcome back,

<b>

<?= htmlspecialchars($fullname); ?>

</b>


<br>


View your mock examination results and progress.

</p>


</div>







<!-- =========================
        SUMMARY CARDS
========================= -->


<div class="summary-grid">





<!-- TOTAL EXAMS -->


<div class="summary-card">


<div class="summary-icon blue">


<i class="fa-solid fa-file-circle-check"></i>


</div>



<div>


<h2>

<?= $totalTests; ?>

</h2>


<p>

Exams Taken

</p>


</div>



</div>







<!-- AVERAGE -->


<div class="summary-card">


<div class="summary-icon green">


<i class="fa-solid fa-chart-column"></i>


</div>



<div>


<h2>

<?= number_format($averageScore,2); ?>%

</h2>


<p>

Average Score

</p>


</div>



</div>








<!-- HIGHEST -->


<div class="summary-card">


<div class="summary-icon orange">


<i class="fa-solid fa-trophy"></i>


</div>



<div>


<h2>

<?= number_format($highestScore,2); ?>%

</h2>


<p>

Highest Score

</p>


</div>



</div>








<!-- LAST ACTIVITY -->


<div class="summary-card">


<div class="summary-icon purple">


<i class="fa-solid fa-clock"></i>


</div>



<div>


<h2>

<?= $lastActivity; ?>

</h2>


<p>

Last Exam

</p>


</div>



</div>




</div>
    
    <!-- =========================
        RESULTS HISTORY
========================= -->


<div class="content-grid">



<div class="card left-section">



<div class="card-title">


<h2>

<i class="fa-solid fa-list-check"></i>

Results History

</h2>


</div>





<div class="table-responsive">



<table>



<thead>


<tr>

<th>
Date Taken
</th>


<th>
Exam
</th>


<th>
Type
</th>


<th>
Score
</th>


<th>
Percentage
</th>


<th>
Status
</th>


<th>
Action
</th>


</tr>


</thead>



<tbody>


<?php


if(mysqli_num_rows($history)>0){


while($row=mysqli_fetch_assoc($history)){


?>



<tr>


<td>


<?php


if($row["end_time"]){


echo date(
"M d, Y",
strtotime($row["end_time"])
);


}else{


echo "-";


}


?>


</td>





<td>


<i class="fa-solid fa-file-lines"></i>


<?= htmlspecialchars($row["title"]); ?>


</td>





<td>


<?php


if($row["exam_type"]=="Mock Exam"){


echo "

<span class='exam-badge mock'>

Mock Examination

</span>

";


}else{


echo "

<span class='exam-badge practice'>

Practice Quiz

</span>

";


}


?>


</td>





<td>


<?= $row["score"]; ?>

/

<?= $row["total_questions"]; ?>


</td>





<td>


<?php


$percentage =
$row["percentage"];



if($percentage >=90){


$score_class="excellent";


}elseif($percentage>=75){


$score_class="passed";


}else{


$score_class="failed";


}



?>


<span class="<?= $score_class; ?>">


<?= number_format($percentage,2); ?>%


</span>



</td>







<td>


<?php


if($row["remarks"]=="Passed"){


?>


<span class="badge passed">


Passed


</span>


<?php


}else{


?>


<span class="badge failed">


Failed


</span>


<?php


}


?>


</td>








<td>



<a

href="user_resultdetails.php?attempt_id=<?= $row['attempt_id']; ?>"

class="view-btn">


<i class="fa-solid fa-eye"></i>


View


</a>



</td>





</tr>





<?php


}


}else{


?>



<tr>


<td colspan="7">


<div class="empty-state">


<i class="fa-solid fa-folder-open"></i>


<h3>

No Results Yet

</h3>


<p>

Take a mock examination to see your results here.

</p>


</div>



</td>


</tr>



<?php


}



?>



</tbody>


</table>



</div>



</div>
    
    <!-- =========================
        RIGHT SIDE PANEL
========================= -->


<div class="right-section">





<!-- =========================
        SCORE CIRCLE
========================= -->


<div class="card">


<h2>

<i class="fa-solid fa-chart-pie"></i>

Average Performance

</h2>



<div class="progress-circle"

style="background:
conic-gradient(
#2563eb <?= $circleDegrees ?>deg,
#e5e7eb <?= $circleDegrees ?>deg
);">


<div class="circle-inner">


<?= number_format($averageScore,2); ?>%


</div>


</div>





<div class="legend">


<p>

<span class="blue-dot"></span>

Excellent (90-100%)

</p>



<p>

<span class="green-dot"></span>

Passed (75-89%)

</p>



<p>

<span class="red-dot"></span>

Needs Improvement

</p>


</div>



</div>








<!-- =========================
        RECENT ACHIEVEMENT
========================= -->


<div class="card achievement-card">


<i class="fa-solid fa-medal trophy"></i>



<h3>

Recent Achievement

</h3>





<?php if($latest){ ?>



<h1>

<?= number_format($latest["percentage"],2); ?>%

</h1>



<p>

<?= htmlspecialchars($latest["title"]); ?>

</p>




<span>


<?= $latest["remarks"]; ?>


</span>



<?php }else{ ?>



<p>

No completed exams yet.

</p>



<?php } ?>



</div>




</div>


</div>





</div>






<script>


// FILTER ANIMATION

const cards=document.querySelectorAll(".summary-card");


cards.forEach(card=>{


card.addEventListener("mouseenter",()=>{


card.style.transform="translateY(-5px)";


});



card.addEventListener("mouseleave",()=>{


card.style.transform="translateY(0)";


});


});



</script>



</body>


</html>