<?php

error_reporting(E_ALL);
ini_set('display_errors',1);

session_start();

require_once "../connection.php";


// =====================================
// CHECK USER LOGIN
// =====================================

if(!isset($_SESSION["user_id"])){

    header("Location: ../login.php");
    exit();

}


$user_id = $_SESSION["user_id"];




// =====================================
// GET USER INFORMATION
// =====================================

$sql = "

SELECT firstname, surname

FROM logintbl

WHERE id=?

";


$stmt = mysqli_prepare($conn,$sql);


mysqli_stmt_bind_param(
    $stmt,
    "i",
    $user_id
);


mysqli_stmt_execute($stmt);


$result = mysqli_stmt_get_result($stmt);



if(mysqli_num_rows($result)>0){

    $user=mysqli_fetch_assoc($result);


    $fullname =
    $user["firstname"]." ".$user["surname"];


}else{


    $fullname="Student";


}




// =====================================
// TOTAL EXAMS TAKEN
// =====================================

$sql="

SELECT COUNT(*) AS total

FROM exam_attempts

WHERE user_id=?

";


$stmt=mysqli_prepare($conn,$sql);


mysqli_stmt_bind_param(
    $stmt,
    "i",
    $user_id
);


mysqli_stmt_execute($stmt);


$result=mysqli_stmt_get_result($stmt);


$row=mysqli_fetch_assoc($result);


$totalExams=$row["total"] ?? 0;





// =====================================
// OVERALL AVERAGE PERFORMANCE
// =====================================

$sql="

SELECT AVG(percentage) AS average

FROM exam_attempts

WHERE user_id=?

";


$stmt=mysqli_prepare($conn,$sql);


mysqli_stmt_bind_param(
    $stmt,
    "i",
    $user_id
);


mysqli_stmt_execute($stmt);


$result=mysqli_stmt_get_result($stmt);


$row=mysqli_fetch_assoc($result);



$overallProgress=$row["average"] ?? 0;


$overallProgress=round($overallProgress,2);





// =====================================
// PRACTICE QUIZZES TAKEN
// =====================================

$sql="

SELECT COUNT(*) AS total

FROM exam_attempts ea

INNER JOIN exams e

ON ea.exam_id=e.exam_id


WHERE ea.user_id=?

AND e.exam_type='Practice Quiz'

";


$stmt=mysqli_prepare($conn,$sql);


mysqli_stmt_bind_param(
    $stmt,
    "i",
    $user_id
);


mysqli_stmt_execute($stmt);


$result=mysqli_stmt_get_result($stmt);


$row=mysqli_fetch_assoc($result);


$quizTaken=$row["total"] ?? 0;





// =====================================
// MOCK EXAMS TAKEN
// =====================================

$sql="

SELECT COUNT(*) AS total

FROM exam_attempts ea


INNER JOIN exams e

ON ea.exam_id=e.exam_id


WHERE ea.user_id=?

AND e.exam_type='Mock Exam'

";


$stmt=mysqli_prepare($conn,$sql);


mysqli_stmt_bind_param(
    $stmt,
    "i",
    $user_id
);


mysqli_stmt_execute($stmt);


$result=mysqli_stmt_get_result($stmt);


$row=mysqli_fetch_assoc($result);


$mockExams=$row["total"] ?? 0;






// =====================================
// CATEGORY PERFORMANCE
// =====================================

$categoryPerformance=[];



$sql="

SELECT

c.category_name,


ROUND(AVG(ea.percentage),2) AS average


FROM exam_attempts ea


INNER JOIN exams e

ON ea.exam_id=e.exam_id


INNER JOIN categories c

ON e.category_id=c.category_id



WHERE ea.user_id=?



GROUP BY c.category_id



ORDER BY average DESC


";



$stmt=mysqli_prepare($conn,$sql);


mysqli_stmt_bind_param(
    $stmt,
    "i",
    $user_id
);


mysqli_stmt_execute($stmt);


$result=mysqli_stmt_get_result($stmt);



while($row=mysqli_fetch_assoc($result)){


    $categoryPerformance[]=$row;


}






// =====================================
// PROGRESS OVER TIME DATA
// =====================================

$progressLabels=[];

$progressScores=[];



$sql="

SELECT

DATE_FORMAT(end_time,'%b %d') AS exam_date,

percentage


FROM exam_attempts


WHERE user_id=?


ORDER BY end_time ASC



LIMIT 10


";



$stmt=mysqli_prepare($conn,$sql);


mysqli_stmt_bind_param(
    $stmt,
    "i",
    $user_id
);


mysqli_stmt_execute($stmt);


$result=mysqli_stmt_get_result($stmt);



while($row=mysqli_fetch_assoc($result)){


    $progressLabels[]=$row["exam_date"];


    $progressScores[]=$row["percentage"];


}






// =====================================
// STUDY STREAK
// =====================================


$studyStreak=0;



$sql="

SELECT DISTINCT DATE(end_time) AS study_date


FROM exam_attempts


WHERE user_id=?


ORDER BY study_date DESC


";



$stmt=mysqli_prepare($conn,$sql);


mysqli_stmt_bind_param(
    $stmt,
    "i",
    $user_id
);


mysqli_stmt_execute($stmt);


$result=mysqli_stmt_get_result($stmt);



$dates=[];


while($row=mysqli_fetch_assoc($result)){


    $dates[]=$row["study_date"];


}



// calculate consecutive days

if(count($dates)>0){


    $studyStreak=1;


    for($i=0;$i<count($dates)-1;$i++){


        $current=strtotime($dates[$i]);

        $next=strtotime($dates[$i+1]);


        if(($current-$next)==86400){


            $studyStreak++;


        }else{


            break;


        }


    }


}






// =====================================
// PERFORMANCE INSIGHT
// =====================================


$insightMessage=[];



if($overallProgress>=90){


    $insightMessage[]="Excellent performance! Keep maintaining your consistency.";


}elseif($overallProgress>=75){


    $insightMessage[]="Good performance. Continue practicing to improve further.";


}else{


    $insightMessage[]="More practice is recommended to improve your scores.";

}



if($quizTaken>0){


    $insightMessage[]=
    "You have completed ".$quizTaken." practice quiz(es).";


}else{


    $insightMessage[]=
    "Start taking practice quizzes to monitor your improvement.";

}



if($mockExams>0){


    $insightMessage[]=
    "You completed ".$mockExams." mock examination(s).";


}else{


    $insightMessage[]=
    "Take mock examinations to evaluate your readiness.";

}




?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">


<title>My Performance - e-Nurse</title>


<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">


<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">


<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>


<style>


*{

margin:0;
padding:0;
box-sizing:border-box;
font-family:'Poppins',sans-serif;

}


body{

background:#f4f7fc;

}


/* =========================
MAIN CONTENT
========================= */


.main-content{

margin-left:230px;

padding:30px;

min-height:100vh;

}



/* =========================
HEADER
========================= */


.header{


background:white;

padding:25px;

border-radius:18px;

box-shadow:0 8px 25px rgba(0,0,0,.08);

margin-bottom:30px;


}


.header h1{


font-size:32px;

color:#0A2F73;

margin-bottom:8px;


}


.header p{


color:#6b7280;

font-size:15px;


}






/* =========================
SUMMARY CARDS
========================= */


.stats-grid{


display:grid;

grid-template-columns:repeat(4,1fr);

gap:20px;

margin-bottom:30px;


}



.stat-card{


background:white;

padding:25px;

border-radius:18px;

box-shadow:0 8px 25px rgba(0,0,0,.08);

transition:.3s;


}



.stat-card:hover{


transform:translateY(-5px);


}



.stat-icon{


width:65px;

height:65px;

border-radius:16px;

display:flex;

justify-content:center;

align-items:center;

font-size:28px;

color:white;

margin-bottom:18px;


}




.stat-icon.blue{


background:linear-gradient(
135deg,
#2563eb,
#3b82f6
);


}



.stat-icon.pink{


background:linear-gradient(
135deg,
#ec4899,
#f472b6
);


}




.stat-icon.yellow{


background:linear-gradient(
135deg,
#f59e0b,
#fbbf24
);


}



.stat-icon.green{


background:linear-gradient(
135deg,
#10b981,
#34d399
);


}




.stat-label{


color:#6b7280;

font-size:14px;

margin-bottom:8px;


}



.stat-value{


font-size:32px;

font-weight:700;

color:#111827;


}



.stat-value.green{


color:#10b981;


}



.stat-description{


font-size:13px;

color:#6b7280;

margin-top:5px;


}





/* =========================
OVERALL PROGRESS CARD
========================= */


.progress-card{


display:flex;

align-items:center;

gap:20px;


}



.progress-circle{


position:relative;

width:120px;

height:120px;


}



.progress-circle canvas{


width:120px!important;

height:120px!important;


}



.progress-text{


position:absolute;

top:50%;

left:50%;

transform:translate(-50%,-50%);

font-size:25px;

font-weight:700;

color:#10b981;


}




/* =========================
RESPONSIVE
========================= */


@media(max-width:992px){


.stats-grid{


grid-template-columns:repeat(2,1fr);


}



}




@media(max-width:768px){



.main-content{


margin-left:0;

padding:80px 15px 20px;


}



.stats-grid{


grid-template-columns:1fr;


}



.header h1{


font-size:25px;


}



}


</style>


</head>



<body>



<?php include "user_sidebar.php"; ?>



<div class="main-content">



<!-- =========================
HEADER
========================= -->


<div class="header">


<h1>

<i class="fa-solid fa-chart-line"></i>

My Performance

</h1>


<p>

Welcome back,

<b>

<?= htmlspecialchars($fullname); ?>

</b>

<br>

Track your mock examination progress and subject mastery.

</p>


</div>







<!-- =========================
SUMMARY CARDS
========================= -->



<div class="stats-grid">





<!-- OVERALL -->


<div class="stat-card progress-card">


<div class="progress-circle">


<canvas id="progressChart"></canvas>


<div class="progress-text">

<?= number_format($overallProgress,1); ?>%

</div>


</div>



<div>


<div class="stat-label">

Overall Progress

</div>


<div class="stat-description">

Average examination performance

</div>


</div>



</div>








<!-- QUIZZES -->


<div class="stat-card">


<div class="stat-icon blue">


<i class="fa-solid fa-book-open"></i>


</div>



<div class="stat-label">

Practice Quizzes

</div>


<div class="stat-value">

<?= $quizTaken; ?>

</div>



<div class="stat-description">

Completed quizzes

</div>



</div>









<!-- MOCK EXAMS -->


<div class="stat-card">


<div class="stat-icon pink">


<i class="fa-solid fa-file-circle-check"></i>


</div>



<div class="stat-label">

Mock Examinations

</div>


<div class="stat-value">

<?= $mockExams; ?>

</div>



<div class="stat-description">

Completed mock exams

</div>



</div>








<!-- STREAK -->


<div class="stat-card">


<div class="stat-icon yellow">


<i class="fa-solid fa-fire"></i>


</div>



<div class="stat-label">

Study Streak

</div>


<div class="stat-value green">

<?= $studyStreak; ?>

</div>



<div class="stat-description">

Days of continuous learning

</div>



</div>





</div>
    
    <!-- =========================
PERFORMANCE ANALYTICS
========================= -->


<div class="charts-grid">



<!-- =========================
CATEGORY PERFORMANCE
========================= -->


<div class="card">


<h2>

<i class="fa-solid fa-layer-group"></i>

Performance by Category

</h2>



<div class="category-list">



<?php


if(count($categoryPerformance)>0){


foreach($categoryPerformance as $category){



$percentage=$category["average"];



if($percentage>=90){

    $barClass="excellent";

}elseif($percentage>=75){

    $barClass="passed";

}else{

    $barClass="failed";

}



?>



<div class="category-item">



<div class="category-header">


<span>

<?= htmlspecialchars($category["category_name"]); ?>

</span>



<strong>

<?= number_format($percentage,1); ?>%

</strong>



</div>





<div class="progress-bar">


<div 

class="<?= $barClass; ?>"

style="width:<?= $percentage; ?>%">

</div>


</div>



</div>



<?php


}


}else{


?>


<div class="empty">


<i class="fa-solid fa-folder-open"></i>


<p>

No category performance available yet.

</p>


</div>



<?php


}



?>



</div>


</div>








<!-- =========================
PROGRESS OVER TIME
========================= -->


<div class="card">


<h2>

<i class="fa-solid fa-chart-area"></i>

Progress Over Time

</h2>



<canvas id="lineChart"></canvas>



</div>





</div>






<style>



/* =========================
CHART SECTION
========================= */


.charts-grid{


display:grid;

grid-template-columns:1fr 1fr;

gap:25px;

margin-bottom:30px;


}



.card{


background:white;

padding:25px;

border-radius:18px;

box-shadow:0 8px 25px rgba(0,0,0,.08);


}



.card h2{


font-size:21px;

color:#0A2F73;

margin-bottom:25px;


}



.card h2 i{


margin-right:10px;

color:#2563eb;


}





/* =========================
CATEGORY BARS
========================= */


.category-item{


margin-bottom:22px;


}



.category-header{


display:flex;

justify-content:space-between;

margin-bottom:8px;

font-size:14px;

color:#374151;


}



.progress-bar{


width:100%;

height:10px;

background:#e5e7eb;

border-radius:20px;

overflow:hidden;


}



.progress-bar div{


height:100%;

border-radius:20px;

transition:1s;


}



.progress-bar .excellent{


background:#2563eb;


}



.progress-bar .passed{


background:#10b981;


}



.progress-bar .failed{


background:#ef4444;


}





.empty{


text-align:center;

padding:40px;

color:#6b7280;


}


.empty i{


font-size:50px;

margin-bottom:15px;

color:#2563eb;


}





canvas{


max-height:320px;


}





@media(max-width:992px){


.charts-grid{


grid-template-columns:1fr;


}



}


</style>







<script>


// ==============================
// OVERALL PROGRESS CIRCLE
// ==============================


const progressCtx =
document.getElementById("progressChart");



new Chart(progressCtx,{


type:"doughnut",


data:{


datasets:[{


data:[

<?= $overallProgress; ?>,

100-<?= $overallProgress; ?>

],


backgroundColor:[

"#10b981",

"#e5e7eb"

],


borderWidth:0


}]


},



options:{


cutout:"75%",


plugins:{


legend:{


display:false


},


tooltip:{


enabled:false


}



}


}



});








// ==============================
// LINE GRAPH
// ==============================



const lineCtx =
document.getElementById("lineChart");



new Chart(lineCtx,{


type:"line",


data:{


labels:


<?= json_encode($progressLabels); ?>,



datasets:[{


label:"Performance Score",


data:


<?= json_encode($progressScores); ?>,


borderColor:"#2563eb",


backgroundColor:
"rgba(37,99,235,.15)",


fill:true,


tension:.4,


pointRadius:5


}]


},




options:{


responsive:true,


scales:{


y:{


beginAtZero:true,


max:100,


ticks:{


callback:function(value){


return value+"%";


}


}


}



},



plugins:{


legend:{


display:false


}



}



}



});



</script>
    
    <!-- =========================
BOTTOM SECTION
========================= -->


<div class="bottom-grid">



<!-- =========================
STUDY SUMMARY
========================= -->


<div class="card streak-card">



<div class="streak-icon">

<i class="fa-solid fa-fire"></i>

</div>



<h2>

Study Streak

</h2>



<div class="streak-number">

<?= $studyStreak; ?>

</div>



<p>

Consecutive learning days

</p>




<?php


if($studyStreak >= 7){


$message="Excellent consistency! Keep it up.";


}elseif($studyStreak >=3){


$message="Good progress. Continue studying daily.";


}else{


$message="Start building your study habit today.";


}



?>


<div class="streak-message">


<?= $message; ?>


</div>



</div>








<!-- =========================
INSIGHTS
========================= -->


<div class="card">



<h2>

<i class="fa-solid fa-lightbulb"></i>

Performance Insights

</h2>



<div class="insight-list">



<?php


foreach($insightMessage as $index=>$message){


?>


<div class="insight-item">



<div class="insight-icon">


<?php


if($index==0){


echo '<i class="fa-solid fa-chart-line"></i>';


}elseif($index==1){


echo '<i class="fa-solid fa-book-open"></i>';


}else{


echo '<i class="fa-solid fa-clipboard-check"></i>';


}


?>


</div>




<p>

<?= htmlspecialchars($message); ?>

</p>



</div>



<?php


}


?>



</div>


</div>



</div>






</div>




<style>



/* =========================
BOTTOM GRID
========================= */


.bottom-grid{


display:grid;

grid-template-columns:1fr 2fr;

gap:25px;

margin-bottom:30px;


}




/* =========================
STREAK CARD
========================= */


.streak-card{


text-align:center;

background:

linear-gradient(
135deg,
#fff7ed,
#fef3c7
);


}



.streak-icon{


font-size:45px;

color:#f59e0b;

margin-bottom:15px;


}



.streak-card h2{


color:#92400e;

margin-bottom:15px;


}



.streak-number{


font-size:60px;

font-weight:700;

color:#92400e;


}



.streak-card p{


color:#92400e;

margin-bottom:15px;


}



.streak-message{


font-weight:600;

color:#78350f;


}






/* =========================
INSIGHTS
========================= */


.insight-list{


display:flex;

flex-direction:column;

gap:15px;


}



.insight-item{


display:flex;

align-items:center;

gap:15px;

padding:15px;

border-radius:12px;

background:#f8fafc;


}



.insight-icon{


width:40px;

height:40px;

border-radius:12px;

display:flex;

align-items:center;

justify-content:center;

background:#dbeafe;

color:#2563eb;


}



.insight-item p{


font-size:14px;

color:#374151;

line-height:1.5;


}






/* =========================
RESPONSIVE
========================= */


@media(max-width:992px){


.bottom-grid{


grid-template-columns:1fr;


}


}



</style>





<script>


// ==========================
// PAGE ANIMATION
// ==========================


window.addEventListener("load",()=>{


document.querySelectorAll(".card,.stat-card")

.forEach((item,index)=>{


item.style.opacity="0";


item.style.transform="translateY(20px)";



setTimeout(()=>{


item.style.transition=".5s";


item.style.opacity="1";


item.style.transform="translateY(0)";


},index*100);



});



});



</script>



</body>


</html>